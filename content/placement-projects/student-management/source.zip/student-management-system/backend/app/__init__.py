"""Student Management backend application package.

Layout (each folder does one job, so you can find things by name):

  config/    - environment-driven settings (database URL, port, secrets)
  database/  - SQLAlchemy engine/session plumbing and the demo-data seeder
  models/    - the ORM: one Python class per database table
  schemas/   - Pydantic request-body models
  security/  - password hashing, session tokens, the auth dependency
  routers/   - the HTTP layer: one module per group of endpoints
"""
