"""Unauthenticated liveness endpoints.

Used by uptime checks and by the frontend's ConnectionStatus indicator, which
polls this to tell the user whether the API is reachable.
"""
from datetime import datetime, timezone

from fastapi import APIRouter

router = APIRouter(tags=["Health"])


@router.get("/health")
def health():
    """Root-level health check (no /api prefix)."""
    return {"status": "OK", "message": "Student Management API is running", "timestamp": datetime.now(timezone.utc).isoformat()}


@router.get("/api/health")
def api_health():
    """The same check under /api, for clients that only talk to the API prefix."""
    return {"status": "healthy", "timestamp": datetime.now(timezone.utc).isoformat(), "environment": "development"}
