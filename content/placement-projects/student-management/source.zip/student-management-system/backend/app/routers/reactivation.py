"""Finding and restoring soft-deleted records.

Nothing in this app is really deleted by default: deactivating a class or a
student only flips a flag, so their marks, fees and attendance history stay
intact. That makes it easy to lose track of them, which is what these routes
fix - the admin UI polls /deactivated on load and offers to restore whatever
it finds.

Reactivating a student also reactivates their login, because a student whose
users row is still inactive could not sign in and would look broken.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.database import get_session
from app.models import SchoolClass, Student, Teacher, User
from app.security import current_user

router = APIRouter(prefix="/api/reactivation", tags=["Reactivation"])


async def _body(request: Request) -> dict:
    """Read an optional JSON body.

    The frontend calls some of these endpoints with no body at all, which
    would otherwise be a 422 from a declared Pydantic parameter.
    """
    try:
        payload = await request.json()
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


@router.get("/deactivated")
def deactivated(session: Session = Depends(get_session), user=Depends(current_user)):
    """Every deactivated class, student and user, with the context the admin
    modal shows: how many students a class holds, and whether a student's
    class is itself still active (if not, the class has to be restored first).
    """
    # SQL: SELECT * FROM classes WHERE active = false
    classes = session.execute(select(SchoolClass).where(SchoolClass.active.is_(False))).scalars().all()
    # SQL: SELECT * FROM students WHERE status <> 'active'
    students = session.execute(select(Student).where(Student.status != "active")).scalars().all()
    # SQL: SELECT * FROM users WHERE active = false
    users = session.execute(select(User).where(User.active.is_(False))).scalars().all()

    # SQL: SELECT classid, COUNT(*) FROM students GROUP BY classid
    student_counts = dict(session.execute(
        select(Student.class_id, func.count()).group_by(Student.class_id)
    ).all())
    # SQL: SELECT * FROM teachers
    teachers = {row.teacher_id: row for row in session.execute(select(Teacher)).scalars().all()}
    # SQL: SELECT * FROM classes
    all_classes = {row.class_id: row for row in session.execute(select(SchoolClass)).scalars().all()}

    class_rows = []
    for school_class in classes:
        teacher = teachers.get(school_class.class_teacher_id)
        record = school_class.to_dict()
        record["_count"] = {"students": student_counts.get(school_class.class_id, 0)}
        record["classTeacher"] = {"name": teacher.name} if teacher else None
        class_rows.append(record)

    student_rows = []
    for student in students:
        school_class = all_classes.get(student.class_id)
        record = student.to_dict()
        record["class"] = (
            {"className": school_class.class_name, "section": school_class.section, "active": school_class.active}
            if school_class else None
        )
        student_rows.append(record)

    user_rows = [account.public() for account in users]
    return {
        "success": True,
        "counts": {
            "total": len(class_rows) + len(student_rows) + len(user_rows),
            "classes": len(class_rows),
            "students": len(student_rows),
            "users": len(user_rows),
        },
        "data": {"classes": class_rows, "students": student_rows, "users": user_rows},
    }


def _reactivate_student(session: Session, student: Student) -> None:
    """Restore a student row and the login that goes with it."""
    student.status = "active"
    # SQL: SELECT * FROM users WHERE username = :student_id
    account = session.get(User, student.student_id)
    if account:
        account.active = True


@router.post("/class/{class_id}")
async def reactivate_class(class_id: int, request: Request, session: Session = Depends(get_session), user=Depends(current_user)):
    """Reactivate a class, and its students too if includeStudents is set."""
    # SQL: SELECT * FROM classes WHERE classid = :class_id
    school_class = session.get(SchoolClass, class_id)
    if not school_class:
        raise HTTPException(404, "Class not found")

    school_class.active = True
    restored = 0
    if (await _body(request)).get("includeStudents"):
        # SQL: SELECT * FROM students WHERE classid = :class_id AND status <> 'active'
        for student in session.execute(
            select(Student).where(Student.class_id == class_id, Student.status != "active")
        ).scalars().all():
            _reactivate_student(session, student)
            restored += 1
    session.commit()

    suffix = f" and {restored} student(s)" if restored else ""
    return {
        "success": True,
        "message": f"Class {school_class.display_name} reactivated{suffix}",
        "data": {"classId": class_id, "studentsReactivated": restored},
    }


@router.post("/class/{class_id}/students")
def reactivate_class_with_students(class_id: int, session: Session = Depends(get_session), user=Depends(current_user)):
    """Reactivate a class and every deactivated student in it."""
    # SQL: SELECT * FROM classes WHERE classid = :class_id
    school_class = session.get(SchoolClass, class_id)
    if not school_class:
        raise HTTPException(404, "Class not found")

    school_class.active = True
    # SQL: SELECT * FROM students WHERE classid = :class_id AND status <> 'active'
    students = session.execute(
        select(Student).where(Student.class_id == class_id, Student.status != "active")
    ).scalars().all()
    for student in students:
        _reactivate_student(session, student)
    session.commit()

    return {
        "success": True,
        "message": f"Class {school_class.display_name} and {len(students)} student(s) reactivated",
        "data": {"classId": class_id, "studentsReactivated": len(students)},
    }


@router.post("/student/{student_id}")
def reactivate_student(student_id: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Reactivate one student.

    Refused while their class is still deactivated, since an active student in
    an inactive class would not appear anywhere in the UI.
    """
    # SQL: SELECT * FROM students WHERE studentid = :student_id
    student = session.get(Student, student_id)
    if not student:
        raise HTTPException(404, "Student not found")

    # SQL: SELECT * FROM classes WHERE classid = :class_id
    school_class = session.get(SchoolClass, student.class_id) if student.class_id else None
    if school_class and not school_class.active:
        raise HTTPException(409, f"Reactivate class {school_class.display_name} first")

    _reactivate_student(session, student)
    session.commit()
    return {"success": True, "message": f"{student.name} reactivated", "data": student.to_dict()}
