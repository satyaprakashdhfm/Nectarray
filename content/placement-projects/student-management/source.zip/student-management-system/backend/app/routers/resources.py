"""Generic, protected CRUD endpoints for every academic table.

Rather than eleven near-identical routers, RESOURCES maps a URL segment
("students", "marks", ...) to its ORM model, and one set of list/get/create/
update/delete handlers serves them all. Every route requires a valid session.

Responses carry the row list twice - once under "data" and once under the
resource's own name ("students", "marks", ...) - because different frontend
pages read different keys, and returning both keeps every page working
without touching the React code.
"""
from __future__ import annotations

import time
import uuid
from datetime import date, datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from app.database import get_session
from app.models import (
    Attendance,
    Fee,
    Mark,
    SchoolClass,
    Student,
    Subject,
    Syllabus,
    Teacher,
    User,
    to_camel,
    to_snake,
)
from app.schemas import Payload
from app.security import current_user

router = APIRouter(prefix="/api", tags=["Student Management"])

# URL segment -> (ORM model, the extra response key that segment's pages read)
RESOURCES: dict[str, tuple[type, str]] = {
    "users": (User, "users"),
    "students": (Student, "students"),
    "teachers": (Teacher, "teachers"),
    "classes": (SchoolClass, "classes"),
    "subjects": (Subject, "subjects"),
    "attendance": (Attendance, "attendance"),
    "marks": (Mark, "marks"),
    "fees": (Fee, "fees"),
    "syllabus": (Syllabus, "syllabus"),
}

# Query params the frontend appends to list requests. A given table only has
# some of these columns, so each is applied only where it exists.
FILTER_FIELDS = (
    "classId", "studentId", "teacherId", "subjectCode", "academicYear",
    "status", "active", "isActive", "examinationType", "feeType", "grade",
)


def resolve(name: str) -> tuple[type, str]:
    """Look up a URL segment's model, or 404 on an unknown resource."""
    if name not in RESOURCES:
        raise HTTPException(404, "Route not found")
    return RESOURCES[name]


# The related rows each resource's pages read nested inside a record
# (fee.student.name, student.class.classTeacher.name). The key is the JSON
# name the React code uses; the value is the ORM relationship it comes from.
EMBEDDED: dict[type, dict[str, str]] = {
    Student: {"class": "school_class"},
    SchoolClass: {"classTeacher": "class_teacher"},
    Attendance: {"student": "student", "class": "school_class", "subject": "subject"},
    Mark: {"student": "student", "class": "school_class", "subject": "subject", "teacher": "teacher"},
    Fee: {"student": "student", "class": "school_class"},
    Syllabus: {"class": "school_class", "subject": "subject", "teacher": "teacher"},
}


def embed(row, depth: int = 2) -> dict:
    """One row as a camelCase dict, with its related rows nested inside it.

    Two levels deep is enough for every screen: a student carries their class,
    and that class carries its class teacher.
    """
    record = row.public() if isinstance(row, User) else row.to_dict()
    if depth <= 0:
        return record
    for key, attribute in EMBEDDED.get(type(row), {}).items():
        related = getattr(row, attribute, None)
        record[key] = embed(related, depth - 1) if related is not None else None
    return record


def embed_options(model: type, depth: int = 2) -> list:
    """Eager-load whatever embed() is about to walk, so listing 1000 fees
    costs a couple of extra queries instead of a thousand."""
    options = []
    for attribute in EMBEDDED.get(model, {}).values():
        relation = getattr(model, attribute)
        loader = selectinload(relation)
        target = relation.property.mapper.class_
        nested = list(EMBEDDED.get(target, {}).values()) if depth > 1 else []
        if nested:
            options.extend(loader.selectinload(getattr(target, name)) for name in nested)
        else:
            options.append(loader)
    return options


def serialize(rows: list) -> list[dict]:
    """Turn ORM rows into the camelCase dicts the frontend expects."""
    return [embed(row) for row in rows]


def query_for(model: type, query: dict[str, str]):
    """Build a SELECT with only the filters that apply to this model.

    The frontend sends the same query string to several resources (teacherId
    on /attendance, for instance, which has no such column), so an unknown
    field is skipped rather than turned into invalid SQL.
    """
    columns = model.columns()
    # SQL: SELECT * FROM <resource table> WHERE <each supplied filter> [AND date BETWEEN :startDate AND :endDate]
    statement = select(model)
    for field in FILTER_FIELDS:
        attribute = to_snake(field)
        if field in query and attribute in columns:
            value = query[field]
            if str(value).lower() in ("true", "false"):
                value = str(value).lower() == "true"
            statement = statement.where(getattr(model, attribute) == value)
    # Date-range filtering for the attendance/marks screens, which send
    # startDate/endDate rather than an exact date.
    if "date" in columns:
        if query.get("startDate"):
            statement = statement.where(model.date >= date.fromisoformat(query["startDate"][:10]))
        if query.get("endDate"):
            statement = statement.where(model.date <= date.fromisoformat(query["endDate"][:10]))
    return statement


def list_resource(session: Session, name: str, query: dict[str, str]) -> dict:
    """Filter, count and page one resource; shared by the generic list route
    and the student-scoped convenience routes below."""
    model, response_key = resolve(name)
    statement = query_for(model, query)

    # SQL: SELECT COUNT(*) FROM (<the filtered select above>)
    total = session.execute(select(func.count()).select_from(statement.subquery())).scalar() or 0
    limit = min(max(int(query.get("limit", 1000)), 1), 10_000)
    page = max(int(query.get("page", 1)), 1)
    # SQL: <the filtered select above> LIMIT :limit OFFSET :offset, plus one
    # SELECT ... WHERE id IN (...) per embedded relation.
    rows = session.execute(
        statement.options(*embed_options(model)).limit(limit).offset((page - 1) * limit)
    ).scalars().all()

    records = serialize(rows)
    return {
        "success": True,
        "data": records,
        response_key: records,
        "pagination": {
            "page": page,
            "limit": limit,
            "total": total,
            "pages": max(1, (total + limit - 1) // limit),
        },
    }


def new_primary_key(model: type, data: dict) -> object:
    """Pick the primary key for a new row: whatever the client supplied, else
    a UUID - or a timestamp for classes, whose key is an integer."""
    key_name = model.primary_key()
    supplied = data.get(to_camel(key_name), data.get(key_name))
    if supplied not in (None, ""):
        return supplied
    return int(time.time()) if model is SchoolClass else str(uuid.uuid4())


def apply_defaults(model: type, row) -> None:
    """Fill in the server-owned fields the frontend never sends."""
    if isinstance(row, Attendance) and row.timestamp is None:
        row.timestamp = datetime.now(timezone.utc)
    if isinstance(row, Mark) and row.entry_date is None:
        row.entry_date = date.today()
    if isinstance(row, Syllabus):
        row.last_updated = datetime.now(timezone.utc)
    if isinstance(row, Fee):
        # balance is derived, never trusted from the request body.
        row.balance = float(row.amount_due or 0) - float(row.amount_paid or 0)
        if not row.academic_year:
            row.academic_year = "2024-2025"


@router.get("/marks/student/{student_id}")
def student_marks(student_id: str, request: Request, session: Session = Depends(get_session), user=Depends(current_user)):
    """All marks for one student, used by the student and teacher marks views."""
    return list_resource(session, "marks", {**dict(request.query_params), "studentId": student_id})


@router.get("/fees/student/{student_id}")
def student_fees(student_id: str, request: Request, session: Session = Depends(get_session), user=Depends(current_user)):
    """All fee rows for one student."""
    return list_resource(session, "fees", {**dict(request.query_params), "studentId": student_id})


@router.get("/attendance/student/{student_id}")
def student_attendance(student_id: str, request: Request, session: Session = Depends(get_session), user=Depends(current_user)):
    """All attendance rows for one student."""
    return list_resource(session, "attendance", {**dict(request.query_params), "studentId": student_id})


@router.get("/students/grade/{grade}")
def students_by_grade(grade: str, request: Request, session: Session = Depends(get_session), user=Depends(current_user)):
    """Students in every class whose className matches this grade.

    The grade in the path is a class name ("Grade 10"), which may span several
    sections, so this resolves it to class ids first.
    """
    # SQL: SELECT classid FROM classes WHERE classname = :grade
    class_ids = session.execute(
        select(SchoolClass.class_id).where(SchoolClass.class_name == grade)
    ).scalars().all()
    query = dict(request.query_params)
    if not class_ids:
        return {"success": True, "data": [], "students": [], "pagination": {"page": 1, "limit": 0, "total": 0, "pages": 1}}

    # SQL: SELECT * FROM students WHERE classid IN :class_ids [AND status = :status]
    statement = select(Student).where(Student.class_id.in_(class_ids))
    if query.get("status"):
        statement = statement.where(Student.status == query["status"])
    rows = session.execute(statement.options(*embed_options(Student))).scalars().all()
    records = serialize(rows)
    return {
        "success": True,
        "data": records,
        "students": records,
        "pagination": {"page": 1, "limit": len(records), "total": len(records), "pages": 1},
    }


@router.post("/fees/{fee_id}/payment")
def record_payment(fee_id: str, body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Apply a payment to a fee, adding to amountPaid rather than replacing it."""
    # SQL: SELECT * FROM fees WHERE feeid = :fee_id
    fee = session.get(Fee, fee_id)
    if not fee:
        raise HTTPException(404, "Fee not found")

    data = body.model_dump()
    payment = float(data.get("amount", data.get("amountPaid", 0)) or 0)
    fee.amount_paid = float(fee.amount_paid or 0) + payment
    fee.balance = float(fee.amount_due or 0) - float(fee.amount_paid)
    fee.payment_date = date.today()
    fee.payment_method = data.get("paymentMethod") or fee.payment_method
    fee.updated_by = user.username
    session.commit()
    return {"success": True, "message": "Payment recorded successfully", "data": embed(fee)}


@router.put("/syllabus/{syllabus_id}/progress")
def update_syllabus_progress(syllabus_id: str, body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Update how far a syllabus unit has got.

    The teacher UI ticks sub-topics off, so when it sends completedSubTopics
    without an explicit percentage the percentage is derived from the counts
    and the status follows from that.
    """
    # SQL: SELECT * FROM syllabus WHERE syllabusid = :syllabus_id
    unit = session.get(Syllabus, syllabus_id)
    if not unit:
        raise HTTPException(404, "Syllabus record not found")

    data = body.model_dump()
    unit.apply(data, skip={"syllabus_id"})
    if "completionPercentage" not in data and unit.sub_topics:
        done = len(unit.completed_sub_topics or [])
        unit.completion_percentage = round(done * 100 / len(unit.sub_topics))
    if "completionStatus" not in data:
        percentage = unit.completion_percentage or 0
        unit.completion_status = "completed" if percentage >= 100 else "in_progress" if percentage > 0 else "not_started"
    unit.last_updated = datetime.now(timezone.utc)
    session.commit()
    return {"success": True, "message": "Progress updated successfully", "data": embed(unit)}


@router.put("/users/{username}/activate")
def activate_user(username: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Re-enable a deactivated login, and their student record if they have one."""
    # SQL: SELECT * FROM users WHERE username = :username
    account = session.get(User, username)
    if not account:
        raise HTTPException(404, "User not found")
    account.active = True
    # SQL: SELECT * FROM students WHERE studentid = :username
    student = session.get(Student, username)
    if student:
        student.status = "active"
    session.commit()
    return {"success": True, "message": f"{username} reactivated", "data": account.public()}


@router.get("/{resource}")
def list_items(resource: str, request: Request, session: Session = Depends(get_session), user=Depends(current_user)):
    """Generic list route: GET /api/students, /api/marks, ... with filtering and paging."""
    return list_resource(session, resource, dict(request.query_params))


@router.get("/{resource}/{item_id}")
def get_item(resource: str, item_id: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Generic get-by-id route.

    Teachers and subjects also get their fields spread onto the top level,
    because older frontend code reads them un-nested (teacher.classesAssigned
    rather than response.data.classesAssigned).
    """
    model, _ = resolve(resource)
    # SQL: SELECT * FROM <resource table> WHERE <primary key> = :item_id
    row = session.get(model, item_id)
    if not row:
        raise HTTPException(404, "Record not found")
    record = embed(row)
    if resource in ("teachers", "subjects"):
        return {"success": True, "data": record, **record}
    return {"success": True, "data": record}


@router.post("/{resource}", status_code=201)
def create_item(resource: str, body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Generic create route. `users` is excluded: accounts are only created
    through /api/auth/register, which hashes the password.

    One route serves nine tables, so the body has no fixed shape: send the
    same camelCase fields that resource's GET returns. Run the matching GET
    first to see them - `POST /api/students` takes studentId, name, email,
    classId and so on. Unknown keys are ignored, and the primary key is
    generated when you leave it out.
    """
    if resource == "users":
        raise HTTPException(404, "Route not found")
    model, _ = resolve(resource)

    data = body.model_dump()
    row = model()
    row.apply(data)
    setattr(row, model.primary_key(), new_primary_key(model, data))
    apply_defaults(model, row)

    # SQL: INSERT INTO <resource table> (<supplied columns>) VALUES (...)
    session.add(row)
    try:
        session.commit()
    except IntegrityError as error:
        session.rollback()
        raise HTTPException(409, "A record with the same unique value already exists") from error
    return {"success": True, "message": "Created successfully", "data": embed(row)}


@router.put("/{resource}/{item_id}")
def update_item(resource: str, item_id: str, body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Generic partial-update route; a fee's balance is always recomputed.

    Send only the fields you want to change, in the same camelCase the GET
    returns - `{"status": "inactive"}` is a complete request. This is also how
    the admin UI soft-deletes a student.
    """
    if resource == "users":
        raise HTTPException(404, "Route not found")
    model, _ = resolve(resource)
    # SQL: SELECT * FROM <resource table> WHERE <primary key> = :item_id
    row = session.get(model, item_id)
    if not row:
        raise HTTPException(404, "Record not found")

    # SQL: UPDATE <resource table> SET <supplied columns> WHERE <primary key> = :item_id
    row.apply(body.model_dump(), skip={model.primary_key()})
    if isinstance(row, Fee):
        row.balance = float(row.amount_due or 0) - float(row.amount_paid or 0)
    if isinstance(row, Syllabus):
        row.last_updated = datetime.now(timezone.utc)
    try:
        session.commit()
    except IntegrityError as error:
        session.rollback()
        raise HTTPException(409, "A record with the same unique value already exists") from error
    return {"success": True, "message": "Updated successfully", "data": embed(row)}


@router.delete("/{resource}/{item_id}")
def delete_item(resource: str, item_id: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Generic hard delete-by-id route.

    The admin UI reaches this only from its explicit "delete permanently"
    action; its normal delete button soft-deletes instead, by PUTting
    status=inactive so marks, fees and attendance survive. A row still
    referenced elsewhere returns 409 rather than a 500.
    """
    model, _ = resolve(resource)
    # SQL: SELECT * FROM <resource table> WHERE <primary key> = :item_id
    row = session.get(model, item_id)
    if not row:
        raise HTTPException(404, "Record not found")
    # SQL: DELETE FROM <resource table> WHERE <primary key> = :item_id
    session.delete(row)
    try:
        session.commit()
    except IntegrityError as error:
        session.rollback()
        raise HTTPException(
            409, "This record is still referenced by other records and cannot be deleted"
        ) from error
    return {"success": True, "message": "Deleted successfully"}
