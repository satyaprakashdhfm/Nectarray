"""Aggregate endpoints behind the admin summary dashboards.

Each /{resource}/stats/overview route answers one page's questions in a
single request, so the browser never has to download every row and add it up
in JavaScript. The response shapes match what AttendanceSummary, MarksSummary
and FeeSummary already read.

This router is registered before resources.py so that "stats" is matched as a
stats request rather than as a record id by the generic /{resource}/{id} route.
"""
from __future__ import annotations

from datetime import date, timedelta

from fastapi import APIRouter, Depends, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.database import get_session
from app.models import Attendance, Fee, Mark, SchoolClass
from app.security import current_user

router = APIRouter(prefix="/api", tags=["Statistics"])


def percentage(part: float, whole: float) -> float:
    """Safe percentage, rounded to one decimal, that returns 0 instead of
    dividing by zero when a class or fee type has no records yet."""
    return round(part * 100 / whole, 1) if whole else 0.0


def classes_in_year(session: Session, academic_year: str | None) -> list[int] | None:
    """Class ids for one academic year, or None meaning "no year filter".

    Attendance and marks have no academicYear column of their own - they are
    scoped to a year through the class they belong to.
    """
    if not academic_year:
        return None
    # SQL: SELECT classid FROM classes WHERE academicyear = :academic_year
    return list(session.execute(
        select(SchoolClass.class_id).where(SchoolClass.academic_year == academic_year)
    ).scalars().all())


@router.get("/attendance/stats/overview")
def attendance_stats(request: Request, session: Session = Depends(get_session), user=Depends(current_user)):
    """Attendance totals by status, overall and per class."""
    class_ids = classes_in_year(session, request.query_params.get("academicYear"))

    def scoped(statement):
        return statement.where(Attendance.class_id.in_(class_ids)) if class_ids is not None else statement

    # SQL: SELECT status, COUNT(*) FROM attendance [WHERE classid IN :class_ids] GROUP BY status
    by_status = session.execute(scoped(
        select(Attendance.status, func.count()).group_by(Attendance.status)
    )).all()
    # SQL: SELECT classid, status, COUNT(*) FROM attendance [WHERE classid IN :class_ids] GROUP BY classid, status
    by_class = session.execute(scoped(
        select(Attendance.class_id, Attendance.status, func.count()).group_by(Attendance.class_id, Attendance.status)
    )).all()

    counts = {status: count for status, count in by_status}
    total = sum(counts.values())
    return {
        "success": True,
        "total": total,
        "present": counts.get("present", 0),
        "absent": counts.get("absent", 0),
        "late": counts.get("late", 0),
        "excused": counts.get("excused", 0),
        "attendanceRate": percentage(counts.get("present", 0), total),
        "statusDistribution": [{"status": status, "count": count} for status, count in by_status],
        "classWiseStats": [
            {"classId": class_id, "status": status, "count": count} for class_id, status, count in by_class
        ],
        "data": {"total": total},
    }


@router.get("/marks/stats/overview")
def marks_stats(request: Request, session: Session = Depends(get_session), user=Depends(current_user)):
    """Exam totals: overall average, grade spread and per-exam performance."""
    class_ids = classes_in_year(session, request.query_params.get("academicYear"))

    def scoped(statement):
        return statement.where(Mark.class_id.in_(class_ids)) if class_ids is not None else statement

    # SQL: SELECT COUNT(*), COALESCE(SUM(marksobtained),0), COALESCE(SUM(maxmarks),0) FROM marks [WHERE classid IN :class_ids]
    total, obtained, maximum = session.execute(scoped(
        select(func.count(), func.coalesce(func.sum(Mark.marks_obtained), 0), func.coalesce(func.sum(Mark.max_marks), 0))
    )).one()
    # SQL: SELECT grade, COUNT(*) FROM marks [WHERE classid IN :class_ids] GROUP BY grade ORDER BY grade
    by_grade = session.execute(scoped(
        select(Mark.grade, func.count()).group_by(Mark.grade).order_by(Mark.grade)
    )).all()
    # SQL: SELECT examinationtype, COUNT(*), COALESCE(SUM(marksobtained),0), COALESCE(SUM(maxmarks),0) FROM marks [WHERE classid IN :class_ids] GROUP BY examinationtype
    by_exam = session.execute(scoped(
        select(Mark.examination_type, func.count(), func.coalesce(func.sum(Mark.marks_obtained), 0), func.coalesce(func.sum(Mark.max_marks), 0))
        .group_by(Mark.examination_type)
    )).all()

    return {
        "success": True,
        "total": total,
        "overall": {
            "totalRecords": total,
            "averagePercentage": percentage(float(obtained), float(maximum)),
            "totalMarksObtained": float(obtained),
            "totalMaxMarks": float(maximum),
        },
        "gradeDistribution": [{"grade": grade or "N/A", "count": count} for grade, count in by_grade],
        "examTypePerformance": [
            {
                "examinationType": exam_type,
                "totalRecords": count,
                "averagePercentage": percentage(float(scored), float(possible)),
            }
            for exam_type, count, scored, possible in by_exam
        ],
        "data": {"total": total},
    }


@router.get("/fees/stats/overview")
def fee_stats(request: Request, session: Session = Depends(get_session), user=Depends(current_user)):
    """Fee collection: overall totals, payment status, and splits by fee type and class."""
    query = request.query_params
    # SQL: SELECT * FROM fees [WHERE academicyear = :year] [AND feetype = :type] [AND classid = :classId]
    statement = select(Fee)
    if query.get("academicYear"):
        statement = statement.where(Fee.academic_year == query["academicYear"])
    if query.get("feeType"):
        statement = statement.where(Fee.fee_type == query["feeType"])
    if query.get("classId"):
        statement = statement.where(Fee.class_id == int(query["classId"]))
    fees = session.execute(statement).scalars().all()

    total_due = sum(float(fee.amount_due or 0) for fee in fees)
    total_paid = sum(float(fee.amount_paid or 0) for fee in fees)

    # A fee is "paid" only when nothing is outstanding, "unpaid" when nothing
    # has come in at all, and "partial" for everything in between.
    status_counts = {"paid": 0, "partial": 0, "unpaid": 0}
    for fee in fees:
        paid, due = float(fee.amount_paid or 0), float(fee.amount_due or 0)
        status_counts["paid" if paid >= due else "unpaid" if paid <= 0 else "partial"] += 1

    by_type: dict[str, dict] = {}
    for fee in fees:
        bucket = by_type.setdefault(fee.fee_type, {"feeType": fee.fee_type, "totalDue": 0.0, "totalPaid": 0.0, "count": 0})
        bucket["totalDue"] += float(fee.amount_due or 0)
        bucket["totalPaid"] += float(fee.amount_paid or 0)
        bucket["count"] += 1
    for bucket in by_type.values():
        bucket["collectionPercentage"] = percentage(bucket["totalPaid"], bucket["totalDue"])

    # SQL: SELECT * FROM classes
    classes = {row.class_id: row for row in session.execute(select(SchoolClass)).scalars().all()}
    by_class: dict[int, dict] = {}
    for fee in fees:
        school_class = classes.get(fee.class_id)
        bucket = by_class.setdefault(fee.class_id, {
            "classId": fee.class_id,
            "className": school_class.class_name if school_class else str(fee.class_id),
            "section": school_class.section if school_class else "",
            "academicYear": school_class.academic_year if school_class else "",
            "maxStudents": school_class.max_students if school_class else 40,
            "totalDue": 0.0,
            "totalPaid": 0.0,
        })
        bucket["totalDue"] += float(fee.amount_due or 0)
        bucket["totalPaid"] += float(fee.amount_paid or 0)
    for bucket in by_class.values():
        bucket["collectionPercentage"] = percentage(bucket["totalPaid"], bucket["totalDue"])

    cutoff = date.today() - timedelta(days=30)
    recent = [fee for fee in fees if fee.payment_date and fee.payment_date >= cutoff]

    return {
        "success": True,
        "total": len(fees),
        "overall": {
            "totalRecords": len(fees),
            "totalDue": total_due,
            "totalPaid": total_paid,
            "totalBalance": total_due - total_paid,
            "collectionPercentage": percentage(total_paid, total_due),
        },
        "paymentStatus": status_counts,
        "feeTypeCollection": sorted(by_type.values(), key=lambda bucket: bucket["feeType"]),
        "classWiseStats": sorted(by_class.values(), key=lambda bucket: bucket["classId"]),
        "recentPayments": {"amount": sum(float(fee.amount_paid or 0) for fee in recent), "count": len(recent)},
        "data": {"total": len(fees)},
    }


@router.get("/{resource}/stats/overview")
def generic_stats(resource: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Row count for any other resource, used by the admin dashboard tiles."""
    from app.routers.resources import resolve  # imported here to avoid a circular import

    model, _ = resolve(resource)
    # SQL: SELECT COUNT(*) FROM <resource table>
    total = session.execute(select(func.count()).select_from(model)).scalar() or 0
    return {"success": True, "total": total, "data": {"total": total}}
