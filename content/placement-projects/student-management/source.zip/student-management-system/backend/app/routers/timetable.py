"""Timetable, calendar, exam and holiday endpoints under /api/timemanagement.

The frontend draws its week grid from two things: the recurring weekly
schedule (ScheduleSlot) and whatever makes a particular date special
(CalendarDay). This module overlays them and returns one row per weekday.

The encoded slot strings below ("SLOT_MORNING_P1_0900_0940_teacher1_MAT10")
are not a new invention - they are the format the existing timetable
components already parse, so they are produced here rather than changing
every calendar screen in the React app.
"""
from __future__ import annotations

import re
import uuid
from datetime import date, time, timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_session
from app.models import CalendarDay, SchoolClass, ScheduleSlot, Student, Subject, Teacher
from app.schemas import Payload
from app.security import current_user

router = APIRouter(prefix="/api", tags=["Timetable"])

DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
LUNCH_START, LUNCH_END = time(11, 40), time(12, 20)
# The marker the frontend recognises for the fixed midday break.
LUNCH_SLOT = "LUNCH_BREAK_P5_1140_1220"


def _hhmm(value: time | None) -> str:
    """Format a time as the compact HHMM the slot strings use."""
    return value.strftime("%H%M") if value else "0000"


def _slot_code(slot: ScheduleSlot, index: int) -> str:
    """Encode one scheduled period in the underscore-separated form the
    timetable components parse: prefix, half, period, start, end, teacher,
    subject - exactly seven parts, with the subject last."""
    half = "MORNING" if (slot.start_time or time(0)) < LUNCH_START else "AFTERNOON"
    return f"SLOT_{half}_P{index}_{_hhmm(slot.start_time)}_{_hhmm(slot.end_time)}_{slot.teacher_id or 'NA'}_{slot.subject_code or 'NA'}"


def _exam_code(day: CalendarDay) -> str:
    """Encode an exam session. The subject part cannot contain underscores,
    so the exam type's spaces become hyphens."""
    label = (day.exam_type or "Exam").replace(" ", "-").replace("_", "-")
    return f"EXAM_{label}_{(day.exam_session or 'Morning').replace(' ', '-')}"


def _week_range(week_offset: int) -> tuple[date, date]:
    """Monday and Friday of the week `week_offset` weeks from this one."""
    today = date.today()
    monday = today - timedelta(days=today.weekday()) + timedelta(weeks=week_offset)
    return monday, monday + timedelta(days=4)


def _week_info(monday: date, friday: date, week_offset: int) -> dict:
    """The header the week navigation shows above the grid."""
    if week_offset == 0:
        label = "Current Week"
    else:
        label = f"Week of {monday.strftime('%d %b %Y')}"
    return {
        "weekLabel": label,
        "startDate": monday.isoformat(),
        "endDate": friday.isoformat(),
        "weekOffset": week_offset,
    }


def _day_payload(day: date, calendar: CalendarDay | None, slots: list[ScheduleSlot]) -> dict:
    """Build one row of the week grid.

    Returns the encoded morning/afternoon slot strings the student and admin
    views parse, plus a plain `periods` list the teacher view reads - both
    describe the same day, and shipping both keeps all three screens working
    off one endpoint.
    """
    day_type = calendar.day_type if calendar else "working"
    ordered = sorted(slots, key=lambda slot: slot.start_time or time(0))

    morning: list[str] = []
    afternoon: list[str] = []
    periods: list[dict] = []

    if day_type == "holiday":
        # Nothing is taught; the frontend renders the holiday name instead.
        pass
    elif day_type == "exam" and calendar:
        code = _exam_code(calendar)
        is_afternoon = (calendar.exam_session or "Morning").lower().startswith("afternoon")
        if is_afternoon:
            afternoon.append(code)
        else:
            morning.append(code)
        periods.append({
            "startTime": (LUNCH_END if is_afternoon else time(9, 0)).isoformat(),
            "endTime": (time(15, 40) if is_afternoon else LUNCH_START).isoformat(),
            "subjectCode": calendar.exam_type or "Exam",
            "classId": calendar.class_id,
            "isExam": True,
        })
    else:
        for index, slot in enumerate(ordered, start=1):
            code = _slot_code(slot, index)
            (morning if (slot.start_time or time(0)) < LUNCH_START else afternoon).append(code)
            periods.append({
                "startTime": slot.start_time.isoformat() if slot.start_time else None,
                "endTime": slot.end_time.isoformat() if slot.end_time else None,
                "subjectCode": slot.subject_code,
                "teacherId": slot.teacher_id,
                "classId": slot.class_id,
                "slotName": slot.slot_names,
                "isExam": False,
            })

    if day_type != "holiday":
        morning.append(LUNCH_SLOT)

    return {
        "calendar_date": day.isoformat(),
        "day_of_week": day.weekday() + 1,
        "day_name": DAY_NAMES[day.weekday()],
        "day_type": day_type,
        "holiday_name": calendar.holiday_name if calendar else None,
        "exam_type": calendar.exam_type if calendar else None,
        "exam_session": calendar.exam_session if calendar else None,
        "description": calendar.description if calendar else None,
        "morning_slots": morning,
        "afternoon_slots": afternoon,
        "periods": periods,
    }


def _build_week(
    session: Session,
    class_ids: list[int],
    academic_year: str,
    week_offset: int,
    teacher_id: str | None = None,
) -> dict:
    """Assemble a Monday-to-Friday week for one or more classes.

    Passing a teacher_id narrows the periods to the ones that teacher
    actually takes, which is what makes the teacher timetable differ from
    the class timetable.
    """
    monday, friday = _week_range(week_offset)

    # SQL: SELECT * FROM schedule_data WHERE classid IN :class_ids AND academicyear = :year AND isactive = true [AND teacherid = :teacher_id]
    slot_query = select(ScheduleSlot).where(
        ScheduleSlot.class_id.in_(class_ids),
        ScheduleSlot.academic_year == academic_year,
        ScheduleSlot.is_active.is_(True),
    )
    if teacher_id:
        slot_query = slot_query.where(ScheduleSlot.teacher_id == teacher_id)
    slots = session.execute(slot_query).scalars().all()

    # SQL: SELECT * FROM calendar_grid WHERE classid IN :class_ids AND calendardate BETWEEN :monday AND :friday
    calendar_rows = session.execute(
        select(CalendarDay).where(
            CalendarDay.class_id.in_(class_ids),
            CalendarDay.calendar_date >= monday,
            CalendarDay.calendar_date <= friday,
        )
    ).scalars().all()
    # One class drives the day type; for a teacher spanning several classes
    # the first row for that date is representative (holidays are school-wide).
    calendar_by_date = {row.calendar_date: row for row in calendar_rows}

    days = []
    for offset in range(5):
        day = monday + timedelta(days=offset)
        day_slots = [slot for slot in slots if slot.day_of_week == day.weekday() + 1]
        days.append(_day_payload(day, calendar_by_date.get(day), day_slots))

    return {"success": True, "data": days, "weekInfo": _week_info(monday, friday, week_offset)}


def _class_names(session: Session) -> dict[int, str]:
    """Class id -> "Grade 10 - A", for labelling exams and holidays."""
    # SQL: SELECT * FROM classes
    return {row.class_id: row.display_name for row in session.execute(select(SchoolClass)).scalars().all()}


def _subject_names(session: Session) -> dict[str, str]:
    """Subject code -> "Mathematics", for naming the subjects sat in an exam."""
    # SQL: SELECT subjectcode, subjectname FROM subjects
    rows = session.execute(select(Subject.subject_code, Subject.subject_name)).all()
    return {code: name for code, name in rows}


def _exam_details(day: CalendarDay, subject_names: dict[str, str]) -> list[dict]:
    """Split an exam's stored subject list into one row per subject.

    The exam tables render a pill per subject, so this has to be a list of
    objects rather than the raw text. An entry that is not a known subject
    code is shown as written.
    """
    if day.day_type != "exam":
        return []
    afternoon = (day.exam_session or "").lower().startswith("afternoon")
    time_slot = "13:00 - 16:00" if afternoon else "09:00 - 12:00"
    details = []
    for part in re.split(r"[,;]| and ", day.description or ""):
        code = part.strip()
        if code:
            details.append({
                "subject": code,
                "subjectCode": code,
                "subjectName": subject_names.get(code, code),
                "timeSlot": time_slot,
            })
    return details


def _event_payload(day: CalendarDay, class_name: str, subject_names: dict[str, str]) -> dict:
    """Shape one calendar entry the way the exam and holiday screens read it."""
    details = _exam_details(day, subject_names)
    return {
        "id": day.grid_id,
        "classId": day.class_id,
        "className": class_name,
        "date": day.calendar_date.isoformat(),
        "dayName": DAY_NAMES[day.calendar_date.weekday()],
        "academicYear": day.academic_year,
        # Exam fields
        "examType": day.exam_type,
        "examSession": day.exam_session,
        "examDetails": details,
        "totalSubjects": len(details),
        # Holiday fields (name/holidayName are both read, depending on screen)
        "holidayName": day.holiday_name,
        "name": day.holiday_name,
        "description": day.description,
        "type": day.day_type,
        "startDate": day.calendar_date.isoformat(),
        "endDate": day.calendar_date.isoformat(),
        "duration": "half_day" if day.day_type == "half_holiday" else "full_day",
    }


def _events(session: Session, rows: list[CalendarDay]) -> list[dict]:
    """Shape a batch of calendar rows, resolving the name lookups just once."""
    names, subjects = _class_names(session), _subject_names(session)
    return [_event_payload(row, names.get(row.class_id, ""), subjects) for row in rows]


def _upcoming(session: Session, day_type: str, class_id: str) -> dict:
    """Events of one type from today onwards, for one class or all of them."""
    # SQL: SELECT * FROM calendar_grid WHERE daytype = :day_type AND calendardate >= CURRENT_DATE [AND classid = :class_id] ORDER BY calendardate
    statement = select(CalendarDay).where(
        CalendarDay.day_type == day_type,
        CalendarDay.calendar_date >= date.today(),
    )
    if class_id != "all":
        statement = statement.where(CalendarDay.class_id == int(class_id))
    rows = session.execute(statement.order_by(CalendarDay.calendar_date)).scalars().all()

    return {"success": True, "data": _events(session, rows)}


def _target_class_ids(session: Session, class_id) -> list[int]:
    """Resolve a classId of "all" to every class id; otherwise just that one."""
    if str(class_id).lower() in ("all", "", "none"):
        # SQL: SELECT classid FROM classes
        return list(session.execute(select(SchoolClass.class_id)).scalars().all())
    return [int(class_id)]


# --- Weekly grids -----------------------------------------------------------

@router.get("/timemanagement/calendar-week/{class_id}/{academic_year}/{week_offset}")
def class_week(class_id: int, academic_year: str, week_offset: int, session: Session = Depends(get_session), user=Depends(current_user)):
    """The week grid for one class, used by the admin time management screen."""
    return _build_week(session, [class_id], academic_year, week_offset)


@router.get("/timemanagement/student-calendar-week/{student_id}/{academic_year}/{week_offset}")
def student_week(student_id: str, academic_year: str, week_offset: int, session: Session = Depends(get_session), user=Depends(current_user)):
    """The week grid for a student, resolved through the class they are in."""
    # SQL: SELECT * FROM students WHERE studentid = :student_id
    student = session.get(Student, student_id)
    if not student:
        raise HTTPException(404, "Student not found")
    if not student.class_id:
        return {"success": True, "data": [], "weekInfo": _week_info(*_week_range(week_offset), week_offset)}
    return _build_week(session, [student.class_id], academic_year, week_offset)


@router.get("/timemanagement/teacher-calendar-week/{teacher_id}/{academic_year}/{week_offset}")
def teacher_week(teacher_id: str, academic_year: str, week_offset: int, session: Session = Depends(get_session), user=Depends(current_user)):
    """The week grid for a teacher: their periods across every class they teach."""
    # SQL: SELECT * FROM teachers WHERE teacherid = :teacher_id
    teacher = session.get(Teacher, teacher_id)
    if not teacher:
        raise HTTPException(404, "Teacher not found")
    # SQL: SELECT classid FROM classes
    class_ids = list(session.execute(select(SchoolClass.class_id)).scalars().all())
    return _build_week(session, class_ids, academic_year, week_offset, teacher_id=teacher_id)


# --- Recurring schedule -----------------------------------------------------

@router.get("/timemanagement/schedule/{academic_year}")
def all_schedules(academic_year: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Every scheduled period for an academic year."""
    # SQL: SELECT * FROM schedule_data WHERE academicyear = :year ORDER BY classid, dayofweek, starttime
    rows = session.execute(
        select(ScheduleSlot).where(ScheduleSlot.academic_year == academic_year)
        .order_by(ScheduleSlot.class_id, ScheduleSlot.day_of_week, ScheduleSlot.start_time)
    ).scalars().all()
    records = [row.to_dict() for row in rows]
    return {"success": True, "data": records, "schedules": records}


@router.get("/timemanagement/class-schedule/{class_id}/{academic_year}")
def class_schedule(class_id: int, academic_year: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """One class's recurring weekly timetable."""
    # SQL: SELECT * FROM schedule_data WHERE classid = :class_id AND academicyear = :year ORDER BY dayofweek, starttime
    rows = session.execute(
        select(ScheduleSlot).where(ScheduleSlot.class_id == class_id, ScheduleSlot.academic_year == academic_year)
        .order_by(ScheduleSlot.day_of_week, ScheduleSlot.start_time)
    ).scalars().all()
    records = [row.to_dict() for row in rows]
    return {"success": True, "data": records, "schedules": records}


@router.get("/timemanagement/teacher-schedule/{teacher_id}/{academic_year}")
def teacher_schedule(teacher_id: str, academic_year: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Every period one teacher takes, across all their classes."""
    # SQL: SELECT * FROM schedule_data WHERE teacherid = :teacher_id AND academicyear = :year ORDER BY dayofweek, starttime
    rows = session.execute(
        select(ScheduleSlot).where(ScheduleSlot.teacher_id == teacher_id, ScheduleSlot.academic_year == academic_year)
        .order_by(ScheduleSlot.day_of_week, ScheduleSlot.start_time)
    ).scalars().all()
    records = [row.to_dict() for row in rows]
    return {"success": True, "data": records, "schedules": records}


@router.post("/timemanagement/schedule", status_code=201)
def create_schedule(body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Add one period to the recurring weekly timetable."""
    slot = ScheduleSlot()
    slot.apply(body.model_dump())
    slot.schedule_id = slot.schedule_id or str(uuid.uuid4())
    slot.academic_year = slot.academic_year or "2024-2025"
    if slot.is_active is None:
        slot.is_active = True
    # SQL: INSERT INTO schedule_data (...) VALUES (...)
    session.add(slot)
    session.commit()
    return {"success": True, "message": "Schedule entry created", "data": slot.to_dict()}


@router.put("/timemanagement/schedule/{schedule_id}")
def update_schedule(schedule_id: str, body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Change one period of the recurring weekly timetable."""
    # SQL: SELECT * FROM schedule_data WHERE scheduleid = :schedule_id
    slot = session.get(ScheduleSlot, schedule_id)
    if not slot:
        raise HTTPException(404, "Schedule entry not found")
    # SQL: UPDATE schedule_data SET <supplied columns> WHERE scheduleid = :schedule_id
    slot.apply(body.model_dump(), skip={"schedule_id"})
    session.commit()
    return {"success": True, "message": "Schedule entry updated", "data": slot.to_dict()}


@router.delete("/timemanagement/schedule/{schedule_id}")
def delete_schedule(schedule_id: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Remove one period from the recurring weekly timetable."""
    # SQL: SELECT * FROM schedule_data WHERE scheduleid = :schedule_id
    slot = session.get(ScheduleSlot, schedule_id)
    if not slot:
        raise HTTPException(404, "Schedule entry not found")
    # SQL: DELETE FROM schedule_data WHERE scheduleid = :schedule_id
    session.delete(slot)
    session.commit()
    return {"success": True, "message": "Schedule entry deleted"}


# --- Calendar grid ----------------------------------------------------------

@router.get("/timemanagement/calendar/{academic_year}")
def calendar_grid(academic_year: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Every calendar day recorded for an academic year."""
    # SQL: SELECT * FROM calendar_grid WHERE academicyear = :year ORDER BY calendardate
    rows = session.execute(
        select(CalendarDay).where(CalendarDay.academic_year == academic_year).order_by(CalendarDay.calendar_date)
    ).scalars().all()
    records = [row.to_dict() for row in rows]
    return {"success": True, "data": records, "calendar": records}


@router.get("/timemanagement/calendar-slots/{class_id}/{day}")
def calendar_slots(class_id: int, day: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """What one class is doing on one specific date."""
    try:
        target = date.fromisoformat(day[:10])
    except ValueError as error:
        raise HTTPException(422, "date must be in YYYY-MM-DD format") from error

    # SQL: SELECT * FROM calendar_grid WHERE classid = :class_id AND calendardate = :target
    calendar = session.execute(
        select(CalendarDay).where(CalendarDay.class_id == class_id, CalendarDay.calendar_date == target)
    ).scalar_one_or_none()
    # SQL: SELECT * FROM schedule_data WHERE classid = :class_id AND dayofweek = :weekday AND isactive = true ORDER BY starttime
    slots = session.execute(
        select(ScheduleSlot).where(
            ScheduleSlot.class_id == class_id,
            ScheduleSlot.day_of_week == target.weekday() + 1,
            ScheduleSlot.is_active.is_(True),
        ).order_by(ScheduleSlot.start_time)
    ).scalars().all()

    payload = _day_payload(target, calendar, slots)
    return {"success": True, "data": payload, "slots": payload["periods"]}


# --- Exams ------------------------------------------------------------------

@router.get("/timemanagement/exams")
def list_exams(session: Session = Depends(get_session), user=Depends(current_user)):
    """Every exam session on the calendar, past and future."""
    # SQL: SELECT * FROM calendar_grid WHERE daytype = 'exam' ORDER BY calendardate
    rows = session.execute(
        select(CalendarDay).where(CalendarDay.day_type == "exam").order_by(CalendarDay.calendar_date)
    ).scalars().all()
    records = _events(session, rows)
    return {"success": True, "data": records, "exams": records}


@router.get("/timemanagement/upcoming-exams/{class_id}")
def upcoming_exams(class_id: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Exams from today onwards; pass "all" for every class."""
    return _upcoming(session, "exam", class_id)


@router.post("/timemanagement/exams", status_code=201)
def create_exams(body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Schedule an exam, one calendar day per session.

    The admin screen submits a whole exam at once - a type plus a list of
    sessions, each with its date, subject and class - so this writes or
    updates one calendar day per (class, date) pair and reports the total.
    """
    data = body.model_dump()
    exam_type = data.get("examType") or "Exam"
    academic_year = data.get("academicYear") or "2024-2025"
    sessions = data.get("examSessions") or []
    if not sessions:
        raise HTTPException(422, "examSessions must contain at least one session")

    created = 0
    for entry in sessions:
        if not entry.get("date"):
            continue
        target = date.fromisoformat(str(entry["date"])[:10])
        for class_id in _target_class_ids(session, entry.get("classId", "all")):
            # SQL: SELECT * FROM calendar_grid WHERE classid = :class_id AND calendardate = :target
            day = session.execute(
                select(CalendarDay).where(CalendarDay.class_id == class_id, CalendarDay.calendar_date == target)
            ).scalar_one_or_none()
            if not day:
                day = CalendarDay(
                    grid_id=f"cal-{class_id}-{target.isoformat()}", class_id=class_id,
                    calendar_date=target, academic_year=academic_year,
                )
                # SQL: INSERT INTO calendar_grid (...) VALUES (...)
                session.add(day)
            # SQL: UPDATE calendar_grid SET daytype='exam', examtype=..., examsession=..., description=... WHERE gridid = :grid_id
            day.day_type = "exam"
            day.exam_type = exam_type
            day.exam_session = entry.get("session") or entry.get("examSession") or "Morning"
            day.description = entry.get("subjectCode") or entry.get("description") or exam_type
            created += 1
    session.commit()
    return {"success": True, "message": "Exam schedule saved", "totalSessions": created, "data": {"totalSessions": created}}


@router.put("/timemanagement/exam/{exam_id}")
def update_exam(exam_id: str, body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Edit one scheduled exam session."""
    # SQL: SELECT * FROM calendar_grid WHERE gridid = :exam_id
    day = session.get(CalendarDay, exam_id)
    if not day or day.day_type != "exam":
        raise HTTPException(404, "Exam not found")
    data = body.model_dump()
    if data.get("examType"):
        day.exam_type = data["examType"]
    if data.get("session") or data.get("examSession"):
        day.exam_session = data.get("session") or data.get("examSession")
    # The admin edit modal sends examDetails back as the same list of subject
    # rows it was given, so flatten it to the comma-separated codes we store.
    details = data.get("examDetails")
    if isinstance(details, list):
        codes = [str(item.get("subjectCode") or item.get("subject") or "").strip()
                 for item in details if isinstance(item, dict)]
        day.description = ",".join(code for code in codes if code)
    elif data.get("subjectCode") or details or data.get("description"):
        day.description = data.get("subjectCode") or details or data.get("description")
    session.commit()
    return {"success": True, "message": "Exam updated", "data": _events(session, [day])[0]}


@router.delete("/timemanagement/exam/{exam_id}")
def delete_exam(exam_id: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Cancel an exam session, returning that date to a normal working day."""
    # SQL: SELECT * FROM calendar_grid WHERE gridid = :exam_id
    day = session.get(CalendarDay, exam_id)
    if not day or day.day_type != "exam":
        raise HTTPException(404, "Exam not found")
    # SQL: UPDATE calendar_grid SET daytype='working', examtype=NULL, examsession=NULL, description=NULL WHERE gridid = :exam_id
    day.day_type, day.exam_type, day.exam_session, day.description = "working", None, None, None
    session.commit()
    return {"success": True, "message": "Exam schedule deleted"}


# --- Holidays ---------------------------------------------------------------

@router.get("/timemanagement/holidays")
def list_holidays(session: Session = Depends(get_session), user=Depends(current_user)):
    """Every holiday on the calendar, past and future."""
    # SQL: SELECT * FROM calendar_grid WHERE daytype IN ('holiday','half_holiday') ORDER BY calendardate
    rows = session.execute(
        select(CalendarDay).where(CalendarDay.day_type.in_(("holiday", "half_holiday")))
        .order_by(CalendarDay.calendar_date)
    ).scalars().all()
    records = _events(session, rows)
    return {"success": True, "data": records, "holidays": records}


@router.get("/timemanagement/upcoming-holidays/{class_id}")
def upcoming_holidays(class_id: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Holidays from today onwards; pass "all" for every class."""
    return _upcoming(session, "holiday", class_id)


@router.post("/timemanagement/holidays", status_code=201)
def create_holidays(body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Declare one or more holidays.

    A holiday can span a date range and apply to every class, so the single
    request the admin screen sends can expand into many calendar days.
    """
    data = body.model_dump()
    entries = data.get("holidays") or [data]

    created = 0
    for entry in entries:
        start_value = entry.get("startDate") or entry.get("date")
        if not start_value:
            continue
        start = date.fromisoformat(str(start_value)[:10])
        end = date.fromisoformat(str(entry.get("endDate") or start_value)[:10])
        if end < start:
            start, end = end, start
        day_type = "half_holiday" if entry.get("duration") == "half_day" else "holiday"
        academic_year = entry.get("academicYear") or "2024-2025"

        for class_id in _target_class_ids(session, entry.get("classId", "all")):
            for offset in range((end - start).days + 1):
                target = start + timedelta(days=offset)
                # SQL: SELECT * FROM calendar_grid WHERE classid = :class_id AND calendardate = :target
                day = session.execute(
                    select(CalendarDay).where(CalendarDay.class_id == class_id, CalendarDay.calendar_date == target)
                ).scalar_one_or_none()
                if not day:
                    day = CalendarDay(
                        grid_id=f"cal-{class_id}-{target.isoformat()}", class_id=class_id,
                        calendar_date=target, academic_year=academic_year,
                    )
                    # SQL: INSERT INTO calendar_grid (...) VALUES (...)
                    session.add(day)
                # SQL: UPDATE calendar_grid SET daytype = :day_type, holidayname = ..., description = ... WHERE gridid = :grid_id
                day.day_type = day_type
                day.holiday_name = entry.get("holidayName") or entry.get("name") or "Holiday"
                day.description = entry.get("description") or day.holiday_name
                created += 1
    session.commit()
    return {"success": True, "message": "Holiday saved", "totalDays": created, "data": {"totalDays": created}}


@router.put("/timemanagement/holiday/{holiday_id}")
def update_holiday(holiday_id: str, body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Rename or re-describe an existing holiday."""
    # SQL: SELECT * FROM calendar_grid WHERE gridid = :holiday_id
    day = session.get(CalendarDay, holiday_id)
    if not day or day.day_type not in ("holiday", "half_holiday"):
        raise HTTPException(404, "Holiday not found")
    data = body.model_dump()
    if data.get("holidayName") or data.get("name"):
        day.holiday_name = data.get("holidayName") or data.get("name")
    if data.get("description"):
        day.description = data["description"]
    if data.get("duration"):
        day.day_type = "half_holiday" if data["duration"] == "half_day" else "holiday"
    session.commit()
    return {"success": True, "message": "Holiday updated", "data": _events(session, [day])[0]}


@router.delete("/timemanagement/holiday/{holiday_id}")
def delete_holiday(holiday_id: str, session: Session = Depends(get_session), user=Depends(current_user)):
    """Cancel a holiday, returning that date to a normal working day."""
    # SQL: SELECT * FROM calendar_grid WHERE gridid = :holiday_id
    day = session.get(CalendarDay, holiday_id)
    if not day or day.day_type not in ("holiday", "half_holiday"):
        raise HTTPException(404, "Holiday not found")
    # SQL: UPDATE calendar_grid SET daytype='working', holidayname=NULL, description=NULL WHERE gridid = :holiday_id
    day.day_type, day.holiday_name, day.description = "working", None, None
    session.commit()
    return {"success": True, "message": "Holiday deleted"}


# --- Academic calendar (legacy /api/calendar routes) ------------------------

@router.get("/calendar")
def academic_calendar(session: Session = Depends(get_session), user=Depends(current_user)):
    """The academic calendar: every non-working day, newest first.

    This is the older endpoint the calendar page still calls; it is the same
    data as /timemanagement/calendar, filtered to the days worth showing.
    """
    # SQL: SELECT * FROM calendar_grid WHERE daytype <> 'working' ORDER BY calendardate
    rows = session.execute(
        select(CalendarDay).where(CalendarDay.day_type != "working").order_by(CalendarDay.calendar_date)
    ).scalars().all()
    records = _events(session, rows)
    return {"success": True, "data": records, "calendar": records}


@router.post("/calendar", status_code=201)
def create_calendar_entry(body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Add one entry to the academic calendar."""
    data = body.model_dump()
    if not data.get("date") and not data.get("calendarDate"):
        raise HTTPException(422, "date is required")
    target = date.fromisoformat(str(data.get("date") or data.get("calendarDate"))[:10])

    day = CalendarDay(
        grid_id=str(uuid.uuid4()),
        class_id=int(data.get("classId") or _target_class_ids(session, "all")[0]),
        calendar_date=target,
        academic_year=data.get("academicYear") or "2024-2025",
        day_type=data.get("type") or data.get("dayType") or "holiday",
        holiday_name=data.get("holidayName") or data.get("name"),
        description=data.get("description"),
    )
    # SQL: INSERT INTO calendar_grid (...) VALUES (...)
    session.add(day)
    session.commit()
    return {"success": True, "message": "Calendar entry created", "data": _events(session, [day])[0]}


@router.put("/calendar/{calendar_id}")
def update_calendar_entry(calendar_id: str, body: Payload, session: Session = Depends(get_session), user=Depends(current_user)):
    """Edit one academic calendar entry."""
    # SQL: SELECT * FROM calendar_grid WHERE gridid = :calendar_id
    day = session.get(CalendarDay, calendar_id)
    if not day:
        raise HTTPException(404, "Calendar entry not found")
    data = body.model_dump()
    if data.get("holidayName") or data.get("name"):
        day.holiday_name = data.get("holidayName") or data.get("name")
    if data.get("description"):
        day.description = data["description"]
    if data.get("type") or data.get("dayType"):
        day.day_type = data.get("type") or data.get("dayType")
    session.commit()
    return {"success": True, "message": "Calendar entry updated", "data": _events(session, [day])[0]}
