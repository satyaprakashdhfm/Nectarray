"""The HTTP layer, one module per group of endpoints.

Import order matters and is enforced in main.py: the specific routers are
registered before resources.py, whose catch-all /api/{resource} routes would
otherwise swallow paths like /api/calendar or /api/reactivation/deactivated.
"""
from app.routers import auth, health, reactivation, resources, statistics, timetable

__all__ = ["auth", "health", "reactivation", "resources", "statistics", "timetable"]
