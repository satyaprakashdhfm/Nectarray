"""Login, registration and session endpoints under /api/auth.

This module only issues sessions and reports who the caller is; verifying a
token on subsequent requests is app/security/dependencies.py's job.
"""
from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.database import get_session
from app.models import Student, Teacher, User
from app.schemas import LoginRequest, RegisterRequest
from app.security import create_token, current_user, hash_password, verify_password

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

# Shown under the login route so the role field is visible without having to
# run the request first.
LOGIN_EXAMPLE = {
    "success": True,
    "message": "Login successful",
    "token": "eyJzdWIiOiJ0ZWFjaGVyMSIsInJvbGUiOiJ0ZWFjaGVyIiwiZXhwIjoxNzkwMDAwMDAwfQ.T0tFTg",
    "user": {
        "username": "teacher1",
        "email": "teacher@example.com",
        "firstName": "Anita",
        "lastName": "Sharma",
        "role": "teacher",
        "active": True,
        "lastLogin": "2026-09-20T06:11:00.184621+00:00",
        "createdAt": "2026-09-20T05:19:19.631695",
        "teacher": {"teacherId": "teacher1", "name": "Anita Sharma", "classesAssigned": ["1", "2", "3"]},
    },
}


def _profile_for(session: Session, user: User) -> dict | None:
    """Load the teacher or student row that belongs to this account.

    The frontend reads user.teacher.classesAssigned / user.student.classId
    straight off the login response to decide what the dashboard shows, so
    the profile has to travel with the user object.
    """
    if user.role == "teacher":
        # SQL: SELECT * FROM teachers WHERE teacherid = :username
        profile = session.get(Teacher, user.username)
    elif user.role == "student":
        # SQL: SELECT * FROM students WHERE studentid = :username
        profile = session.get(Student, user.username)
    else:
        return None
    return profile.to_dict() if profile else None


@router.post(
    "/login",
    summary="Log in and get a session token",
    responses={200: {"description": "Signed in", "content": {"application/json": {"example": LOGIN_EXAMPLE}}}},
)
def login(body: LoginRequest, session: Session = Depends(get_session)):
    """Verify credentials, stamp lastLogin, and return a token plus the profile.

    The `token` in the response is what the **Authorize** button at the top of
    this page wants. The `user.role` field says whether the account is an
    `admin`, a `teacher` or a `student`, and decides which screens the app
    shows; a teacher or student also gets their full profile nested under
    `user.teacher` / `user.student`.

    Deactivated accounts get the same generic message as a wrong password, so
    the response cannot be used to probe which usernames exist.
    """
    # SQL: SELECT * FROM users WHERE username = :username
    user = session.get(User, body.username)
    if not user or not user.active or not verify_password(body.password, user.password):
        raise HTTPException(401, "Invalid username or password")

    user.last_login = datetime.now(timezone.utc)
    session.commit()

    public_user = user.public()
    profile = _profile_for(session, user)
    if profile:
        public_user[user.role] = profile
    return {
        "success": True,
        "message": "Login successful",
        "token": create_token(user.username, user.role),
        "user": public_user,
    }


@router.post("/register", status_code=201, summary="Create an account and log it in")
def register(body: RegisterRequest, session: Session = Depends(get_session)):
    """Create a new account (defaulting to the student role) and log it in.

    This only creates the login. A teacher or student also needs their profile
    row, which the admin screens create through /api/teachers or /api/students.
    """
    # SQL: SELECT * FROM users WHERE username = :username OR email = :email
    clash = session.execute(
        select(User).where(or_(User.username == body.username, User.email == body.email))
    ).scalar_one_or_none()
    if clash:
        raise HTTPException(409, "Username or email already exists")

    user = User(
        username=body.username,
        email=body.email,
        password=hash_password(body.password),
        first_name=body.firstName,
        last_name=body.lastName,
        role=body.role,
        active=True,
        created_at=datetime.now(timezone.utc),
    )
    session.add(user)
    session.commit()
    return {
        "success": True,
        "token": create_token(user.username, user.role),
        "user": user.public(),
        "message": "User registered successfully",
    }


@router.get("/profile", summary="Who the current token belongs to")
def profile(user: User = Depends(current_user), session: Session = Depends(get_session)):
    """Return the caller's own account, resolved from their bearer token.

    Handy after authorizing on this page: it answers which account the pasted
    token belongs to and what role it has.
    """
    public_user = user.public()
    linked = _profile_for(session, user)
    if linked:
        public_user[user.role] = linked
    return {"success": True, "user": public_user}


@router.post("/logout", summary="End the session (client-side only)")
def logout(user: User = Depends(current_user)):
    """No-op: tokens are stateless and expire on their own, so there is
    nothing to invalidate server-side. It exists so the frontend's logout
    flow gets a 200 instead of a 404."""
    return {"success": True, "message": "Logged out successfully"}
