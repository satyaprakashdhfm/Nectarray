"""SQLAlchemy engine and Session plumbing - the only place that opens
connections, so nothing else in the app has to know how the DB is reached.

Two ways to get a Session:
  * `Depends(get_session)` inside a route - FastAPI closes it for you.
  * `with session_scope() as session:` anywhere else (startup, seeding).
"""
from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.config import DATABASE_URL, IS_SQLITE
from app.models import Base

# check_same_thread is a SQLite-only guard that would otherwise reject the
# connections uvicorn's threadpool hands to sync route functions.
engine = create_engine(
    DATABASE_URL,
    future=True,
    pool_pre_ping=True,
    connect_args={"check_same_thread": False} if IS_SQLITE else {},
)

# expire_on_commit=False keeps loaded rows readable after commit(), so routes
# can serialise the object they just saved without a second SELECT.
SessionFactory = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, future=True)


def get_session() -> Iterator[Session]:
    """FastAPI dependency yielding a request-scoped Session.

    Routes commit explicitly; this only guarantees a failed request rolls
    back and that the connection always returns to the pool.
    """
    session = SessionFactory()
    try:
        yield session
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


@contextmanager
def session_scope() -> Iterator[Session]:
    """Session for code outside a request (seeding, scripts): commits on
    success, rolls back on error, always closes."""
    session = SessionFactory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def create_tables() -> None:
    """Create any missing tables from the ORM models.

    This is what makes SQLite zero-config: no migration step, the schema is
    whatever app/models declares. PostgreSQL users can instead run
    database/postgresql_starter.sql, which declares the same tables.
    """
    # SQL: CREATE TABLE IF NOT EXISTS <every table in app/models>
    Base.metadata.create_all(engine)
