"""The demo dataset written into an empty database on first run.

Why this exists: the app is meant to be cloned and started with no setup, and
empty dashboards look broken. Seeding a small but complete school - 3 classes,
3 teachers, 12 students, a week of attendance, two exams, fees, syllabus
progress and a full timetable - makes every screen render real data at once.

The same dataset is mirrored in database/postgresql_starter.sql, so switching
to PostgreSQL gives you the identical demo school.

Seeding runs group by group and skips any group that already has rows, so it
is safe on every startup and can top up an older database without touching
anything you have entered yourself.
"""
from __future__ import annotations

import random
from datetime import date, datetime, time, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models import (
    Attendance,
    CalendarDay,
    Fee,
    Mark,
    ScheduleSlot,
    SchoolClass,
    Student,
    Subject,
    Syllabus,
    Teacher,
    User,
)

ACADEMIC_YEAR = "2024-2025"

# --- The cast of the demo school -------------------------------------------
# (id, name, email, phone, qualification, subjects, classes, class teacher of, hired, salary)
TEACHERS = [
    ("teacher1", "Anita Sharma", "teacher@example.com", "9876543210", "M.Sc. Mathematics", ["MAT10"], ["1", "2", "3"], "Grade 9 - A", "2023-06-01", 45000),
    ("teacher2", "Rohan Mehta", "teacher2@example.com", "9876543212", "M.Sc. Physics", ["SCI10", "CS10"], ["1", "2", "3"], "Grade 10 - A", "2022-04-10", 48000),
    ("teacher3", "Priya Nair", "teacher3@example.com", "9876543213", "M.A. English", ["ENG10", "SOC10"], ["1", "2", "3"], "Grade 10 - B", "2021-07-15", 46000),
]
CLASSES = [
    (1, "Grade 9", "A", 40, "teacher1"),
    (2, "Grade 10", "A", 40, "teacher2"),
    (3, "Grade 10", "B", 40, "teacher3"),
]
SUBJECTS = [
    ("MAT10", "Mathematics", "Grade 9,Grade 10", 100),
    ("SCI10", "Science", "Grade 9,Grade 10", 100),
    ("ENG10", "English", "Grade 9,Grade 10", 100),
    ("SOC10", "Social Studies", "Grade 9,Grade 10", 100),
    ("CS10", "Computer Science", "Grade 9,Grade 10", 100),
]
STUDENTS = [
    ("student1", "Aarav Patel", "student@example.com", "9876543211", "Pune", "2008-05-14", "Ravi Patel", "Meera Patel", 1, "active"),
    ("student2", "Diya Sharma", "student2@example.com", "9876543221", "Pune", "2008-08-21", "Sanjay Sharma", "Neha Sharma", 1, "active"),
    ("student3", "Kabir Singh", "student3@example.com", "9876543222", "Mumbai", "2008-02-02", "Manpreet Singh", "Simran Kaur", 1, "active"),
    ("student4", "Ishita Rao", "student4@example.com", "9876543223", "Pune", "2008-11-30", "Suresh Rao", "Lakshmi Rao", 1, "active"),
    ("student5", "Vivaan Gupta", "student5@example.com", "9876543224", "Delhi", "2007-06-18", "Anil Gupta", "Pooja Gupta", 2, "active"),
    ("student6", "Ananya Iyer", "student6@example.com", "9876543225", "Chennai", "2007-09-09", "Krishnan Iyer", "Divya Iyer", 2, "active"),
    ("student7", "Reyansh Kumar", "student7@example.com", "9876543226", "Delhi", "2007-01-27", "Rakesh Kumar", "Sunita Kumar", 2, "active"),
    ("student8", "Saanvi Joshi", "student8@example.com", "9876543227", "Nashik", "2007-04-12", "Mahesh Joshi", "Kavita Joshi", 2, "active"),
    ("student9", "Arjun Reddy", "student9@example.com", "9876543228", "Hyderabad", "2007-07-07", "Srinivas Reddy", "Padma Reddy", 3, "active"),
    ("student10", "Myra Verma", "student10@example.com", "9876543229", "Hyderabad", "2007-03-15", "Ashok Verma", "Ritu Verma", 3, "active"),
    ("student11", "Aditya Nair", "student11@example.com", "9876543230", "Bengaluru", "2007-10-05", "Vijay Nair", "Geetha Nair", 3, "active"),
    ("student12", "Kiara Menon", "student12@example.com", "9876543231", "Bengaluru", "2007-12-23", "Suresh Menon", "Anju Menon", 3, "inactive"),
]

# Each class's home subject, used for the attendance register and marks.
CORE_SUBJECT_BY_CLASS = {1: ("MAT10", "teacher1"), 2: ("SCI10", "teacher2"), 3: ("ENG10", "teacher3")}
ATTENDANCE_PATTERN = ["present", "present", "present", "absent", "present", "late", "present"]

# --- The school day ---------------------------------------------------------
# The frontend renders these exact ten columns, so the times here must match
# the timeSlots array in the timetable components.
PERIODS = [
    ("Period 1", time(9, 0), time(9, 40)),
    ("Period 2", time(9, 40), time(10, 20)),
    ("Period 3", time(10, 20), time(11, 0)),
    ("Period 4", time(11, 0), time(11, 40)),
    ("Lunch Break", time(11, 40), time(12, 20)),
    ("Period 5", time(12, 20), time(13, 0)),
    ("Period 6", time(13, 0), time(13, 40)),
    ("Period 7", time(13, 40), time(14, 20)),
    ("Period 8", time(14, 20), time(15, 0)),
    ("Period 9", time(15, 0), time(15, 40)),
]
LUNCH_INDEX = 4
# Who teaches what, rotated across the week so every class sees every subject.
TEACHING_STAFF = [
    ("MAT10", "teacher1"),
    ("SCI10", "teacher2"),
    ("ENG10", "teacher3"),
    ("SOC10", "teacher3"),
    ("CS10", "teacher2"),
]

# The calendar is generated around today so the demo always has recent history
# and upcoming events, whatever date the project is cloned on.
CALENDAR_DAYS_BACK = 35
CALENDAR_DAYS_AHEAD = 120
# (days from today, name, description)
HOLIDAYS = [
    (-21, "Independence Day", "National holiday - school closed"),
    (-7, "Staff Development Day", "No classes; teacher training in progress"),
    (9, "Autumn Break", "Mid-term break for all classes"),
    (23, "Founders Day", "School foundation day celebrations"),
    (47, "Winter Break", "Winter vacation begins"),
    (76, "Annual Sports Day", "Inter-house athletics meet; no regular classes"),
]
# (days from today, exam type, session, subject codes sat that session)
EXAMS = [
    (-10, "Unit Test 1", "Morning", ["MAT10", "SCI10"]),
    (14, "Unit Test 2", "Morning", ["MAT10", "SCI10", "ENG10"]),
    (15, "Unit Test 2", "Morning", ["SOC10", "CS10"]),
    (38, "Mid Term", "Morning", ["MAT10", "SCI10", "ENG10"]),
    (39, "Mid Term", "Afternoon", ["SOC10", "CS10"]),
]


def _is_empty(session: Session, model) -> bool:
    """True when a table has no rows yet, i.e. its group still needs seeding."""
    # SQL: SELECT COUNT(*) FROM <table>
    return not session.execute(select(func.count()).select_from(model)).scalar()


def _weekday_on_or_after(day: date) -> date:
    """Nudge a generated event off the weekend, since the timetable grid only
    shows Monday to Friday and a Saturday event would be invisible."""
    while day.weekday() > 4:
        day += timedelta(days=1)
    return day


def seed_demo_data(session: Session) -> dict[str, int]:
    """Fill any empty part of the database with the demo school.

    Returns a count per group actually inserted, which startup logs so you can
    see at a glance whether this run seeded anything.
    """
    random.seed(42)
    inserted: dict[str, int] = {}
    today = date.today()
    now = datetime.now(timezone.utc)

    if _is_empty(session, User):
        inserted.update(_seed_people(session, now))
        inserted.update(_seed_records(session, today, now))
    if _is_empty(session, ScheduleSlot):
        inserted.update(_seed_timetable(session))
    if _is_empty(session, CalendarDay):
        inserted.update(_seed_calendar(session, today))

    session.commit()
    return inserted


def _seed_people(session: Session, now: datetime) -> dict[str, int]:
    """Insert the accounts, classes, subjects, teachers and students.

    Every teacher and student also gets a users row with the same id, because
    that id is what they log in with.
    """
    from app.security.passwords import hash_password

    def account(username: str, email: str, password: str, full_name: str, role: str) -> User:
        first, _, last = full_name.partition(" ")
        return User(
            username=username, email=email, password=hash_password(password),
            first_name=first, last_name=last, role=role, active=True, created_at=now,
        )

    # SQL: INSERT INTO users (username, email, password, firstname, lastname, role, active, createdat) VALUES ...
    session.add(account("admin", "admin@example.com", "admin123", "System Admin", "admin"))
    session.add_all(account(row[0], row[2], "teacher123", row[1], "teacher") for row in TEACHERS)
    session.add_all(account(row[0], row[2], "student123", row[1], "student") for row in STUDENTS)

    # SQL: INSERT INTO teachers (teacherid, name, email, phonenumber, qualification, subjectshandled, classesassigned, classteacherof, hiredate, salary, active) VALUES ...
    session.add_all(
        Teacher(
            teacher_id=teacher_id, name=name, email=email, phone_number=phone,
            qualification=qualification, subjects_handled=subjects, classes_assigned=classes,
            class_teacher_of=class_teacher_of, hire_date=date.fromisoformat(hired),
            salary=salary, active=True,
        )
        for teacher_id, name, email, phone, qualification, subjects, classes, class_teacher_of, hired, salary in TEACHERS
    )
    # SQL: INSERT INTO classes (classid, classname, section, academicyear, maxstudents, classteacherid, active) VALUES ...
    session.add_all(
        SchoolClass(
            class_id=class_id, class_name=class_name, section=section, academic_year=ACADEMIC_YEAR,
            max_students=max_students, class_teacher_id=teacher_id, active=True,
        )
        for class_id, class_name, section, max_students, teacher_id in CLASSES
    )
    # SQL: INSERT INTO subjects (subjectcode, subjectname, classapplicable, maxmarksperexam, isactive) VALUES ...
    session.add_all(
        Subject(
            subject_code=code, subject_name=name, class_applicable=applicable,
            max_marks_per_exam=max_marks, is_active=True,
        )
        for code, name, applicable, max_marks in SUBJECTS
    )
    # SQL: INSERT INTO students (studentid, name, email, phone, address, dateofbirth, fathername, mothername, parentcontact, classid, admissiondate, status) VALUES ...
    session.add_all(
        Student(
            student_id=student_id, name=name, email=email, phone=phone, address=address,
            date_of_birth=date.fromisoformat(dob), father_name=father, mother_name=mother,
            parent_contact=phone, class_id=class_id, admission_date=date(2024, 6, 1), status=status,
        )
        for student_id, name, email, phone, address, dob, father, mother, class_id, status in STUDENTS
    )
    session.flush()
    return {
        "users": 1 + len(TEACHERS) + len(STUDENTS),
        "teachers": len(TEACHERS),
        "classes": len(CLASSES),
        "subjects": len(SUBJECTS),
        "students": len(STUDENTS),
    }


def _seed_records(session: Session, today: date, now: datetime) -> dict[str, int]:
    """Insert a week of attendance, two exams of marks, fees and syllabus progress.

    Only active students get records, which is what leaves the one inactive
    student visible as a gap on the dashboards until an admin reactivates them.
    """
    active = [student for student in STUDENTS if student[9] == "active"]
    counts = {"attendance": 0, "marks": 0, "fees": 0, "syllabus": 0}

    # One school week of attendance per student, on their class's core subject.
    for row in active:
        student_id, class_id = row[0], row[8]
        subject_code, teacher_id = CORE_SUBJECT_BY_CLASS[class_id]
        for offset in range(6, -1, -1):
            # SQL: INSERT INTO attendance (attendanceid, studentid, classid, date, period, status, markedby, timestamp, subjectcode) VALUES (...)
            session.add(Attendance(
                attendance_id=f"att-{student_id}-{offset}", student_id=student_id, class_id=class_id,
                date=today - timedelta(days=offset), period=1, status=ATTENDANCE_PATTERN[6 - offset],
                marked_by=teacher_id, timestamp=now, subject_code=subject_code,
            ))
            counts["attendance"] += 1

    # Two exams across the three core subjects, scored randomly but with a
    # fixed seed so the dashboards look the same on every fresh install.
    for row in active:
        student_id, class_id = row[0], row[8]
        for subject_code, teacher_id in CORE_SUBJECT_BY_CLASS.values():
            for exam_type in ("Unit Test 1", "Mid Term"):
                score = random.randint(58, 96)
                # SQL: INSERT INTO marks (marksid, studentid, classid, examinationtype, marksobtained, maxmarks, grade, entrydate, subjectcode, teacherid) VALUES (...)
                session.add(Mark(
                    marks_id=f"marks-{student_id}-{subject_code}-{exam_type}", student_id=student_id,
                    class_id=class_id, examination_type=exam_type, marks_obtained=score, max_marks=100,
                    grade="A" if score >= 90 else "B" if score >= 75 else "C" if score >= 60 else "D",
                    entry_date=today, subject_code=subject_code, teacher_id=teacher_id,
                ))
                counts["marks"] += 1

    # Tuition and transport fees, deliberately mixing paid, part-paid and
    # unpaid so the fee summary's status pills all have something in them.
    tuition_variants = [(25000, 25000), (25000, 10000), (25000, 15000)]
    for index, row in enumerate(active):
        student_id, class_id = row[0], row[8]
        due, paid = tuition_variants[index % len(tuition_variants)]
        # SQL: INSERT INTO fees (feeid, studentid, classid, feetype, amountdue, amountpaid, balance, academicyear, paymentdate, paymentmethod, updatedby) VALUES (...)
        session.add(Fee(
            fee_id=f"fee-{student_id}-tuition", student_id=student_id, class_id=class_id,
            fee_type="Tuition", amount_due=due, amount_paid=paid, balance=due - paid,
            academic_year=ACADEMIC_YEAR, payment_date=today, payment_method="UPI", updated_by="admin",
        ))
        transport_paid = 8000 if index % 4 != 3 else 0
        # SQL: INSERT INTO fees (feeid, studentid, classid, feetype, amountdue, amountpaid, balance, academicyear, paymentdate, paymentmethod, updatedby) VALUES (...)
        session.add(Fee(
            fee_id=f"fee-{student_id}-transport", student_id=student_id, class_id=class_id,
            fee_type="Transport", amount_due=8000, amount_paid=transport_paid,
            balance=8000 - transport_paid, academic_year=ACADEMIC_YEAR,
            payment_date=today, payment_method="Cash", updated_by="admin",
        ))
        counts["fees"] += 2

    units = [
        (1, "MAT10", "teacher1", "Algebra Foundations", "in_progress", 60, "Linear equations", ["Variables", "Linear equations", "Quadratic equations"], ["Variables", "Linear equations"]),
        (1, "SCI10", "teacher2", "Motion and Force", "completed", 100, "Newtons Laws of Motion", ["Speed and velocity", "Newtons Laws of Motion"], ["Speed and velocity", "Newtons Laws of Motion"]),
        (1, "ENG10", "teacher3", "Prose and Poetry", "not_started", 0, None, ["Poetic devices", "Comprehension"], []),
        (2, "MAT10", "teacher1", "Trigonometry Basics", "in_progress", 45, "Trigonometric ratios", ["Angles", "Trigonometric ratios", "Identities"], ["Angles"]),
        (2, "SCI10", "teacher2", "Chemical Reactions", "in_progress", 70, "Balancing equations", ["Types of reactions", "Balancing equations"], ["Types of reactions"]),
        (2, "ENG10", "teacher3", "Grammar Essentials", "completed", 100, "Tenses", ["Parts of speech", "Tenses"], ["Parts of speech", "Tenses"]),
        (3, "MAT10", "teacher1", "Statistics", "not_started", 0, None, ["Mean median and mode", "Standard deviation"], []),
        (3, "SCI10", "teacher2", "Electricity", "in_progress", 30, "Ohms Law", ["Circuits", "Ohms Law"], []),
        (3, "ENG10", "teacher3", "Letter Writing", "completed", 100, "Formal letters", ["Informal letters", "Formal letters"], ["Informal letters", "Formal letters"]),
    ]
    for class_id, subject_code, teacher_id, unit, status, percentage, topic, sub_topics, done in units:
        # SQL: INSERT INTO syllabus (syllabusid, classid, unitname, completionstatus, completionpercentage, currenttopic, lastupdated, subjectcode, teacherid, subtopics, completedsubtopics) VALUES (...)
        session.add(Syllabus(
            syllabus_id=f"syl-{class_id}-{subject_code}", class_id=class_id, unit_name=unit,
            completion_status=status, completion_percentage=percentage, current_topic=topic,
            last_updated=now, subject_code=subject_code, teacher_id=teacher_id,
            sub_topics=sub_topics, completed_sub_topics=done,
        ))
        counts["syllabus"] += 1

    session.flush()
    return counts


def _seed_timetable(session: Session) -> dict[str, int]:
    """Build the recurring weekly timetable: every class, Monday to Friday,
    nine teaching periods, with subjects rotated so a class does not get the
    same subject in the same slot two days running."""
    total = 0
    for class_index, class_row in enumerate(CLASSES):
        class_id = class_row[0]
        for day_of_week in range(1, 6):
            for period_index, (slot_name, start, end) in enumerate(PERIODS):
                if period_index == LUNCH_INDEX:
                    continue  # lunch is a fixed break, not a scheduled lesson
                subject_code, teacher_id = TEACHING_STAFF[(class_index + day_of_week + period_index) % len(TEACHING_STAFF)]
                # SQL: INSERT INTO schedule_data (scheduleid, classid, academicyear, dayofweek, subjectcode, teacherid, slotnames, starttime, endtime, isactive) VALUES (...)
                session.add(ScheduleSlot(
                    schedule_id=f"sch-{class_id}-{day_of_week}-{period_index}", class_id=class_id,
                    academic_year=ACADEMIC_YEAR, day_of_week=day_of_week, subject_code=subject_code,
                    teacher_id=teacher_id, slot_names=slot_name, start_time=start, end_time=end,
                    is_active=True,
                ))
                total += 1
    session.flush()
    return {"schedule_slots": total}


def _seed_calendar(session: Session, today: date) -> dict[str, int]:
    """Mark every weekday in the calendar window as a working day, then
    overlay the named holidays and exam sessions on top of it."""
    start = today - timedelta(days=CALENDAR_DAYS_BACK)
    days: dict[tuple[int, date], CalendarDay] = {}

    for class_row in CLASSES:
        class_id = class_row[0]
        for offset in range(CALENDAR_DAYS_BACK + CALENDAR_DAYS_AHEAD + 1):
            day = start + timedelta(days=offset)
            if day.weekday() > 4:
                continue  # weekends are not part of the timetable grid
            entry = CalendarDay(
                grid_id=f"cal-{class_id}-{day.isoformat()}", class_id=class_id, calendar_date=day,
                academic_year=ACADEMIC_YEAR, day_type="working",
            )
            days[(class_id, day)] = entry
            # SQL: INSERT INTO calendar_grid (gridid, classid, calendardate, academicyear, daytype) VALUES (...)
            session.add(entry)

    for class_row in CLASSES:
        class_id = class_row[0]
        for offset, name, description in HOLIDAYS:
            entry = days.get((class_id, _weekday_on_or_after(today + timedelta(days=offset))))
            if entry:
                entry.day_type = "holiday"
                entry.holiday_name = name
                entry.description = description
        for offset, exam_type, exam_session, subject_codes in EXAMS:
            entry = days.get((class_id, _weekday_on_or_after(today + timedelta(days=offset))))
            if entry and entry.day_type == "working":
                entry.day_type = "exam"
                entry.exam_type = exam_type
                entry.exam_session = exam_session
                entry.description = ",".join(subject_codes)

    session.flush()
    return {"calendar_days": len(days)}
