"""The people-and-curriculum tables: classes, subjects, teachers, students.

These four are the reference data every other record points at - an
attendance row, a mark or a fee is always "this student, in this class, for
this subject" - so they are grouped in one module.
"""
from __future__ import annotations

from datetime import date

from sqlalchemy import JSON, Boolean, Date, ForeignKey, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import ApiModel, Base


class SchoolClass(Base, ApiModel):
    """One class section for one academic year, e.g. "Grade 10 - A, 2024-2025"."""

    __tablename__ = "classes"

    class_id: Mapped[int] = mapped_column("classid", Integer, primary_key=True, autoincrement=False)
    class_name: Mapped[str] = mapped_column("classname", String(100), nullable=False)
    section: Mapped[str] = mapped_column(String(20), nullable=False)
    academic_year: Mapped[str] = mapped_column("academicyear", String(20), nullable=False)
    max_students: Mapped[int] = mapped_column("maxstudents", Integer, nullable=False, default=40)
    class_teacher_id: Mapped[str | None] = mapped_column("classteacherid", String(100), ForeignKey("teachers.teacherid"))
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    students: Mapped[list["Student"]] = relationship(back_populates="school_class", viewonly=True)
    class_teacher: Mapped["Teacher"] = relationship(viewonly=True)

    @property
    def display_name(self) -> str:
        """"Grade 10 - A", the label the timetable and notification screens show."""
        return f"{self.class_name} - {self.section}"


class Subject(Base, ApiModel):
    """A subject that can be taught, graded and timetabled (e.g. MAT10)."""

    __tablename__ = "subjects"

    subject_code: Mapped[str] = mapped_column("subjectcode", String(30), primary_key=True)
    subject_name: Mapped[str] = mapped_column("subjectname", String(100), nullable=False)
    class_applicable: Mapped[str | None] = mapped_column("classapplicable", String(100))
    max_marks_per_exam: Mapped[int] = mapped_column("maxmarksperexam", Integer, nullable=False, default=100)
    is_active: Mapped[bool] = mapped_column("isactive", Boolean, nullable=False, default=True)


class Teacher(Base, ApiModel):
    """A teacher profile. `teacher_id` is also their users.username."""

    __tablename__ = "teachers"

    teacher_id: Mapped[str] = mapped_column("teacherid", String(100), ForeignKey("users.username"), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    phone_number: Mapped[str | None] = mapped_column("phonenumber", String(20))
    qualification: Mapped[str | None] = mapped_column(String(255))
    # Stored as JSON because a teacher handles a variable number of subjects
    # and classes; the frontend reads both as plain arrays of codes/ids.
    subjects_handled: Mapped[list] = mapped_column("subjectshandled", JSON, nullable=False, default=list)
    classes_assigned: Mapped[list] = mapped_column("classesassigned", JSON, nullable=False, default=list)
    class_teacher_of: Mapped[str | None] = mapped_column("classteacherof", String(50))
    hire_date: Mapped[date | None] = mapped_column("hiredate", Date)
    salary: Mapped[float | None] = mapped_column(Numeric(12, 2))
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    user: Mapped["User"] = relationship(back_populates="teacher", viewonly=True)


class Student(Base, ApiModel):
    """A student profile. `student_id` is also their users.username."""

    __tablename__ = "students"

    student_id: Mapped[str] = mapped_column("studentid", String(100), ForeignKey("users.username"), primary_key=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    phone: Mapped[str | None] = mapped_column(String(20))
    address: Mapped[str | None] = mapped_column(Text)
    date_of_birth: Mapped[date | None] = mapped_column("dateofbirth", Date)
    father_name: Mapped[str | None] = mapped_column("fathername", String(255))
    mother_name: Mapped[str | None] = mapped_column("mothername", String(255))
    parent_contact: Mapped[str | None] = mapped_column("parentcontact", String(20))
    class_id: Mapped[int | None] = mapped_column("classid", Integer, ForeignKey("classes.classid"))
    admission_date: Mapped[date | None] = mapped_column("admissiondate", Date)
    # "active" or "inactive" - students are soft-deleted so their marks, fees
    # and attendance history survive and can be reactivated later.
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="active")

    school_class: Mapped["SchoolClass"] = relationship(back_populates="students", viewonly=True)
    user: Mapped["User"] = relationship(back_populates="student", viewonly=True)
