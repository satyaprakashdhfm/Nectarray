"""The two planning tables behind every timetable and calendar screen.

They are deliberately separate concerns:

  ScheduleSlot - the *repeating* weekly pattern ("Grade 10-A has Maths with
                 teacher1 every Monday at 09:00").
  CalendarDay  - what makes a *specific* date special (a working day, a named
                 holiday, or an exam session).

The timetable router overlays the second on the first to produce the week
grid the frontend renders.
"""
from __future__ import annotations

from datetime import date, time

from sqlalchemy import Boolean, Date, ForeignKey, Integer, String, Time, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import ApiModel, Base


class ScheduleSlot(Base, ApiModel):
    """One period of the recurring weekly timetable for a class."""

    __tablename__ = "schedule_data"

    schedule_id: Mapped[str] = mapped_column("scheduleid", String(64), primary_key=True)
    class_id: Mapped[int] = mapped_column("classid", Integer, ForeignKey("classes.classid"), nullable=False)
    academic_year: Mapped[str] = mapped_column("academicyear", String(20), nullable=False)
    # 1 = Monday ... 7 = Sunday, matching the frontend's day ordering.
    day_of_week: Mapped[int] = mapped_column("dayofweek", Integer, nullable=False)
    subject_code: Mapped[str | None] = mapped_column("subjectcode", String(30), ForeignKey("subjects.subjectcode"))
    teacher_id: Mapped[str | None] = mapped_column("teacherid", String(100), ForeignKey("teachers.teacherid"))
    slot_names: Mapped[str | None] = mapped_column("slotnames", String(100))
    start_time: Mapped[time | None] = mapped_column("starttime", Time)
    end_time: Mapped[time | None] = mapped_column("endtime", Time)
    is_active: Mapped[bool] = mapped_column("isactive", Boolean, nullable=False, default=True)

    school_class: Mapped["SchoolClass"] = relationship(viewonly=True)


class CalendarDay(Base, ApiModel):
    """What one class is doing on one date: working, holiday or exam."""

    __tablename__ = "calendar_grid"
    __table_args__ = (UniqueConstraint("classid", "calendardate", name="uq_calendar_class_date"),)

    grid_id: Mapped[str] = mapped_column("gridid", String(64), primary_key=True)
    class_id: Mapped[int] = mapped_column("classid", Integer, ForeignKey("classes.classid"), nullable=False)
    calendar_date: Mapped[date] = mapped_column("calendardate", Date, nullable=False)
    academic_year: Mapped[str] = mapped_column("academicyear", String(20), nullable=False)
    # "working", "holiday", "half_holiday" or "exam".
    day_type: Mapped[str] = mapped_column("daytype", String(20), nullable=False, default="working")
    holiday_name: Mapped[str | None] = mapped_column("holidayname", String(100))
    exam_type: Mapped[str | None] = mapped_column("examtype", String(50))
    exam_session: Mapped[str | None] = mapped_column("examsession", String(50))
    # Free text shown under a holiday's name, or the subjects an exam covers.
    description: Mapped[str | None] = mapped_column(String(255))

    school_class: Mapped["SchoolClass"] = relationship(viewonly=True)
