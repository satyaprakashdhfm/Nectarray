"""Every database table as an ORM class, re-exported for easy importing.

Importing this package is also what registers the tables on `Base.metadata`,
which is how create_all() in app/database/session.py knows what to create.
"""
from app.models.academics import SchoolClass, Student, Subject, Teacher
from app.models.base import ApiModel, Base, to_camel, to_snake
from app.models.records import Attendance, Fee, Mark, Syllabus
from app.models.timetable import CalendarDay, ScheduleSlot
from app.models.user import User

__all__ = [
    "ApiModel", "Base", "to_camel", "to_snake",
    "User", "Teacher", "Student", "SchoolClass", "Subject",
    "Attendance", "Mark", "Fee", "Syllabus",
    "ScheduleSlot", "CalendarDay",
]
