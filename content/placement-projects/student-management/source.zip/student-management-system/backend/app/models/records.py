"""The per-student record tables: attendance, marks, fees and syllabus.

Everything here is transactional data that accumulates over the year and
feeds the dashboards, as opposed to the reference data in academics.py.
"""
from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import JSON, Date, DateTime, ForeignKey, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import ApiModel, Base


class Attendance(Base, ApiModel):
    """One student's presence for one period on one day."""

    __tablename__ = "attendance"

    attendance_id: Mapped[str] = mapped_column("attendanceid", String(64), primary_key=True)
    student_id: Mapped[str] = mapped_column("studentid", String(100), ForeignKey("students.studentid"), nullable=False)
    class_id: Mapped[int] = mapped_column("classid", Integer, ForeignKey("classes.classid"), nullable=False)
    date: Mapped[date] = mapped_column(Date, nullable=False)
    period: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    status: Mapped[str] = mapped_column(String(20), nullable=False)
    marked_by: Mapped[str | None] = mapped_column("markedby", String(100))
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=datetime.utcnow)
    subject_code: Mapped[str | None] = mapped_column("subjectcode", String(30), ForeignKey("subjects.subjectcode"))

    # Read-only companions, nested into the API response because the register
    # screens show a student's name and class, not their ids.
    student: Mapped["Student"] = relationship(viewonly=True)
    school_class: Mapped["SchoolClass"] = relationship(viewonly=True)
    subject: Mapped["Subject"] = relationship(viewonly=True)


class Mark(Base, ApiModel):
    """A score for one student, in one subject, for one examination."""

    __tablename__ = "marks"

    marks_id: Mapped[str] = mapped_column("marksid", String(64), primary_key=True)
    student_id: Mapped[str] = mapped_column("studentid", String(100), ForeignKey("students.studentid"), nullable=False)
    class_id: Mapped[int] = mapped_column("classid", Integer, ForeignKey("classes.classid"), nullable=False)
    examination_type: Mapped[str] = mapped_column("examinationtype", String(50), nullable=False)
    marks_obtained: Mapped[int] = mapped_column("marksobtained", Integer, nullable=False)
    max_marks: Mapped[int] = mapped_column("maxmarks", Integer, nullable=False)
    grade: Mapped[str | None] = mapped_column(String(5))
    entry_date: Mapped[date] = mapped_column("entrydate", Date, nullable=False, default=date.today)
    subject_code: Mapped[str | None] = mapped_column("subjectcode", String(30), ForeignKey("subjects.subjectcode"))
    teacher_id: Mapped[str | None] = mapped_column("teacherid", String(100), ForeignKey("teachers.teacherid"))

    student: Mapped["Student"] = relationship(viewonly=True)
    school_class: Mapped["SchoolClass"] = relationship(viewonly=True)
    subject: Mapped["Subject"] = relationship(viewonly=True)
    teacher: Mapped["Teacher"] = relationship(viewonly=True)


class Fee(Base, ApiModel):
    """One fee line (tuition, transport, ...) for one student for a year.

    `balance` is always amount_due - amount_paid; the fee routes recompute it
    on every write so the dashboards never have to.
    """

    __tablename__ = "fees"

    fee_id: Mapped[str] = mapped_column("feeid", String(64), primary_key=True)
    student_id: Mapped[str] = mapped_column("studentid", String(100), ForeignKey("students.studentid"), nullable=False)
    class_id: Mapped[int] = mapped_column("classid", Integer, ForeignKey("classes.classid"), nullable=False)
    fee_type: Mapped[str] = mapped_column("feetype", String(50), nullable=False)
    amount_due: Mapped[float] = mapped_column("amountdue", Numeric(12, 2), nullable=False)
    amount_paid: Mapped[float] = mapped_column("amountpaid", Numeric(12, 2), nullable=False, default=0)
    balance: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False, default=0)
    academic_year: Mapped[str] = mapped_column("academicyear", String(20), nullable=False)
    payment_date: Mapped[date | None] = mapped_column("paymentdate", Date)
    payment_method: Mapped[str | None] = mapped_column("paymentmethod", String(30))
    updated_by: Mapped[str | None] = mapped_column("updatedby", String(100))

    student: Mapped["Student"] = relationship(viewonly=True)
    school_class: Mapped["SchoolClass"] = relationship(viewonly=True)


class Syllabus(Base, ApiModel):
    """A teaching unit for one class/subject and how far through it the class is."""

    __tablename__ = "syllabus"

    syllabus_id: Mapped[str] = mapped_column("syllabusid", String(64), primary_key=True)
    class_id: Mapped[int] = mapped_column("classid", Integer, ForeignKey("classes.classid"), nullable=False)
    unit_name: Mapped[str] = mapped_column("unitname", String(255), nullable=False)
    completion_status: Mapped[str] = mapped_column("completionstatus", String(30), nullable=False, default="not_started")
    completion_percentage: Mapped[int] = mapped_column("completionpercentage", Integer, nullable=False, default=0)
    current_topic: Mapped[str | None] = mapped_column("currenttopic", Text)
    last_updated: Mapped[datetime] = mapped_column("lastupdated", DateTime(timezone=True), nullable=False, default=datetime.utcnow)
    subject_code: Mapped[str | None] = mapped_column("subjectcode", String(30), ForeignKey("subjects.subjectcode"))
    teacher_id: Mapped[str | None] = mapped_column("teacherid", String(100), ForeignKey("teachers.teacherid"))
    # The full topic list and the subset already taught; the teacher UI ticks
    # items off the first list into the second.
    sub_topics: Mapped[list] = mapped_column("subtopics", JSON, nullable=False, default=list)
    completed_sub_topics: Mapped[list] = mapped_column("completedsubtopics", JSON, nullable=False, default=list)

    school_class: Mapped["SchoolClass"] = relationship(viewonly=True)
    subject: Mapped["Subject"] = relationship(viewonly=True)
    teacher: Mapped["Teacher"] = relationship(viewonly=True)
