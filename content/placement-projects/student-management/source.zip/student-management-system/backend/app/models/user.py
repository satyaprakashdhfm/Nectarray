"""The `users` table: one login account per admin, teacher and student.

Teachers and students each have a matching profile row (see academics.py)
keyed by the same username, so this table only holds credentials and the
role that decides which dashboard the frontend shows.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import ApiModel, Base


class User(Base, ApiModel):
    """A login account. `role` is one of admin / teacher / student."""

    __tablename__ = "users"

    username: Mapped[str] = mapped_column(String(100), primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    password: Mapped[str] = mapped_column(Text, nullable=False)
    first_name: Mapped[str | None] = mapped_column("firstname", String(100))
    last_name: Mapped[str | None] = mapped_column("lastname", String(100))
    role: Mapped[str] = mapped_column(String(20), nullable=False, default="student")
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    last_login: Mapped[datetime | None] = mapped_column("lastlogin", DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column("createdat", DateTime(timezone=True), default=datetime.utcnow)

    teacher: Mapped["Teacher"] = relationship(back_populates="user", uselist=False, viewonly=True)
    student: Mapped["Student"] = relationship(back_populates="user", uselist=False, viewonly=True)

    def public(self) -> dict:
        """The user object returned to the client: everything except the password hash."""
        return {key: value for key, value in self.to_dict().items() if key != "password"}
