"""The ORM's shared foundation: the declarative Base plus the naming and
type conversion every model needs to talk to the React frontend.

Three different naming styles meet in this file, which is why it exists:

  * PostgreSQL folds unquoted identifiers to lowercase, so every column is
    declared lowercase ("firstname"). SQLite matches identifiers
    case-insensitively, so the same declaration works on both databases.
  * Python attributes are snake_case ("first_name"), as usual.
  * The React app has always spoken camelCase ("firstName").

`ApiModel` below converts between the last two automatically, so models can
be written in idiomatic Python without changing the frontend's contract.
"""
from __future__ import annotations

import re
import uuid
from datetime import date, datetime, time
from decimal import Decimal

from sqlalchemy import Boolean, Date, DateTime, Float, Integer, Numeric, Time, inspect
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Declarative base class that every table model inherits from."""


def to_camel(name: str) -> str:
    """snake_case attribute -> camelCase JSON key ("first_name" -> "firstName")."""
    head, *tail = name.split("_")
    return head + "".join(word.capitalize() for word in tail)


def to_snake(name: str) -> str:
    """camelCase JSON key -> snake_case attribute ("firstName" -> "first_name")."""
    return re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()


def jsonable(value):
    """Make one column value safe for JSONResponse.

    SQLAlchemy hands back real Python objects (date, datetime, Decimal) that
    the frontend has always received as strings/numbers, so convert them here
    rather than in every route.
    """
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, uuid.UUID):
        # PostgreSQL UUID columns come back as UUID objects, which JSON cannot
        # encode; the frontend has always seen these ids as strings.
        return str(value)
    return value


def coerce(column, value):
    """Convert one inbound JSON value to the Python type its column expects.

    The frontend posts everything as strings ("2024-06-01", "45", "true"),
    which SQLite would happily store as-is and PostgreSQL would reject, so
    every write goes through this first.
    """
    if value is None or value == "":
        return None
    kind = column.type
    try:
        if isinstance(kind, Boolean):
            return value if isinstance(value, bool) else str(value).lower() in ("1", "true", "yes")
        if isinstance(kind, Integer):
            return int(value)
        if isinstance(kind, (Numeric, Float)):
            return float(value)
        if isinstance(kind, DateTime):
            return value if isinstance(value, datetime) else datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if isinstance(kind, Date):
            return value if isinstance(value, date) else date.fromisoformat(str(value)[:10])
        if isinstance(kind, Time):
            return value if isinstance(value, time) else time.fromisoformat(str(value))
    except (TypeError, ValueError):
        # Keep the raw value and let the database raise a clearer error than
        # a stack trace from inside this helper.
        return value
    return value


class ApiModel:
    """Mixin that turns a model row into the camelCase JSON the frontend
    expects, and applies a camelCase request body back onto the row."""

    @classmethod
    def columns(cls) -> dict:
        """Map every snake_case attribute name to its SQLAlchemy Column."""
        return {attribute.key: attribute.columns[0] for attribute in inspect(cls).mapper.column_attrs}

    @classmethod
    def primary_key(cls) -> str:
        """The attribute name of this table's primary key column."""
        key = inspect(cls).mapper.primary_key[0]
        return next(name for name, column in cls.columns().items() if column is key)

    @classmethod
    def api_fields(cls) -> dict[str, str]:
        """Map the camelCase names the frontend uses to attribute names."""
        return {to_camel(name): name for name in cls.columns()}

    def to_dict(self) -> dict:
        """Serialise this row as the camelCase object the React app consumes."""
        return {to_camel(name): jsonable(getattr(self, name)) for name in type(self).columns()}

    def apply(self, payload: dict, skip: set[str] = frozenset()) -> "ApiModel":
        """Assign the recognised fields of a request body onto this row.

        Unknown keys are ignored on purpose: the frontend sends a few extra
        display-only fields (className, studentName, ...) alongside real
        columns, and rejecting the whole request over them would break pages
        that have always worked.
        """
        columns = type(self).columns()
        for key, value in payload.items():
            name = type(self).api_fields().get(key, to_snake(key))
            if name in columns and name not in skip:
                setattr(self, name, coerce(columns[name], value))
        return self
