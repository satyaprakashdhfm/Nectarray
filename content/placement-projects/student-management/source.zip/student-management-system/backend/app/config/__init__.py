"""Application settings, loaded once from the environment at import time."""
from app.config.settings import (
    BACKEND_ROOT,
    DATABASE_URL,
    FRONTEND_ORIGINS,
    IS_SQLITE,
    JWT_SECRET,
    PORT,
)

__all__ = ["BACKEND_ROOT", "DATABASE_URL", "FRONTEND_ORIGINS", "IS_SQLITE", "JWT_SECRET", "PORT"]
