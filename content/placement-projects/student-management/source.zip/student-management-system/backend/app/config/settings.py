"""Centralised environment-based application configuration.

Reads everything from environment variables (see backend/.env.example) once,
at import time, so the rest of the app can import plain constants instead of
calling os.getenv() everywhere.
"""
from __future__ import annotations

import os
from pathlib import Path

# backend/ - the folder that holds main.py, so relative paths below never
# depend on the directory the process happened to be launched from.
BACKEND_ROOT = Path(__file__).resolve().parents[2]

raw_database_url = os.getenv("DATABASE_URL", "sqlite:///./student_management.db")

# A relative sqlite:/// path is resolved against the backend folder (not the
# process's cwd) so the DB file lands in the same place every time.
if raw_database_url.startswith("sqlite:///"):
    database_path = Path(raw_database_url.removeprefix("sqlite:///"))
    database_path = database_path if database_path.is_absolute() else BACKEND_ROOT / database_path
    DATABASE_URL = f"sqlite+pysqlite:///{database_path.as_posix()}"
else:
    DATABASE_URL = raw_database_url

IS_SQLITE = DATABASE_URL.startswith("sqlite")

JWT_SECRET = os.getenv("JWT_SECRET", "development-secret-change-me")
PORT = int(os.getenv("PORT", "8080"))
FRONTEND_ORIGINS = [
    origin.strip()
    for origin in os.getenv("FRONTEND_URL", "http://localhost:3000,http://localhost:3001").split(",")
]
