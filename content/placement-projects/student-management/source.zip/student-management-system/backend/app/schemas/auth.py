"""Request bodies for the /api/auth routes.

These spell their fields out, unlike the deliberately permissive Payload the
generic resource routes use, so the docs page shows a filled-in username and
password to edit rather than an "additionalProp1" placeholder - and a request
missing either field is rejected with a 422 that names it.
"""
from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    """Credentials posted to /api/auth/login."""

    username: str = Field(
        description=(
            "Admins log in with their username; teachers and students log in with "
            "their own id, e.g. teacher1 or student1."
        ),
    )
    password: str = Field(description="The account's password.")

    model_config = {
        "json_schema_extra": {"example": {"username": "admin", "password": "admin123"}}
    }


class RegisterRequest(BaseModel):
    """A new account for /api/auth/register.

    Role defaults to student, which is the only role the public signup flow
    creates; teacher and admin accounts are made by an admin instead.
    """

    username: str = Field(description="Must be unique across all accounts.")
    email: str = Field(description="Must also be unique.")
    password: str = Field(description="Stored as a PBKDF2-SHA256 hash, never in the clear.")
    firstName: str | None = None
    lastName: str | None = None
    role: str = Field(default="student", description='One of "student", "teacher" or "admin".')

    model_config = {
        "json_schema_extra": {
            "example": {
                "username": "student13",
                "email": "student13@example.com",
                "password": "student123",
                "firstName": "Neha",
                "lastName": "Kulkarni",
                "role": "student",
            }
        }
    }
