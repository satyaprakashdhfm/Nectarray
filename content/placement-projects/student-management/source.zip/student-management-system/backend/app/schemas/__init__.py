"""Pydantic models describing request bodies and the shared error body."""
from app.schemas.auth import LoginRequest, RegisterRequest
from app.schemas.common import ErrorResponse, Payload

__all__ = ["ErrorResponse", "LoginRequest", "Payload", "RegisterRequest"]
