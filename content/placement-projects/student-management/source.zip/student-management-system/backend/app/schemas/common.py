"""Shared request-body schema used across the routers."""
from pydantic import BaseModel


class Payload(BaseModel):
    """A permissive JSON body.

    The resource routes are generic over eleven tables with different columns,
    and the frontend also sends display-only extras (className, studentName)
    alongside real fields. Accepting any object here and letting the ORM layer
    pick out the columns it recognises keeps those requests working; the
    database still enforces types and constraints.
    """

    model_config = {"extra": "allow"}


class ErrorResponse(BaseModel):
    """The body every failed request returns.

    Declaring it here is only for the docs: the actual JSON is built by the
    exception handler in main.py, and this keeps Swagger from labelling those
    responses "Undocumented".
    """

    success: bool = False
    error: str = "Invalid or expired token"
    message: str = "Invalid or expired token"
    timestamp: str = "2026-09-20T05:59:25.074222+00:00"
