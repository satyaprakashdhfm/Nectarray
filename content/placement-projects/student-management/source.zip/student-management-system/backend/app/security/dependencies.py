"""The auth dependency every protected route hangs off.

`Depends(current_user)` both requires a valid session and tells the route who
is calling, so no route has to parse the Authorization header itself.
"""
from __future__ import annotations

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.database.session import get_session
from app.models import User
from app.security.tokens import decode_token

# Declaring the scheme rather than reading the header by hand is what puts the
# "Authorize" button on /docs and a padlock on every protected route, so the
# token can be pasted once and reused for the whole page. auto_error=False
# keeps our own 401 body instead of FastAPI's {"detail": ...}.
bearer_scheme = HTTPBearer(
    scheme_name="Session token",
    description='Paste the "token" from POST /api/auth/login. Swagger adds the "Bearer " prefix for you.',
    auto_error=False,
)


def current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    session: Session = Depends(get_session),
) -> User:
    """Resolve the bearer token to a live, still-active user row.

    Raises 401 for a missing, tampered or expired token, and for an account
    that has since been deactivated - a token stays valid for 24 hours, so
    the active flag has to be re-checked on every request.
    """
    payload = decode_token(credentials.credentials if credentials else "")
    if not payload:
        raise HTTPException(401, "Invalid or expired token")

    # SQL: SELECT * FROM users WHERE username = :sub
    user = session.get(User, payload["sub"])
    if not user:
        raise HTTPException(401, "Invalid or expired token")
    if not user.active:
        raise HTTPException(401, "Account is deactivated")
    return user
