"""Session tokens handed to the browser on login.

These are *not* standards-compliant JWTs: it is a base64url payload plus an
HMAC-SHA256 signature over it, implemented here to avoid an extra dependency.
They fill the same role, but don't feed them to generic JWT tooling.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time

from app.config import JWT_SECRET

TOKEN_LIFETIME_SECONDS = 86_400  # 24 hours


def _b64(raw: bytes) -> str:
    """Base64url-encode without padding, which keeps tokens URL-safe."""
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode()


def _unb64(value: str) -> bytes:
    """Reverse _b64, restoring the padding base64 needs to decode."""
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def create_token(username: str, role: str) -> str:
    """Issue a signed token identifying this user for the next 24 hours."""
    payload = {"sub": username, "role": role, "exp": int(time.time()) + TOKEN_LIFETIME_SECONDS}
    raw = _b64(json.dumps(payload, separators=(",", ":")).encode())
    signature = hmac.new(JWT_SECRET.encode(), raw.encode(), hashlib.sha256).digest()
    return f"{raw}.{_b64(signature)}"


def decode_token(token: str) -> dict | None:
    """Return the token's payload, or None if the signature or expiry fails.

    Returning None rather than raising lets the caller decide the status code
    and message the client sees.
    """
    try:
        raw, signature = token.split(".")
        expected = hmac.new(JWT_SECRET.encode(), raw.encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(_unb64(signature), expected):
            return None
        payload = json.loads(_unb64(raw))
        return None if payload["exp"] < time.time() else payload
    except Exception:
        return None
