"""Password hashing for the users table.

PBKDF2-HMAC-SHA256 with a per-user random salt, stored as one self-describing
string: `pbkdf2_sha256$<salt>$<base64 digest>`. Keeping the salt in the hash
means verification needs nothing but the stored value.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets

ITERATIONS = 210_000


def hash_password(value: str, salt: str | None = None) -> str:
    """Hash a plaintext password, generating a salt unless one is supplied.

    verify_password passes the stored salt back in so this same function can
    recompute the original hash for comparison.
    """
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", value.encode(), salt.encode(), ITERATIONS)
    return f"pbkdf2_sha256${salt}${base64.b64encode(digest).decode()}"


def verify_password(value: str, stored: str) -> bool:
    """Check a login attempt against the stored hash, in constant time."""
    try:
        return hmac.compare_digest(hash_password(value, stored.split("$", 2)[1]), stored)
    except (IndexError, ValueError, AttributeError):
        return False
