"""Application entry point: compose FastAPI, middleware, routers and errors.

Run it with `python main.py` (auto-reload for development) or point uvicorn at
`main:app`. On startup it creates any missing tables and seeds demo data into
an empty database, so a fresh clone works with no setup at all.
"""
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import FRONTEND_ORIGINS, PORT
from app.database import create_tables, seed_demo_data, session_scope
from app.routers import auth, health, reactivation, resources, statistics, timetable
from app.schemas import ErrorResponse

# Shown at the top of /docs. Swagger renders Markdown, so the table below
# comes out as a table.
DESCRIPTION = """
The REST API behind the student management app. Every route under `/api`
except `/api/auth/login` and `/api/auth/register` needs a session token.

### Trying an endpoint

1. Run **POST `/api/auth/login`** with one of the demo accounts below.
2. Copy the `token` value out of the response.
3. Click the green **Authorize** button at the top right, paste the token and
   press Authorize. Every endpoint on this page will then send it for you, and
   it survives a page reload.

You can also paste a token you already have from the browser's session storage.
Paste the token on its own - Swagger adds the `Bearer ` prefix.

| Role | Username | Password |
| --- | --- | --- |
| Admin | `admin` | `admin123` |
| Teacher | `teacher1`, `teacher2`, `teacher3` | `teacher123` |
| Student | `student1` ... `student12` | `student123` |

A token lasts 24 hours. A `401` means it is missing, expired or the account
was deactivated - log in again and re-authorize.
"""

# Ordered the way the groups appear on the page.
API_TAGS = [
    {"name": "Health", "description": "Liveness checks. The only routes that need no token."},
    {"name": "Authentication", "description": "Log in, register, and read the current session's profile."},
    {"name": "Student Management", "description": (
        "CRUD over every academic table - students, teachers, classes, subjects, "
        "attendance, marks, fees and syllabus - plus fee payments and syllabus progress. "
        "List responses carry their rows under both `data` and the resource's own name."
    )},
    {"name": "Timetable", "description": (
        "The weekly schedule and the academic calendar: week grids, recurring periods, "
        "exam sessions and holidays."
    )},
    {"name": "Statistics", "description": "Aggregates behind the dashboard charts and summary tiles."},
    {"name": "Reactivation", "description": "Find deactivated classes, students and logins, and restore them."},
]

# Attached to every protected router so a 401 is documented rather than
# showing up as "Undocumented" once you try a route without a token.
UNAUTHORIZED = {401: {"model": ErrorResponse, "description": "Missing, expired or rejected token"}}


@asynccontextmanager
async def lifespan(_: FastAPI):
    """Prepare the database before serving: create missing tables, then seed
    demo data into whichever tables are still empty (a no-op once seeded)."""
    create_tables()
    with session_scope() as session:
        seeded = seed_demo_data(session)
    if seeded:
        print("Seeded demo data:", ", ".join(f"{name}={count}" for name, count in seeded.items()))
    yield


app = FastAPI(
    title="Student Management API",
    version="3.0.0",
    description=DESCRIPTION,
    openapi_tags=API_TAGS,
    lifespan=lifespan,
    swagger_ui_parameters={
        # Keep the pasted token across page reloads, collapse the groups so the
        # page opens on an overview rather than sixty expanded routes, and show
        # a search box for finding one by path.
        "persistAuthorization": True,
        "docExpansion": "none",
        "filter": True,
        "defaultModelsExpandDepth": -1,
    },
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=FRONTEND_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Registration order is deliberate: resources.py ends with catch-all
# /api/{resource} routes, so every more specific router has to come first.
app.include_router(health.router)
app.include_router(auth.router, responses={401: {"model": ErrorResponse, "description": "Bad credentials"}})
app.include_router(reactivation.router, responses=UNAUTHORIZED)
app.include_router(timetable.router, responses=UNAUTHORIZED)
app.include_router(statistics.router, responses=UNAUTHORIZED)
app.include_router(resources.router, responses=UNAUTHORIZED)


def error_body(detail: str) -> dict:
    """The {success, error, message, timestamp} shape the frontend reads."""
    return {
        "success": False,
        "error": detail,
        "message": detail,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@app.exception_handler(HTTPException)
async def http_error(_: Request, error: HTTPException):
    """Render every raised HTTPException in the shared error shape."""
    return JSONResponse(status_code=error.status_code, content=error_body(error.detail))


@app.exception_handler(RequestValidationError)
async def validation_error(_: Request, error: RequestValidationError):
    """Do the same for a body that fails validation.

    FastAPI's own 422 is a {"detail": [...]} list, which the frontend's error
    handling cannot read, so the failing fields are summarised into one
    sentence in the same shape as every other error.
    """
    problems = ", ".join(
        f"{'.'.join(str(part) for part in item['loc'][1:]) or 'body'}: {item['msg']}"
        for item in error.errors()
    )
    return JSONResponse(status_code=422, content=error_body(problems or "Invalid request body"))


if __name__ == "__main__":
    # `python main.py` is the path the README documents, so keep this
    # runnable directly with auto-reload for development.
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=PORT, reload=True)
