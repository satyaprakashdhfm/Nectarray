// Shared chrome for all admin pages: sidebar navigation (with per-section
// collapsible dropdowns grouped by grade), the academic-year selector that
// feeds AcademicYearContext, and the top header with logout/theme toggle.
import React, { useState, useEffect } from 'react';
import ThemeToggle from '../Common/ThemeToggle';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import apiService from '../../services/api';
import { useAcademicYear } from '../../context/AcademicYearContext';
import { useAuth } from '../../context/AuthContext';

const AdminLayout = ({ children }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { logout, user } = useAuth();
  const [showFeeDropdown, setShowFeeDropdown] = useState(false);
  const [showStudentDropdown, setShowStudentDropdown] = useState(false);
  const [showTimeDropdown, setShowTimeDropdown] = useState(false);
  const [showMarksDropdown, setShowMarksDropdown] = useState(false);
  const [showAttendanceDropdown, setShowAttendanceDropdown] = useState(false);
  const [showScheduleDropdown, setShowScheduleDropdown] = useState(false);
  
  // Use the academic year context
  const { 
    selectedAcademicYear, 
    setSelectedAcademicYear, 
    classes, 
    setClasses, 
    loading, 
    setLoading 
  } = useAcademicYear();

  // Fetch classes for dropdowns
  // Loads all classes and filters them to the currently selected academic year, for the sidebar dropdowns.
  useEffect(() => {
    const fetchClasses = async () => {
      setLoading(true);
      try {
        const response = await apiService.getClasses();
        if (response.classes) {
          // Filter classes by selected academic year
          const filteredClasses = response.classes.filter(
            cls => cls.academicYear === selectedAcademicYear
          );
          setClasses(filteredClasses);
        }
      } catch (error) {
        console.error('Error fetching classes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchClasses();
  }, [selectedAcademicYear]); // Re-fetch when academic year changes

  // Keep dropdowns open based on current route
  // Re-opens the relevant sidebar dropdown whenever the route changes, so the active section stays expanded.
  useEffect(() => {
    if (location.pathname.includes('/admin/time-management')) {
      setShowTimeDropdown(true);
    }
    if (location.pathname.includes('/admin/students')) {
      setShowStudentDropdown(true);
    }
    if (location.pathname.includes('/admin/fees')) {
      setShowFeeDropdown(true);
    }
    if (location.pathname.includes('/admin/marks')) {
      setShowMarksDropdown(true);
    }
    if (location.pathname.includes('/admin/attendance')) {
      setShowAttendanceDropdown(true);
    }
    if (location.pathname.includes('/admin/schedule-management')) {
      setShowScheduleDropdown(true);
    }
  }, [location.pathname]);

  // Each handleXDropdownToggle below toggles its own sidebar dropdown while
  // closing all the other dropdowns, so only one section is expanded at a time.
  const handleStudentDropdownToggle = () => {
    setShowStudentDropdown(!showStudentDropdown);
    // Close other dropdowns when student dropdown is opened
    if (!showStudentDropdown) {
      setShowFeeDropdown(false);
      setShowTimeDropdown(false);
      setShowAttendanceDropdown(false);
      setShowMarksDropdown(false);
      setShowScheduleDropdown(false);
    }
  };

  const handleFeeDropdownToggle = () => {
    setShowFeeDropdown(!showFeeDropdown);
    // Close other dropdowns when fee dropdown is opened
    if (!showFeeDropdown) {
      setShowStudentDropdown(false);
      setShowTimeDropdown(false);
      setShowAttendanceDropdown(false);
      setShowMarksDropdown(false);
      setShowScheduleDropdown(false);
    }
  };

  const handleTimeDropdownToggle = () => {
    setShowTimeDropdown(!showTimeDropdown);
    // Close other dropdowns when time dropdown is opened
    if (!showTimeDropdown) {
      setShowStudentDropdown(false);
      setShowFeeDropdown(false);
      setShowAttendanceDropdown(false);
      setShowMarksDropdown(false);
      setShowScheduleDropdown(false);
    }
  };

  const handleScheduleDropdownToggle = () => {
    setShowScheduleDropdown(!showScheduleDropdown);
    // Close other dropdowns when schedule dropdown is opened
    if (!showScheduleDropdown) {
      setShowStudentDropdown(false);
      setShowFeeDropdown(false);
      setShowTimeDropdown(false);
      setShowAttendanceDropdown(false);
      setShowMarksDropdown(false);
    }
  };

  const handleMarksDropdownToggle = () => {
    setShowMarksDropdown(!showMarksDropdown);
    // Close other dropdowns when marks dropdown is opened
    if (!showMarksDropdown) {
      setShowStudentDropdown(false);
      setShowFeeDropdown(false);
      setShowTimeDropdown(false);
      setShowAttendanceDropdown(false);
      setShowScheduleDropdown(false);
    }
  };

  const handleAttendanceDropdownToggle = () => {
    setShowAttendanceDropdown(!showAttendanceDropdown);
    // Close other dropdowns when attendance dropdown is opened
    if (!showAttendanceDropdown) {
      setShowStudentDropdown(false);
      setShowFeeDropdown(false);
      setShowTimeDropdown(false);
      setShowMarksDropdown(false);
      setShowScheduleDropdown(false);
    }
  };

  // Close all dropdowns when clicking on Teacher Management or System Configuration
  const handleSingleNavClick = () => {
    setShowStudentDropdown(false);
    setShowFeeDropdown(false);
    setShowTimeDropdown(false);
    setShowMarksDropdown(false);
    setShowAttendanceDropdown(false);
    setShowScheduleDropdown(false);
  };

  // Function to handle navigation without closing dropdown for Time Management
  const handleTimeNavigation = () => {
    // Don't close the dropdown when navigating within Time Management
  };

  // Updates the shared academic year (triggering the class re-fetch above) and collapses open dropdowns.
  const handleAcademicYearChange = (e) => {
    const newYear = e.target.value;
    setSelectedAcademicYear(newYear);
    console.log('Academic year changed to:', newYear);
    
    // Close dropdowns when academic year changes
    setShowFeeDropdown(false);
    setShowStudentDropdown(false);
    setShowTimeDropdown(false);
    setShowMarksDropdown(false);
    setShowAttendanceDropdown(false);
    setShowScheduleDropdown(false);
  };

  const handleLogout = () => {
    logout();
    navigate('/login/admin');
  };

  // Group classes by grade (e.g., "8th", "9th", "10th")
  // Builds { grade: [classes] } so the sidebar can render one nav entry per grade instead of per class.
  const classGroups = classes.reduce((groups, cls) => {
    const grade = cls.className; // e.g., "8th"
    if (!groups[grade]) {
      groups[grade] = [];
    }
    groups[grade].push(cls);
    return groups;
  }, {});
  
  // Get unique grades sorted (e.g., ["8th", "9th", "10th"])
  const uniqueGrades = Object.keys(classGroups).sort();

  return (
    <div className="dashboard">
      <div className="sidebar">
        <h2>Admin Portal</h2>
        
        {/* Academic Year Filter in Sidebar */}
        <div className="sidebar-academic-year">
          <label>Academic Year:</label>
          <select 
            value={selectedAcademicYear} 
            onChange={handleAcademicYearChange}
            disabled={loading}
          >
            <option value="2023-2024">2023-2024</option>
            <option value="2024-2025">2024-2025</option>
            <option value="2025-2026">2025-2026</option>
          </select>
          {loading && (
            <div className="loading-indicator">
              <small>Loading classes...</small>
            </div>
          )}
        </div>

        <nav>
          <ul className="sidebar-nav">
            {/* Teacher Management without Dropdown */}
            <li>
              <Link 
                to="/admin/teachers"
                className={location.pathname === '/admin/teachers' ? 'active' : ''}
                onClick={handleSingleNavClick}
              >
                <span style={{ marginRight: '10px' }}>👩‍🏫</span>
                Teacher Management
              </Link>
            </li>

            {/* Student Management with Dropdown */}
            <li>
              <div 
                className={`dropdown-header ${location.pathname.includes('/admin/students') ? 'active' : ''}`}
                onClick={handleStudentDropdownToggle}
              >
                <span style={{ marginRight: '10px' }}>🎓</span>
                Student Management
                <span style={{ marginLeft: '10px' }}>{showStudentDropdown ? '▲' : '▼'}</span>
              </div>
              {showStudentDropdown && (
                <ul className="dropdown-menu">
                  <li>
                    <Link to="/admin/students" className={location.pathname === '/admin/students' ? 'active' : ''}>
                      All Students
                    </Link>
                  </li>
                  {uniqueGrades.map(grade => (
                    <li key={grade}>
                      <Link 
                        to={`/admin/students/grade/${grade}`} 
                        className={location.pathname === `/admin/students/grade/${grade}` ? 'active' : ''}
                      >
                        Grade {grade}
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </li>

            {/* Fee Management with Dropdown */}
            <li>
              <div 
                className={`dropdown-header ${location.pathname.includes('/admin/fees') ? 'active' : ''}`}
                onClick={handleFeeDropdownToggle}
              >
                <span style={{ marginRight: '10px' }}>💰</span>
                Fee Management
                <span style={{ marginLeft: '10px' }}>{showFeeDropdown ? '▲' : '▼'}</span>
              </div>
              {showFeeDropdown && (
                <ul className="dropdown-menu">
                  <li>
                    <Link to="/admin/fees" className={location.pathname === '/admin/fees' ? 'active' : ''}>
                      All Classes
                    </Link>
                  </li>
                  {uniqueGrades.map(grade => (
                    <li key={grade}>
                      <Link 
                        to={`/admin/fees/grade/${grade}`} 
                        className={location.pathname === `/admin/fees/grade/${grade}` ? 'active' : ''}
                      >
                        Grade {grade}
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </li>

            {/* Time Management with Dropdown */}
            <li>
              <div
                className={`dropdown-header ${location.pathname.includes('/admin/time-management') ? 'active' : ''}`}
                onClick={handleTimeDropdownToggle}
              >
                <span style={{ marginRight: '10px' }}>⏰</span>
                Time Management
                <span style={{ marginLeft: '10px' }}>{showTimeDropdown ? '▲' : '▼'}</span>
              </div>
              {showTimeDropdown && (
                <ul className="dropdown-menu">
                  {uniqueGrades.map(grade => (
                    <li key={grade}>
                      <Link
                        to={`/admin/time-management/grade/${grade}`}
                        className={location.pathname === `/admin/time-management/grade/${grade}` ? 'active' : ''}
                        onClick={handleTimeNavigation}
                      >
                        Grade {grade}
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </li>

            {/* Schedule, Holidays & Exams Management with Dropdown */}
            <li>
              <div
                className={`dropdown-header ${location.pathname.includes('/admin/schedule-management') ? 'active' : ''}`}
                onClick={handleScheduleDropdownToggle}
              >
                <span style={{ marginRight: '10px' }}>📅</span>
                Schedule, Holidays & Exams Management
                <span style={{ marginLeft: '10px' }}>{showScheduleDropdown ? '▲' : '▼'}</span>
              </div>
              {showScheduleDropdown && (
                <ul className="dropdown-menu">
                  <li>
                    <Link
                      to="/admin/schedule-management/exams"
                      className={location.pathname === '/admin/schedule-management/exams' ? 'active' : ''}
                    >
                      📚 Exams
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/admin/schedule-management/holidays"
                      className={location.pathname === '/admin/schedule-management/holidays' ? 'active' : ''}
                    >
                      🏖️ Holidays
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/admin/schedule-management/schedules"
                      className={location.pathname === '/admin/schedule-management/schedules' ? 'active' : ''}
                    >
                      🗓️ New Schedule (Coming Soon)
                    </Link>
                  </li>
                </ul>
              )}
            </li>

            {/* Class Management */}
            <li>
              <Link 
                to="/admin/classes"
                className={location.pathname === '/admin/classes' ? 'active' : ''}
                onClick={handleSingleNavClick}
              >
                <span style={{ marginRight: '10px' }}>🏫</span>
                Class Management
              </Link>
            </li>

            {/* Attendance Management with Dropdown */}
            <li>
              <div 
                className={`dropdown-header ${location.pathname.includes('/admin/attendance') ? 'active' : ''}`}
                onClick={handleAttendanceDropdownToggle}
              >
                <span style={{ marginRight: '10px' }}>📋</span>
                Attendance Management
                <span style={{ marginLeft: '10px' }}>{showAttendanceDropdown ? '▲' : '▼'}</span>
              </div>
              {showAttendanceDropdown && (
                <ul className="dropdown-menu">
                  {uniqueGrades.map(grade => (
                    <li key={grade}>
                      <Link 
                        to={`/admin/attendance/grade/${grade}`} 
                        className={location.pathname === `/admin/attendance/grade/${grade}` ? 'active' : ''}
                      >
                        Grade {grade}
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </li>

            {/* Marks Management with Dropdown */}
            <li>
              <div 
                className={`dropdown-header ${location.pathname.includes('/admin/marks') ? 'active' : ''}`}
                onClick={handleMarksDropdownToggle}
              >
                <span style={{ marginRight: '10px' }}>📊</span>
                Marks Management
                <span style={{ marginLeft: '10px' }}>{showMarksDropdown ? '▲' : '▼'}</span>
              </div>
              {showMarksDropdown && (
                <ul className="dropdown-menu">
                  {uniqueGrades.map(grade => (
                    <li key={grade}>
                      <Link 
                        to={`/admin/marks/grade/${grade}`} 
                        className={location.pathname === `/admin/marks/grade/${grade}` ? 'active' : ''}
                      >
                        Grade {grade}
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </li>

            {/* System Configuration without Dropdown */}
            <li>
              <Link 
                to="/admin/system-config"
                className={location.pathname === '/admin/system-config' ? 'active' : ''}
                onClick={handleSingleNavClick}
              >
                <span style={{ marginRight: '10px' }}>⚙️</span>
                System Configuration
              </Link>
            </li>
          </ul>
        </nav>
      </div>

      <div className="main-content">
        <div className="header">
          <div className="header-left">
            <h1>Admin Dashboard</h1>
          </div>
          <div className="header-right">
            <div className="user-info">
              <span>Welcome, {user ? `${user.firstName || user.username}` : 'Admin'}</span>
              <ThemeToggle />
              <button className="logout-btn" onClick={handleLogout}>Logout</button>
            </div>
          </div>
        </div>
        {/* Pass academic year context to children */}
        <div className="academic-year-context" data-academic-year={selectedAcademicYear}>
          {children}
        </div>
      </div>
    </div>
  );
};

// Add CSS for the dropdown menu and sidebar academic year filter
const styles = `
  .sidebar-academic-year {
    background-color: #34495e;
    padding: 15px 20px;
    border-bottom: 1px solid #2c3e50;
    margin-bottom: 10px;
  }
  
  .sidebar-academic-year label {
    color: #ecf0f1;
    font-size: 0.9em;
    margin-bottom: 8px;
    display: block;
  }
  
  .sidebar-academic-year select {
    width: 100%;
    padding: 8px 10px;
    border-radius: 4px;
    border: 1px solid #bdc3c7;
    background-color: #ecf0f1;
    color: #2c3e50;
    font-size: 0.9em;
  }
  
  .sidebar-academic-year select:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
  
  .loading-indicator {
    margin-top: 5px;
  }
  
  .loading-indicator small {
    color: #95a5a6;
    font-style: italic;
  }
  
  .academic-year-context {
    height: 100%;
  }
  
  .dropdown-header {
    display: flex;
    align-items: center;
    color: white;
    text-decoration: none;
    padding: 15px 20px;
    cursor: pointer;
    transition: background-color 0.3s;
  }
  
  .dropdown-header:hover,
  .dropdown-header.active {
    background-color: #34495e;
    border-left: 4px solid #3498db;
  }
  
  .dropdown-menu {
    list-style: none;
    background-color: #34495e;
    padding-left: 20px;
    margin-bottom: 10px;
  }
  
  .dropdown-menu a {
    padding: 10px 15px;
    font-size: 0.9em;
    border-left: none;
  }
  
  .dropdown-subheader {
    color: #95a5a6;
    font-size: 0.8em;
    padding: 5px 15px;
    border-bottom: 1px solid #3c536d;
    margin-top: 8px;
  }
  
  .header-left, .header-right {
    display: flex;
    align-items: center;
  }
  
  .header-right {
    display: flex;
    gap: 20px;
  }
`;

// Add the styles to the document
if (typeof document !== 'undefined') {
  const styleElement = document.createElement('style');
  styleElement.textContent = styles;
  document.head.appendChild(styleElement);
}

export default AdminLayout;
