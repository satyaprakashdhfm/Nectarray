// Placeholder admin page for future system-wide settings (academic year
// setup, calendar management, exam schedules). Not implemented yet.
import React from 'react';

const SystemConfiguration = () => {
  return (
    <div className="content-card">
      <h2>System Configuration</h2>
      <p style={{ color: '#7f8c8d' }}>
        ⚙️ Configuration forms and settings will be implemented here.
        <br />
        (Academic year setup, calendar management, examination schedule, etc.)
      </p>
    </div>
  );
};

export default SystemConfiguration;
