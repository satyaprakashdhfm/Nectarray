-- Student Management System: PostgreSQL starter schema and demo data
-- Run once from PowerShell after creating the database:
--   createdb -U postgres student_management
--   psql -U postgres -d student_management -f database/postgresql_starter.sql

BEGIN;

CREATE TABLE IF NOT EXISTS users (
    username VARCHAR(100) PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password TEXT NOT NULL,
    firstname VARCHAR(100),
    lastname VARCHAR(100),
    role VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'teacher', 'student')),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    lastlogin TIMESTAMPTZ,
    createdat TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS teachers (
    teacherid VARCHAR(100) PRIMARY KEY REFERENCES users(username),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phonenumber VARCHAR(20),
    qualification VARCHAR(255),
    subjectshandled JSONB NOT NULL DEFAULT '[]'::jsonb,
    classesassigned JSONB NOT NULL DEFAULT '[]'::jsonb,
    classteacherof VARCHAR(50),
    hiredate DATE,
    salary NUMERIC(12, 2),
    active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS classes (
    classid INTEGER PRIMARY KEY,
    classname VARCHAR(100) NOT NULL,
    section VARCHAR(20) NOT NULL,
    academicyear VARCHAR(20) NOT NULL,
    maxstudents INTEGER NOT NULL DEFAULT 40 CHECK (maxstudents > 0),
    classteacherid VARCHAR(100) REFERENCES teachers(teacherid),
    active BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (classname, section, academicyear)
);

CREATE TABLE IF NOT EXISTS students (
    studentid VARCHAR(100) PRIMARY KEY REFERENCES users(username),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    dateofbirth DATE,
    fathername VARCHAR(255),
    mothername VARCHAR(255),
    parentcontact VARCHAR(20),
    classid INTEGER REFERENCES classes(classid),
    admissiondate DATE,
    status VARCHAR(20) NOT NULL DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS subjects (
    subjectcode VARCHAR(30) PRIMARY KEY,
    subjectname VARCHAR(100) NOT NULL,
    classapplicable VARCHAR(100),
    maxmarksperexam INTEGER NOT NULL DEFAULT 100 CHECK (maxmarksperexam > 0),
    isactive BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS attendance (
    attendanceid VARCHAR(64) PRIMARY KEY,
    studentid VARCHAR(100) NOT NULL REFERENCES students(studentid),
    classid INTEGER NOT NULL REFERENCES classes(classid),
    date DATE NOT NULL,
    period INTEGER NOT NULL DEFAULT 1,
    status VARCHAR(20) NOT NULL CHECK (status IN ('present', 'absent', 'late', 'excused')),
    markedby VARCHAR(100) REFERENCES users(username),
    timestamp TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    subjectcode VARCHAR(30) REFERENCES subjects(subjectcode),
    UNIQUE (studentid, date, period, subjectcode)
);

CREATE TABLE IF NOT EXISTS marks (
    marksid VARCHAR(64) PRIMARY KEY,
    studentid VARCHAR(100) NOT NULL REFERENCES students(studentid),
    classid INTEGER NOT NULL REFERENCES classes(classid),
    examinationtype VARCHAR(50) NOT NULL,
    marksobtained INTEGER NOT NULL CHECK (marksobtained >= 0),
    maxmarks INTEGER NOT NULL CHECK (maxmarks > 0),
    grade VARCHAR(5),
    entrydate DATE NOT NULL DEFAULT CURRENT_DATE,
    subjectcode VARCHAR(30) REFERENCES subjects(subjectcode),
    teacherid VARCHAR(100) REFERENCES teachers(teacherid),
    CHECK (marksobtained <= maxmarks)
);

CREATE TABLE IF NOT EXISTS fees (
    feeid VARCHAR(64) PRIMARY KEY,
    studentid VARCHAR(100) NOT NULL REFERENCES students(studentid),
    classid INTEGER NOT NULL REFERENCES classes(classid),
    feetype VARCHAR(50) NOT NULL,
    amountdue NUMERIC(12, 2) NOT NULL CHECK (amountdue >= 0),
    amountpaid NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (amountpaid >= 0),
    balance NUMERIC(12, 2) NOT NULL,
    academicyear VARCHAR(20) NOT NULL,
    paymentdate DATE,
    paymentmethod VARCHAR(30),
    updatedby VARCHAR(100) REFERENCES users(username)
);

CREATE TABLE IF NOT EXISTS syllabus (
    syllabusid VARCHAR(64) PRIMARY KEY,
    classid INTEGER NOT NULL REFERENCES classes(classid),
    unitname VARCHAR(255) NOT NULL,
    completionstatus VARCHAR(30) NOT NULL DEFAULT 'not_started',
    completionpercentage INTEGER NOT NULL DEFAULT 0 CHECK (completionpercentage BETWEEN 0 AND 100),
    currenttopic TEXT,
    lastupdated TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    subjectcode VARCHAR(30) REFERENCES subjects(subjectcode),
    teacherid VARCHAR(100) REFERENCES teachers(teacherid),
    subtopics JSONB NOT NULL DEFAULT '[]'::jsonb,
    completedsubtopics JSONB NOT NULL DEFAULT '[]'::jsonb
);

CREATE TABLE IF NOT EXISTS schedule_data (
    scheduleid VARCHAR(64) PRIMARY KEY,
    classid INTEGER NOT NULL REFERENCES classes(classid),
    academicyear VARCHAR(20) NOT NULL,
    dayofweek INTEGER CHECK (dayofweek BETWEEN 1 AND 7),
    subjectcode VARCHAR(30) REFERENCES subjects(subjectcode),
    teacherid VARCHAR(100) REFERENCES teachers(teacherid),
    slotnames VARCHAR(100),
    starttime TIME,
    endtime TIME,
    isactive BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS calendar_grid (
    gridid VARCHAR(64) PRIMARY KEY,
    classid INTEGER NOT NULL REFERENCES classes(classid),
    calendardate DATE NOT NULL,
    academicyear VARCHAR(20) NOT NULL,
    daytype VARCHAR(20) NOT NULL DEFAULT 'working',
    holidayname VARCHAR(100),
    examtype VARCHAR(50),
    examsession VARCHAR(50),
    description VARCHAR(255),
    UNIQUE (classid, calendardate)
);

CREATE INDEX IF NOT EXISTS idx_students_classid ON students(classid);
CREATE INDEX IF NOT EXISTS idx_attendance_student_date ON attendance(studentid, date);
CREATE INDEX IF NOT EXISTS idx_marks_studentid ON marks(studentid);
CREATE INDEX IF NOT EXISTS idx_fees_studentid ON fees(studentid);

-- Demo dataset: 1 admin, 3 teachers, 12 students (11 active + 1 inactive) across
-- 3 classes, 5 subjects, a week of attendance, two exams of marks, fees and
-- syllabus progress per class/subject, plus a full weekly timetable and a
-- calendar of working days, holidays and exams. All accounts share one password per
-- role so the FastAPI PBKDF2 verifier can check them: admin/admin123,
-- teacher1-3/teacher123, student1-12/student123.
INSERT INTO users (username, email, password, firstname, lastname, role) VALUES
('admin', 'admin@example.com', 'pbkdf2_sha256$9e2b1848add9e21fb9a447cc378fd0b8$fL/CAecI4r85wpwb7mfcf17P5Qn5ooZVoEjkwP2JzYY=', 'System', 'Admin', 'admin'),
('teacher1', 'teacher@example.com', 'pbkdf2_sha256$54023a79063d11873d1c1f4c4533a8a4$0vFumdhc0l6swQ4x2oeDU6wbha5Oz290hNdUGbPMM5s=', 'Anita', 'Sharma', 'teacher'),
('teacher2', 'teacher2@example.com', 'pbkdf2_sha256$54023a79063d11873d1c1f4c4533a8a4$0vFumdhc0l6swQ4x2oeDU6wbha5Oz290hNdUGbPMM5s=', 'Rohan', 'Mehta', 'teacher'),
('teacher3', 'teacher3@example.com', 'pbkdf2_sha256$54023a79063d11873d1c1f4c4533a8a4$0vFumdhc0l6swQ4x2oeDU6wbha5Oz290hNdUGbPMM5s=', 'Priya', 'Nair', 'teacher'),
('student1', 'student@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Aarav', 'Patel', 'student'),
('student2', 'student2@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Diya', 'Sharma', 'student'),
('student3', 'student3@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Kabir', 'Singh', 'student'),
('student4', 'student4@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Ishita', 'Rao', 'student'),
('student5', 'student5@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Vivaan', 'Gupta', 'student'),
('student6', 'student6@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Ananya', 'Iyer', 'student'),
('student7', 'student7@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Reyansh', 'Kumar', 'student'),
('student8', 'student8@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Saanvi', 'Joshi', 'student'),
('student9', 'student9@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Arjun', 'Reddy', 'student'),
('student10', 'student10@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Myra', 'Verma', 'student'),
('student11', 'student11@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Aditya', 'Nair', 'student'),
('student12', 'student12@example.com', 'pbkdf2_sha256$8744a2737e7fe833ea5981d144cb7095$SaXRy4YwttFZlzeC8so+UX1MO59vnTf9AUsMRAfdpdk=', 'Kiara', 'Menon', 'student')
ON CONFLICT (username) DO NOTHING;

INSERT INTO teachers (teacherid, name, email, phonenumber, qualification, subjectshandled, classesassigned, classteacherof, hiredate, salary) VALUES
('teacher1', 'Anita Sharma', 'teacher@example.com', '9876543210', 'M.Sc. Mathematics', '["MAT10"]', '["1", "2", "3"]', 'Grade 9 - A', '2023-06-01', 45000),
('teacher2', 'Rohan Mehta', 'teacher2@example.com', '9876543212', 'M.Sc. Physics', '["SCI10", "CS10"]', '["1", "2", "3"]', 'Grade 10 - A', '2022-04-10', 48000),
('teacher3', 'Priya Nair', 'teacher3@example.com', '9876543213', 'M.A. English', '["ENG10", "SOC10"]', '["1", "2", "3"]', 'Grade 10 - B', '2021-07-15', 46000)
ON CONFLICT (teacherid) DO NOTHING;

INSERT INTO classes (classid, classname, section, academicyear, maxstudents, classteacherid) VALUES
(1, 'Grade 9', 'A', '2024-2025', 40, 'teacher1'),
(2, 'Grade 10', 'A', '2024-2025', 40, 'teacher2'),
(3, 'Grade 10', 'B', '2024-2025', 40, 'teacher3')
ON CONFLICT (classid) DO NOTHING;

INSERT INTO subjects (subjectcode, subjectname, classapplicable, maxmarksperexam) VALUES
('MAT10', 'Mathematics', 'Grade 9,Grade 10', 100),
('SCI10', 'Science', 'Grade 9,Grade 10', 100),
('ENG10', 'English', 'Grade 9,Grade 10', 100),
('SOC10', 'Social Studies', 'Grade 9,Grade 10', 100),
('CS10', 'Computer Science', 'Grade 9,Grade 10', 100)
ON CONFLICT (subjectcode) DO NOTHING;

INSERT INTO students (studentid, name, email, phone, address, dateofbirth, fathername, mothername, parentcontact, classid, admissiondate, status) VALUES
('student1', 'Aarav Patel', 'student@example.com', '9876543211', 'Pune', '2008-05-14', 'Ravi Patel', 'Meera Patel', '9876543211', 1, '2024-06-01', 'active'),
('student2', 'Diya Sharma', 'student2@example.com', '9876543221', 'Pune', '2008-08-21', 'Sanjay Sharma', 'Neha Sharma', '9876543221', 1, '2024-06-01', 'active'),
('student3', 'Kabir Singh', 'student3@example.com', '9876543222', 'Mumbai', '2008-02-02', 'Manpreet Singh', 'Simran Kaur', '9876543222', 1, '2024-06-01', 'active'),
('student4', 'Ishita Rao', 'student4@example.com', '9876543223', 'Pune', '2008-11-30', 'Suresh Rao', 'Lakshmi Rao', '9876543223', 1, '2024-06-01', 'active'),
('student5', 'Vivaan Gupta', 'student5@example.com', '9876543224', 'Delhi', '2007-06-18', 'Anil Gupta', 'Pooja Gupta', '9876543224', 2, '2024-06-01', 'active'),
('student6', 'Ananya Iyer', 'student6@example.com', '9876543225', 'Chennai', '2007-09-09', 'Krishnan Iyer', 'Divya Iyer', '9876543225', 2, '2024-06-01', 'active'),
('student7', 'Reyansh Kumar', 'student7@example.com', '9876543226', 'Delhi', '2007-01-27', 'Rakesh Kumar', 'Sunita Kumar', '9876543226', 2, '2024-06-01', 'active'),
('student8', 'Saanvi Joshi', 'student8@example.com', '9876543227', 'Nashik', '2007-04-12', 'Mahesh Joshi', 'Kavita Joshi', '9876543227', 2, '2024-06-01', 'active'),
('student9', 'Arjun Reddy', 'student9@example.com', '9876543228', 'Hyderabad', '2007-07-07', 'Srinivas Reddy', 'Padma Reddy', '9876543228', 3, '2024-06-01', 'active'),
('student10', 'Myra Verma', 'student10@example.com', '9876543229', 'Hyderabad', '2007-03-15', 'Ashok Verma', 'Ritu Verma', '9876543229', 3, '2024-06-01', 'active'),
('student11', 'Aditya Nair', 'student11@example.com', '9876543230', 'Bengaluru', '2007-10-05', 'Vijay Nair', 'Geetha Nair', '9876543230', 3, '2024-06-01', 'active'),
('student12', 'Kiara Menon', 'student12@example.com', '9876543231', 'Bengaluru', '2007-12-23', 'Suresh Menon', 'Anju Menon', '9876543231', 3, '2024-06-01', 'inactive')
ON CONFLICT (studentid) DO NOTHING;

-- One school week (today back to 6 days ago) per active student, on their class's core subject.
INSERT INTO attendance (attendanceid, studentid, classid, date, period, status, markedby, subjectcode) VALUES
('00000101-0000-0000-0000-000000000000', 'student1', 1, CURRENT_DATE - INTERVAL '6 days', 1, 'present', 'teacher1', 'MAT10'),
('00000102-0000-0000-0000-000000000000', 'student1', 1, CURRENT_DATE - INTERVAL '5 days', 1, 'present', 'teacher1', 'MAT10'),
('00000103-0000-0000-0000-000000000000', 'student1', 1, CURRENT_DATE - INTERVAL '4 days', 1, 'present', 'teacher1', 'MAT10'),
('00000104-0000-0000-0000-000000000000', 'student1', 1, CURRENT_DATE - INTERVAL '3 days', 1, 'absent', 'teacher1', 'MAT10'),
('00000105-0000-0000-0000-000000000000', 'student1', 1, CURRENT_DATE - INTERVAL '2 days', 1, 'present', 'teacher1', 'MAT10'),
('00000106-0000-0000-0000-000000000000', 'student1', 1, CURRENT_DATE - INTERVAL '1 days', 1, 'late', 'teacher1', 'MAT10'),
('00000107-0000-0000-0000-000000000000', 'student1', 1, CURRENT_DATE - INTERVAL '0 days', 1, 'present', 'teacher1', 'MAT10'),
('00000108-0000-0000-0000-000000000000', 'student2', 1, CURRENT_DATE - INTERVAL '6 days', 1, 'present', 'teacher1', 'MAT10'),
('00000109-0000-0000-0000-000000000000', 'student2', 1, CURRENT_DATE - INTERVAL '5 days', 1, 'present', 'teacher1', 'MAT10'),
('00000110-0000-0000-0000-000000000000', 'student2', 1, CURRENT_DATE - INTERVAL '4 days', 1, 'present', 'teacher1', 'MAT10'),
('00000111-0000-0000-0000-000000000000', 'student2', 1, CURRENT_DATE - INTERVAL '3 days', 1, 'absent', 'teacher1', 'MAT10'),
('00000112-0000-0000-0000-000000000000', 'student2', 1, CURRENT_DATE - INTERVAL '2 days', 1, 'present', 'teacher1', 'MAT10'),
('00000113-0000-0000-0000-000000000000', 'student2', 1, CURRENT_DATE - INTERVAL '1 days', 1, 'late', 'teacher1', 'MAT10'),
('00000114-0000-0000-0000-000000000000', 'student2', 1, CURRENT_DATE - INTERVAL '0 days', 1, 'present', 'teacher1', 'MAT10'),
('00000115-0000-0000-0000-000000000000', 'student3', 1, CURRENT_DATE - INTERVAL '6 days', 1, 'present', 'teacher1', 'MAT10'),
('00000116-0000-0000-0000-000000000000', 'student3', 1, CURRENT_DATE - INTERVAL '5 days', 1, 'present', 'teacher1', 'MAT10'),
('00000117-0000-0000-0000-000000000000', 'student3', 1, CURRENT_DATE - INTERVAL '4 days', 1, 'present', 'teacher1', 'MAT10'),
('00000118-0000-0000-0000-000000000000', 'student3', 1, CURRENT_DATE - INTERVAL '3 days', 1, 'absent', 'teacher1', 'MAT10'),
('00000119-0000-0000-0000-000000000000', 'student3', 1, CURRENT_DATE - INTERVAL '2 days', 1, 'present', 'teacher1', 'MAT10'),
('00000120-0000-0000-0000-000000000000', 'student3', 1, CURRENT_DATE - INTERVAL '1 days', 1, 'late', 'teacher1', 'MAT10'),
('00000121-0000-0000-0000-000000000000', 'student3', 1, CURRENT_DATE - INTERVAL '0 days', 1, 'present', 'teacher1', 'MAT10'),
('00000122-0000-0000-0000-000000000000', 'student4', 1, CURRENT_DATE - INTERVAL '6 days', 1, 'present', 'teacher1', 'MAT10'),
('00000123-0000-0000-0000-000000000000', 'student4', 1, CURRENT_DATE - INTERVAL '5 days', 1, 'present', 'teacher1', 'MAT10'),
('00000124-0000-0000-0000-000000000000', 'student4', 1, CURRENT_DATE - INTERVAL '4 days', 1, 'present', 'teacher1', 'MAT10'),
('00000125-0000-0000-0000-000000000000', 'student4', 1, CURRENT_DATE - INTERVAL '3 days', 1, 'absent', 'teacher1', 'MAT10'),
('00000126-0000-0000-0000-000000000000', 'student4', 1, CURRENT_DATE - INTERVAL '2 days', 1, 'present', 'teacher1', 'MAT10'),
('00000127-0000-0000-0000-000000000000', 'student4', 1, CURRENT_DATE - INTERVAL '1 days', 1, 'late', 'teacher1', 'MAT10'),
('00000128-0000-0000-0000-000000000000', 'student4', 1, CURRENT_DATE - INTERVAL '0 days', 1, 'present', 'teacher1', 'MAT10'),
('00000129-0000-0000-0000-000000000000', 'student5', 2, CURRENT_DATE - INTERVAL '6 days', 1, 'present', 'teacher2', 'SCI10'),
('00000130-0000-0000-0000-000000000000', 'student5', 2, CURRENT_DATE - INTERVAL '5 days', 1, 'present', 'teacher2', 'SCI10'),
('00000131-0000-0000-0000-000000000000', 'student5', 2, CURRENT_DATE - INTERVAL '4 days', 1, 'present', 'teacher2', 'SCI10'),
('00000132-0000-0000-0000-000000000000', 'student5', 2, CURRENT_DATE - INTERVAL '3 days', 1, 'absent', 'teacher2', 'SCI10'),
('00000133-0000-0000-0000-000000000000', 'student5', 2, CURRENT_DATE - INTERVAL '2 days', 1, 'present', 'teacher2', 'SCI10'),
('00000134-0000-0000-0000-000000000000', 'student5', 2, CURRENT_DATE - INTERVAL '1 days', 1, 'late', 'teacher2', 'SCI10'),
('00000135-0000-0000-0000-000000000000', 'student5', 2, CURRENT_DATE - INTERVAL '0 days', 1, 'present', 'teacher2', 'SCI10'),
('00000136-0000-0000-0000-000000000000', 'student6', 2, CURRENT_DATE - INTERVAL '6 days', 1, 'present', 'teacher2', 'SCI10'),
('00000137-0000-0000-0000-000000000000', 'student6', 2, CURRENT_DATE - INTERVAL '5 days', 1, 'present', 'teacher2', 'SCI10'),
('00000138-0000-0000-0000-000000000000', 'student6', 2, CURRENT_DATE - INTERVAL '4 days', 1, 'present', 'teacher2', 'SCI10'),
('00000139-0000-0000-0000-000000000000', 'student6', 2, CURRENT_DATE - INTERVAL '3 days', 1, 'absent', 'teacher2', 'SCI10'),
('00000140-0000-0000-0000-000000000000', 'student6', 2, CURRENT_DATE - INTERVAL '2 days', 1, 'present', 'teacher2', 'SCI10'),
('00000141-0000-0000-0000-000000000000', 'student6', 2, CURRENT_DATE - INTERVAL '1 days', 1, 'late', 'teacher2', 'SCI10'),
('00000142-0000-0000-0000-000000000000', 'student6', 2, CURRENT_DATE - INTERVAL '0 days', 1, 'present', 'teacher2', 'SCI10'),
('00000143-0000-0000-0000-000000000000', 'student7', 2, CURRENT_DATE - INTERVAL '6 days', 1, 'present', 'teacher2', 'SCI10'),
('00000144-0000-0000-0000-000000000000', 'student7', 2, CURRENT_DATE - INTERVAL '5 days', 1, 'present', 'teacher2', 'SCI10'),
('00000145-0000-0000-0000-000000000000', 'student7', 2, CURRENT_DATE - INTERVAL '4 days', 1, 'present', 'teacher2', 'SCI10'),
('00000146-0000-0000-0000-000000000000', 'student7', 2, CURRENT_DATE - INTERVAL '3 days', 1, 'absent', 'teacher2', 'SCI10'),
('00000147-0000-0000-0000-000000000000', 'student7', 2, CURRENT_DATE - INTERVAL '2 days', 1, 'present', 'teacher2', 'SCI10'),
('00000148-0000-0000-0000-000000000000', 'student7', 2, CURRENT_DATE - INTERVAL '1 days', 1, 'late', 'teacher2', 'SCI10'),
('00000149-0000-0000-0000-000000000000', 'student7', 2, CURRENT_DATE - INTERVAL '0 days', 1, 'present', 'teacher2', 'SCI10'),
('00000150-0000-0000-0000-000000000000', 'student8', 2, CURRENT_DATE - INTERVAL '6 days', 1, 'present', 'teacher2', 'SCI10'),
('00000151-0000-0000-0000-000000000000', 'student8', 2, CURRENT_DATE - INTERVAL '5 days', 1, 'present', 'teacher2', 'SCI10'),
('00000152-0000-0000-0000-000000000000', 'student8', 2, CURRENT_DATE - INTERVAL '4 days', 1, 'present', 'teacher2', 'SCI10'),
('00000153-0000-0000-0000-000000000000', 'student8', 2, CURRENT_DATE - INTERVAL '3 days', 1, 'absent', 'teacher2', 'SCI10'),
('00000154-0000-0000-0000-000000000000', 'student8', 2, CURRENT_DATE - INTERVAL '2 days', 1, 'present', 'teacher2', 'SCI10'),
('00000155-0000-0000-0000-000000000000', 'student8', 2, CURRENT_DATE - INTERVAL '1 days', 1, 'late', 'teacher2', 'SCI10'),
('00000156-0000-0000-0000-000000000000', 'student8', 2, CURRENT_DATE - INTERVAL '0 days', 1, 'present', 'teacher2', 'SCI10'),
('00000157-0000-0000-0000-000000000000', 'student9', 3, CURRENT_DATE - INTERVAL '6 days', 1, 'present', 'teacher3', 'ENG10'),
('00000158-0000-0000-0000-000000000000', 'student9', 3, CURRENT_DATE - INTERVAL '5 days', 1, 'present', 'teacher3', 'ENG10'),
('00000159-0000-0000-0000-000000000000', 'student9', 3, CURRENT_DATE - INTERVAL '4 days', 1, 'present', 'teacher3', 'ENG10'),
('00000160-0000-0000-0000-000000000000', 'student9', 3, CURRENT_DATE - INTERVAL '3 days', 1, 'absent', 'teacher3', 'ENG10'),
('00000161-0000-0000-0000-000000000000', 'student9', 3, CURRENT_DATE - INTERVAL '2 days', 1, 'present', 'teacher3', 'ENG10'),
('00000162-0000-0000-0000-000000000000', 'student9', 3, CURRENT_DATE - INTERVAL '1 days', 1, 'late', 'teacher3', 'ENG10'),
('00000163-0000-0000-0000-000000000000', 'student9', 3, CURRENT_DATE - INTERVAL '0 days', 1, 'present', 'teacher3', 'ENG10'),
('00000164-0000-0000-0000-000000000000', 'student10', 3, CURRENT_DATE - INTERVAL '6 days', 1, 'present', 'teacher3', 'ENG10'),
('00000165-0000-0000-0000-000000000000', 'student10', 3, CURRENT_DATE - INTERVAL '5 days', 1, 'present', 'teacher3', 'ENG10'),
('00000166-0000-0000-0000-000000000000', 'student10', 3, CURRENT_DATE - INTERVAL '4 days', 1, 'present', 'teacher3', 'ENG10'),
('00000167-0000-0000-0000-000000000000', 'student10', 3, CURRENT_DATE - INTERVAL '3 days', 1, 'absent', 'teacher3', 'ENG10'),
('00000168-0000-0000-0000-000000000000', 'student10', 3, CURRENT_DATE - INTERVAL '2 days', 1, 'present', 'teacher3', 'ENG10'),
('00000169-0000-0000-0000-000000000000', 'student10', 3, CURRENT_DATE - INTERVAL '1 days', 1, 'late', 'teacher3', 'ENG10'),
('00000170-0000-0000-0000-000000000000', 'student10', 3, CURRENT_DATE - INTERVAL '0 days', 1, 'present', 'teacher3', 'ENG10'),
('00000171-0000-0000-0000-000000000000', 'student11', 3, CURRENT_DATE - INTERVAL '6 days', 1, 'present', 'teacher3', 'ENG10'),
('00000172-0000-0000-0000-000000000000', 'student11', 3, CURRENT_DATE - INTERVAL '5 days', 1, 'present', 'teacher3', 'ENG10'),
('00000173-0000-0000-0000-000000000000', 'student11', 3, CURRENT_DATE - INTERVAL '4 days', 1, 'present', 'teacher3', 'ENG10'),
('00000174-0000-0000-0000-000000000000', 'student11', 3, CURRENT_DATE - INTERVAL '3 days', 1, 'absent', 'teacher3', 'ENG10'),
('00000175-0000-0000-0000-000000000000', 'student11', 3, CURRENT_DATE - INTERVAL '2 days', 1, 'present', 'teacher3', 'ENG10'),
('00000176-0000-0000-0000-000000000000', 'student11', 3, CURRENT_DATE - INTERVAL '1 days', 1, 'late', 'teacher3', 'ENG10'),
('00000177-0000-0000-0000-000000000000', 'student11', 3, CURRENT_DATE - INTERVAL '0 days', 1, 'present', 'teacher3', 'ENG10')
ON CONFLICT DO NOTHING;

-- Two exams (Unit Test 1, Mid Term) across the three core subjects for every active student.
INSERT INTO marks (marksid, studentid, classid, examinationtype, marksobtained, maxmarks, grade, subjectcode, teacherid) VALUES
('00000178-0000-0000-0000-000000000000', 'student1', 1, 'Unit Test 1', 65, 100, 'C', 'MAT10', 'teacher1'),
('00000179-0000-0000-0000-000000000000', 'student1', 1, 'Mid Term', 59, 100, 'D', 'MAT10', 'teacher1'),
('00000180-0000-0000-0000-000000000000', 'student1', 1, 'Unit Test 1', 75, 100, 'B', 'SCI10', 'teacher2'),
('00000181-0000-0000-0000-000000000000', 'student1', 1, 'Mid Term', 73, 100, 'C', 'SCI10', 'teacher2'),
('00000182-0000-0000-0000-000000000000', 'student1', 1, 'Unit Test 1', 72, 100, 'C', 'ENG10', 'teacher3'),
('00000183-0000-0000-0000-000000000000', 'student1', 1, 'Mid Term', 66, 100, 'C', 'ENG10', 'teacher3'),
('00000184-0000-0000-0000-000000000000', 'student2', 1, 'Unit Test 1', 64, 100, 'C', 'MAT10', 'teacher1'),
('00000185-0000-0000-0000-000000000000', 'student2', 1, 'Mid Term', 92, 100, 'A', 'MAT10', 'teacher1'),
('00000186-0000-0000-0000-000000000000', 'student2', 1, 'Unit Test 1', 63, 100, 'C', 'SCI10', 'teacher2'),
('00000187-0000-0000-0000-000000000000', 'student2', 1, 'Mid Term', 95, 100, 'A', 'SCI10', 'teacher2'),
('00000188-0000-0000-0000-000000000000', 'student2', 1, 'Unit Test 1', 85, 100, 'B', 'ENG10', 'teacher3'),
('00000189-0000-0000-0000-000000000000', 'student2', 1, 'Mid Term', 60, 100, 'C', 'ENG10', 'teacher3'),
('00000190-0000-0000-0000-000000000000', 'student3', 1, 'Unit Test 1', 59, 100, 'D', 'MAT10', 'teacher1'),
('00000191-0000-0000-0000-000000000000', 'student3', 1, 'Mid Term', 63, 100, 'C', 'MAT10', 'teacher1'),
('00000192-0000-0000-0000-000000000000', 'student3', 1, 'Unit Test 1', 71, 100, 'C', 'SCI10', 'teacher2'),
('00000193-0000-0000-0000-000000000000', 'student3', 1, 'Mid Term', 72, 100, 'C', 'SCI10', 'teacher2'),
('00000194-0000-0000-0000-000000000000', 'student3', 1, 'Unit Test 1', 90, 100, 'A', 'ENG10', 'teacher3'),
('00000195-0000-0000-0000-000000000000', 'student3', 1, 'Mid Term', 96, 100, 'A', 'ENG10', 'teacher3'),
('00000196-0000-0000-0000-000000000000', 'student4', 1, 'Unit Test 1', 59, 100, 'D', 'MAT10', 'teacher1'),
('00000197-0000-0000-0000-000000000000', 'student4', 1, 'Mid Term', 93, 100, 'A', 'MAT10', 'teacher1'),
('00000198-0000-0000-0000-000000000000', 'student4', 1, 'Unit Test 1', 70, 100, 'C', 'SCI10', 'teacher2'),
('00000199-0000-0000-0000-000000000000', 'student4', 1, 'Mid Term', 92, 100, 'A', 'SCI10', 'teacher2'),
('00000200-0000-0000-0000-000000000000', 'student4', 1, 'Unit Test 1', 84, 100, 'B', 'ENG10', 'teacher3'),
('00000201-0000-0000-0000-000000000000', 'student4', 1, 'Mid Term', 72, 100, 'C', 'ENG10', 'teacher3'),
('00000202-0000-0000-0000-000000000000', 'student5', 2, 'Unit Test 1', 86, 100, 'B', 'MAT10', 'teacher1'),
('00000203-0000-0000-0000-000000000000', 'student5', 2, 'Mid Term', 95, 100, 'A', 'MAT10', 'teacher1'),
('00000204-0000-0000-0000-000000000000', 'student5', 2, 'Unit Test 1', 75, 100, 'B', 'SCI10', 'teacher2'),
('00000205-0000-0000-0000-000000000000', 'student5', 2, 'Mid Term', 58, 100, 'D', 'SCI10', 'teacher2'),
('00000206-0000-0000-0000-000000000000', 'student5', 2, 'Unit Test 1', 68, 100, 'C', 'ENG10', 'teacher3'),
('00000207-0000-0000-0000-000000000000', 'student5', 2, 'Mid Term', 85, 100, 'B', 'ENG10', 'teacher3'),
('00000208-0000-0000-0000-000000000000', 'student6', 2, 'Unit Test 1', 79, 100, 'B', 'MAT10', 'teacher1'),
('00000209-0000-0000-0000-000000000000', 'student6', 2, 'Mid Term', 75, 100, 'B', 'MAT10', 'teacher1'),
('00000210-0000-0000-0000-000000000000', 'student6', 2, 'Unit Test 1', 67, 100, 'C', 'SCI10', 'teacher2'),
('00000211-0000-0000-0000-000000000000', 'student6', 2, 'Mid Term', 71, 100, 'C', 'SCI10', 'teacher2'),
('00000212-0000-0000-0000-000000000000', 'student6', 2, 'Unit Test 1', 79, 100, 'B', 'ENG10', 'teacher3'),
('00000213-0000-0000-0000-000000000000', 'student6', 2, 'Mid Term', 64, 100, 'C', 'ENG10', 'teacher3'),
('00000214-0000-0000-0000-000000000000', 'student7', 2, 'Unit Test 1', 63, 100, 'C', 'MAT10', 'teacher1'),
('00000215-0000-0000-0000-000000000000', 'student7', 2, 'Mid Term', 82, 100, 'B', 'MAT10', 'teacher1'),
('00000216-0000-0000-0000-000000000000', 'student7', 2, 'Unit Test 1', 64, 100, 'C', 'SCI10', 'teacher2'),
('00000217-0000-0000-0000-000000000000', 'student7', 2, 'Mid Term', 80, 100, 'B', 'SCI10', 'teacher2'),
('00000218-0000-0000-0000-000000000000', 'student7', 2, 'Unit Test 1', 80, 100, 'B', 'ENG10', 'teacher3'),
('00000219-0000-0000-0000-000000000000', 'student7', 2, 'Mid Term', 96, 100, 'A', 'ENG10', 'teacher3'),
('00000220-0000-0000-0000-000000000000', 'student8', 2, 'Unit Test 1', 74, 100, 'C', 'MAT10', 'teacher1'),
('00000221-0000-0000-0000-000000000000', 'student8', 2, 'Mid Term', 60, 100, 'C', 'MAT10', 'teacher1'),
('00000222-0000-0000-0000-000000000000', 'student8', 2, 'Unit Test 1', 87, 100, 'B', 'SCI10', 'teacher2'),
('00000223-0000-0000-0000-000000000000', 'student8', 2, 'Mid Term', 92, 100, 'A', 'SCI10', 'teacher2'),
('00000224-0000-0000-0000-000000000000', 'student8', 2, 'Unit Test 1', 65, 100, 'C', 'ENG10', 'teacher3'),
('00000225-0000-0000-0000-000000000000', 'student8', 2, 'Mid Term', 82, 100, 'B', 'ENG10', 'teacher3'),
('00000226-0000-0000-0000-000000000000', 'student9', 3, 'Unit Test 1', 63, 100, 'C', 'MAT10', 'teacher1'),
('00000227-0000-0000-0000-000000000000', 'student9', 3, 'Mid Term', 93, 100, 'A', 'MAT10', 'teacher1'),
('00000228-0000-0000-0000-000000000000', 'student9', 3, 'Unit Test 1', 76, 100, 'B', 'SCI10', 'teacher2'),
('00000229-0000-0000-0000-000000000000', 'student9', 3, 'Mid Term', 81, 100, 'B', 'SCI10', 'teacher2'),
('00000230-0000-0000-0000-000000000000', 'student9', 3, 'Unit Test 1', 94, 100, 'A', 'ENG10', 'teacher3'),
('00000231-0000-0000-0000-000000000000', 'student9', 3, 'Mid Term', 70, 100, 'C', 'ENG10', 'teacher3'),
('00000232-0000-0000-0000-000000000000', 'student10', 3, 'Unit Test 1', 62, 100, 'C', 'MAT10', 'teacher1'),
('00000233-0000-0000-0000-000000000000', 'student10', 3, 'Mid Term', 60, 100, 'C', 'MAT10', 'teacher1'),
('00000234-0000-0000-0000-000000000000', 'student10', 3, 'Unit Test 1', 72, 100, 'C', 'SCI10', 'teacher2'),
('00000235-0000-0000-0000-000000000000', 'student10', 3, 'Mid Term', 76, 100, 'B', 'SCI10', 'teacher2'),
('00000236-0000-0000-0000-000000000000', 'student10', 3, 'Unit Test 1', 63, 100, 'C', 'ENG10', 'teacher3'),
('00000237-0000-0000-0000-000000000000', 'student10', 3, 'Mid Term', 72, 100, 'C', 'ENG10', 'teacher3'),
('00000238-0000-0000-0000-000000000000', 'student11', 3, 'Unit Test 1', 64, 100, 'C', 'MAT10', 'teacher1'),
('00000239-0000-0000-0000-000000000000', 'student11', 3, 'Mid Term', 82, 100, 'B', 'MAT10', 'teacher1'),
('00000240-0000-0000-0000-000000000000', 'student11', 3, 'Unit Test 1', 75, 100, 'B', 'SCI10', 'teacher2'),
('00000241-0000-0000-0000-000000000000', 'student11', 3, 'Mid Term', 87, 100, 'B', 'SCI10', 'teacher2'),
('00000242-0000-0000-0000-000000000000', 'student11', 3, 'Unit Test 1', 81, 100, 'B', 'ENG10', 'teacher3'),
('00000243-0000-0000-0000-000000000000', 'student11', 3, 'Mid Term', 68, 100, 'C', 'ENG10', 'teacher3')
ON CONFLICT DO NOTHING;

-- Tuition and Transport fees per active student, with a mix of fully paid, partial and unpaid balances.
INSERT INTO fees (feeid, studentid, classid, feetype, amountdue, amountpaid, balance, academicyear, paymentdate, paymentmethod, updatedby) VALUES
('00000244-0000-0000-0000-000000000000', 'student1', 1, 'Tuition', 25000, 25000, 0, '2024-2025', CURRENT_DATE, 'UPI', 'admin'),
('00000245-0000-0000-0000-000000000000', 'student1', 1, 'Transport', 8000, 8000, 0, '2024-2025', CURRENT_DATE, 'Cash', 'admin'),
('00000246-0000-0000-0000-000000000000', 'student2', 1, 'Tuition', 25000, 10000, 15000, '2024-2025', CURRENT_DATE, 'UPI', 'admin'),
('00000247-0000-0000-0000-000000000000', 'student2', 1, 'Transport', 8000, 8000, 0, '2024-2025', CURRENT_DATE, 'Cash', 'admin'),
('00000248-0000-0000-0000-000000000000', 'student3', 1, 'Tuition', 25000, 25000, 0, '2024-2025', CURRENT_DATE, 'UPI', 'admin'),
('00000249-0000-0000-0000-000000000000', 'student3', 1, 'Transport', 8000, 8000, 0, '2024-2025', CURRENT_DATE, 'Cash', 'admin'),
('00000250-0000-0000-0000-000000000000', 'student4', 1, 'Tuition', 25000, 25000, 0, '2024-2025', CURRENT_DATE, 'UPI', 'admin'),
('00000251-0000-0000-0000-000000000000', 'student4', 1, 'Transport', 8000, 8000, 0, '2024-2025', CURRENT_DATE, 'Cash', 'admin'),
('00000252-0000-0000-0000-000000000000', 'student5', 2, 'Tuition', 25000, 15000, 10000, '2024-2025', CURRENT_DATE, 'UPI', 'admin'),
('00000253-0000-0000-0000-000000000000', 'student5', 2, 'Transport', 8000, 8000, 0, '2024-2025', CURRENT_DATE, 'Cash', 'admin'),
('00000254-0000-0000-0000-000000000000', 'student6', 2, 'Tuition', 25000, 25000, 0, '2024-2025', CURRENT_DATE, 'UPI', 'admin'),
('00000255-0000-0000-0000-000000000000', 'student6', 2, 'Transport', 8000, 0, 8000, '2024-2025', CURRENT_DATE, 'Cash', 'admin'),
('00000256-0000-0000-0000-000000000000', 'student7', 2, 'Tuition', 25000, 10000, 15000, '2024-2025', CURRENT_DATE, 'UPI', 'admin'),
('00000257-0000-0000-0000-000000000000', 'student7', 2, 'Transport', 8000, 8000, 0, '2024-2025', CURRENT_DATE, 'Cash', 'admin'),
('00000258-0000-0000-0000-000000000000', 'student8', 2, 'Tuition', 25000, 15000, 10000, '2024-2025', CURRENT_DATE, 'UPI', 'admin'),
('00000259-0000-0000-0000-000000000000', 'student8', 2, 'Transport', 8000, 8000, 0, '2024-2025', CURRENT_DATE, 'Cash', 'admin'),
('00000260-0000-0000-0000-000000000000', 'student9', 3, 'Tuition', 25000, 10000, 15000, '2024-2025', CURRENT_DATE, 'UPI', 'admin'),
('00000261-0000-0000-0000-000000000000', 'student9', 3, 'Transport', 8000, 8000, 0, '2024-2025', CURRENT_DATE, 'Cash', 'admin'),
('00000262-0000-0000-0000-000000000000', 'student10', 3, 'Tuition', 25000, 25000, 0, '2024-2025', CURRENT_DATE, 'UPI', 'admin'),
('00000263-0000-0000-0000-000000000000', 'student10', 3, 'Transport', 8000, 8000, 0, '2024-2025', CURRENT_DATE, 'Cash', 'admin'),
('00000264-0000-0000-0000-000000000000', 'student11', 3, 'Tuition', 25000, 25000, 0, '2024-2025', CURRENT_DATE, 'UPI', 'admin'),
('00000265-0000-0000-0000-000000000000', 'student11', 3, 'Transport', 8000, 0, 8000, '2024-2025', CURRENT_DATE, 'Cash', 'admin')
ON CONFLICT DO NOTHING;

-- One syllabus unit per class/core-subject combination, at varying completion stages.
INSERT INTO syllabus (syllabusid, classid, unitname, completionstatus, completionpercentage, currenttopic, subjectcode, teacherid, subtopics, completedsubtopics) VALUES
('00000266-0000-0000-0000-000000000000', 1, 'Algebra Foundations', 'in_progress', 60, 'Linear equations', 'MAT10', 'teacher1', '["Variables", "Linear equations", "Quadratic equations"]', '["Variables", "Linear equations"]'),
('00000267-0000-0000-0000-000000000000', 1, 'Motion and Force', 'completed', 100, 'Newtons Laws of Motion', 'SCI10', 'teacher2', '["Speed and velocity", "Newtons Laws of Motion"]', '["Speed and velocity", "Newtons Laws of Motion"]'),
('00000268-0000-0000-0000-000000000000', 1, 'Prose and Poetry', 'not_started', 0, NULL, 'ENG10', 'teacher3', '["Poetic devices", "Comprehension"]', '[]'),
('00000269-0000-0000-0000-000000000000', 2, 'Trigonometry Basics', 'in_progress', 45, 'Trigonometric ratios', 'MAT10', 'teacher1', '["Angles", "Trigonometric ratios", "Identities"]', '["Angles"]'),
('00000270-0000-0000-0000-000000000000', 2, 'Chemical Reactions', 'in_progress', 70, 'Balancing equations', 'SCI10', 'teacher2', '["Types of reactions", "Balancing equations"]', '["Types of reactions"]'),
('00000271-0000-0000-0000-000000000000', 2, 'Grammar Essentials', 'completed', 100, 'Tenses', 'ENG10', 'teacher3', '["Parts of speech", "Tenses"]', '["Parts of speech", "Tenses"]'),
('00000272-0000-0000-0000-000000000000', 3, 'Statistics', 'not_started', 0, NULL, 'MAT10', 'teacher1', '["Mean median and mode", "Standard deviation"]', '[]'),
('00000273-0000-0000-0000-000000000000', 3, 'Electricity', 'in_progress', 30, 'Ohms Law', 'SCI10', 'teacher2', '["Circuits", "Ohms Law"]', '[]'),
('00000274-0000-0000-0000-000000000000', 3, 'Letter Writing', 'completed', 100, 'Formal letters', 'ENG10', 'teacher3', '["Informal letters", "Formal letters"]', '["Informal letters", "Formal letters"]')
ON CONFLICT DO NOTHING;

-- Recurring weekly timetable: every class, Monday to Friday, nine teaching
-- periods (lunch is a fixed break and is not stored). Subjects rotate by
-- (class + weekday + period) so no class repeats a subject in the same slot
-- two days running. This mirrors _seed_timetable() in backend/app/database/seed.py.
WITH periods(period_index, slot_name, start_time, end_time) AS (VALUES
    (0, 'Period 1', TIME '09:00', TIME '09:40'),
    (1, 'Period 2', TIME '09:40', TIME '10:20'),
    (2, 'Period 3', TIME '10:20', TIME '11:00'),
    (3, 'Period 4', TIME '11:00', TIME '11:40'),
    (5, 'Period 5', TIME '12:20', TIME '13:00'),
    (6, 'Period 6', TIME '13:00', TIME '13:40'),
    (7, 'Period 7', TIME '13:40', TIME '14:20'),
    (8, 'Period 8', TIME '14:20', TIME '15:00'),
    (9, 'Period 9', TIME '15:00', TIME '15:40')
), staff(idx, subjectcode, teacherid) AS (VALUES
    (0, 'MAT10', 'teacher1'),
    (1, 'SCI10', 'teacher2'),
    (2, 'ENG10', 'teacher3'),
    (3, 'SOC10', 'teacher3'),
    (4, 'CS10', 'teacher2')
)
INSERT INTO schedule_data (scheduleid, classid, academicyear, dayofweek, subjectcode, teacherid, slotnames, starttime, endtime, isactive)
SELECT
    'sch-' || c.classid || '-' || d.dayofweek || '-' || p.period_index,
    c.classid,
    '2024-2025',
    d.dayofweek,
    s.subjectcode,
    s.teacherid,
    p.slot_name,
    p.start_time,
    p.end_time,
    TRUE
FROM classes c
CROSS JOIN generate_series(1, 5) AS d(dayofweek)
CROSS JOIN periods p
JOIN staff s ON s.idx = ((c.classid - 1) + d.dayofweek + p.period_index) % 5
ON CONFLICT DO NOTHING;

-- Calendar: every weekday from 35 days ago to 120 days ahead starts as a
-- working day. Generated relative to CURRENT_DATE so the demo always has
-- recent history and upcoming events, whenever the project is set up.
INSERT INTO calendar_grid (gridid, classid, calendardate, academicyear, daytype)
SELECT
    'cal-' || c.classid || '-' || d::date,
    c.classid,
    d::date,
    '2024-2025',
    'working'
FROM classes c
CROSS JOIN generate_series(CURRENT_DATE - INTERVAL '35 days', CURRENT_DATE + INTERVAL '120 days', INTERVAL '1 day') AS d
WHERE EXTRACT(ISODOW FROM d) <= 5
ON CONFLICT (classid, calendardate) DO NOTHING;

-- Named holidays, nudged forward off a weekend so they land on a day the
-- timetable grid actually shows.
WITH holiday(offset_days, holiday_name, note) AS (VALUES
    (-21, 'Independence Day', 'National holiday - school closed'),
    (-7, 'Staff Development Day', 'No classes; teacher training in progress'),
    (9, 'Autumn Break', 'Mid-term break for all classes'),
    (23, 'Founders Day', 'School foundation day celebrations'),
    (47, 'Winter Break', 'Winter vacation begins'),
    (76, 'Annual Sports Day', 'Inter-house athletics meet; no regular classes')
)
UPDATE calendar_grid g
SET daytype = 'holiday', holidayname = h.holiday_name, description = h.note
FROM holiday h
WHERE g.calendardate = (CURRENT_DATE + h.offset_days)
    + CASE EXTRACT(ISODOW FROM (CURRENT_DATE + h.offset_days)) WHEN 6 THEN 2 WHEN 7 THEN 1 ELSE 0 END;

-- Exam sessions. Only working days are converted, so a holiday declared above
-- always wins over an exam that would fall on the same date. description holds
-- the subject codes sat that session; the API expands them into named subjects.
WITH exam(offset_days, exam_type, exam_session, note) AS (VALUES
    (-10, 'Unit Test 1', 'Morning', 'MAT10,SCI10'),
    (14, 'Unit Test 2', 'Morning', 'MAT10,SCI10,ENG10'),
    (15, 'Unit Test 2', 'Morning', 'SOC10,CS10'),
    (38, 'Mid Term', 'Morning', 'MAT10,SCI10,ENG10'),
    (39, 'Mid Term', 'Afternoon', 'SOC10,CS10')
)
UPDATE calendar_grid g
SET daytype = 'exam', examtype = e.exam_type, examsession = e.exam_session, description = e.note
FROM exam e
WHERE g.daytype = 'working'
    AND g.calendardate = (CURRENT_DATE + e.offset_days)
    + CASE EXTRACT(ISODOW FROM (CURRENT_DATE + e.offset_days)) WHEN 6 THEN 2 WHEN 7 THEN 1 ELSE 0 END;

COMMIT;
