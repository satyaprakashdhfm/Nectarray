# Student Management System

## Start the application

```powershell
# Terminal 1 — backend
cd backend
python -m pip install -r requirements.txt
python main.py
```

```powershell
# Terminal 2 — frontend
cd frontend
npm install
npm start
```

Open http://localhost:3000.
