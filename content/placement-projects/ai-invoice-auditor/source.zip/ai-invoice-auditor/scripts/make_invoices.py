"""Make the sample data: 100 invoice PDFs and the ERP records they are checked against.

    python scripts/make_invoices.py

Writes
    backend/app/data/incoming/INV-2026-001.pdf ... INV-2026-100.pdf
    backend/mcp_servers/data/erp/vendors.json
    backend/mcp_servers/data/erp/purchase_orders.json

Every invoice bills its own purchase order. Most match the PO exactly, so they
pass and are stored automatically. The ones listed in MISTAKES carry one small
error each, so the rules hold them for a human. Same seed, same files every time.
"""
import json
import random
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[1]
INCOMING = ROOT / "backend" / "app" / "data" / "incoming"
ERP = ROOT / "backend" / "mcp_servers" / "data" / "erp"

VENDORS = [
    ("V-ACME", "Acme Logistics Ltd", "USD", "400 Harbor Blvd, Long Beach, CA"),
    ("V-EURO", "Euro Freight GmbH", "EUR", "Hafenstrasse 12, Hamburg"),
    ("V-BRIT", "Britannia Haulage PLC", "GBP", "8 Dock Road, Felixstowe"),
    ("V-INDO", "IndoTrans Cargo Pvt Ltd", "INR", "Plot 22, JNPT Road, Navi Mumbai"),
    ("V-PACI", "Pacific Air Cargo Inc", "USD", "Cargo Bldg 5, SFO, San Francisco, CA"),
    ("V-ALPS", "Alpine Rail Logistics AG", "EUR", "Bahnhofplatz 3, Basel"),
    ("V-TAJ", "Taj Customs Brokers", "INR", "14 Ballard Estate, Mumbai"),
    ("V-THAM", "Thames Warehousing Ltd", "GBP", "Unit 9, Tilbury Park, Essex"),
    ("V-GULF", "Gulf Coast Trucking LLC", "USD", "2100 Port Rd, Houston, TX"),
    ("V-NORD", "Nordic Shipping AB", "EUR", "Frihamnen 4, Gothenburg"),
]

# item code: (description, base price in USD, typical quantity range)
CATALOG = {
    "FRT-AIR": ("Air freight", 1200, (1, 3)),
    "FRT-SEA20": ("Ocean freight, 20ft container", 950, (1, 4)),
    "FRT-SEA40": ("Ocean freight, 40ft container", 1650, (1, 3)),
    "FRT-ROAD": ("Road haulage, full truck", 480, (1, 5)),
    "FRT-RAIL": ("Rail freight, per wagon", 720, (1, 4)),
    "FUEL": ("Fuel surcharge", 180, (1, 2)),
    "CUSTOMS": ("Customs clearance", 250, (1, 2)),
    "HANDLING": ("Terminal handling", 140, (1, 4)),
    "STORAGE": ("Warehouse storage, pallet-week", 12, (10, 60)),
    "INSURANCE": ("Cargo insurance", 95, (1, 2)),
    "DOCS": ("Documentation fee", 45, (1, 1)),
}
RATE = {"USD": 1, "EUR": 0.92, "GBP": 0.79, "INR": 83}      # price in each currency
TAX = {"USD": 0.0, "EUR": 0.19, "GBP": 0.20, "INR": 0.18}   # VAT / GST on the subtotal

# invoice number -> the one small mistake it carries. Everything else is clean.
MISTAKES = {
    7: "price",       # one unit price 7% above the PO price (limit is 5%)
    19: "quantity",   # bills one unit more than the PO ordered
    28: "total",      # the grand total does not add up
    41: "extra_item", # bills an item that is not on the PO
    56: "price",
    63: "quantity",
    77: "total",
    92: "extra_item",
}


def money(value: float) -> str:
    return f"{value:,.2f}"


def make_order(n: int, rng: random.Random) -> dict:
    """One purchase order: a vendor, 2-4 items, agreed quantities and prices."""
    vendor_id, _, currency, _ = VENDORS[rng.randrange(len(VENDORS))]
    items = []
    for code in rng.sample(sorted(c for c in CATALOG if c != "DOCS"), rng.randint(2, 4)):
        _, base, (low, high) = CATALOG[code]
        price = round(base * RATE[currency] * rng.uniform(0.95, 1.05), 2)
        items.append({"item_code": code, "qty": rng.randint(low, high), "unit_price": price})
    return {"po_number": f"PO-{3000 + n}", "vendor_id": vendor_id, "currency": currency, "items": items}


def make_invoice(n: int, po: dict, rng: random.Random) -> dict:
    """The invoice for a PO: a copy of its lines, plus the mistake if n is in MISTAKES."""
    lines = [{**item, "description": CATALOG[item["item_code"]][0]} for item in po["items"]]
    mistake = MISTAKES.get(n)
    if mistake == "price":
        lines[0]["unit_price"] = round(lines[0]["unit_price"] * 1.07, 2)
    if mistake == "quantity":
        lines[-1]["qty"] += 1
    if mistake == "extra_item":
        lines.append({"item_code": "DOCS", "description": CATALOG["DOCS"][0], "qty": 1,
                      "unit_price": round(45 * RATE[po["currency"]], 2)})
    for line in lines:
        line["total"] = round(line["qty"] * line["unit_price"], 2)

    subtotal = round(sum(line["total"] for line in lines), 2)
    tax = round(subtotal * TAX[po["currency"]], 2)
    total = round(subtotal + tax + (25 if mistake == "total" else 0), 2)
    return {"invoice_no": f"INV-2026-{n:03d}", "invoice_date": f"2026-{7 + (n - 1) // 34:02d}-{(n - 1) % 28 + 1:02d}",
            "po": po, "lines": lines, "subtotal": subtotal, "tax": tax, "total": total}


def draw_pdf(path: Path, inv: dict) -> None:
    """Lay the invoice out on one A4 page."""
    po = inv["po"]
    vendor_id, name, currency, address = next(v for v in VENDORS if v[0] == po["vendor_id"])
    pdf = canvas.Canvas(str(path), pagesize=A4)
    pdf.setTitle(f"Invoice {inv['invoice_no']}")
    width, height = A4
    left, right = 50, width - 50

    pdf.setFillColor(colors.HexColor("#173D2C"))
    pdf.rect(0, height - 95, width, 95, stroke=0, fill=1)
    pdf.setFillColor(colors.white)
    pdf.setFont("Helvetica-Bold", 20)
    pdf.drawString(left, height - 50, name)
    pdf.setFont("Helvetica", 9)
    pdf.drawString(left, height - 68, address)
    pdf.setFont("Helvetica-Bold", 24)
    pdf.drawRightString(right, height - 55, "INVOICE")

    pdf.setFillColor(colors.black)
    y = height - 130
    pdf.setFont("Helvetica", 10)
    for text in (f"Vendor: {name}", f"Vendor ID: {vendor_id}", "Bill To: Global Logistics Control Tower",
                 "1 Harbour Road, Singapore 099253"):
        pdf.drawString(left, y, text)
        y -= 15
    y = height - 130
    for text in (f"Invoice No: {inv['invoice_no']}", f"Invoice Date: {inv['invoice_date']}",
                 f"PO Number: {po['po_number']}", f"Currency: {currency}"):
        pdf.drawString(right - 170, y, text)
        y -= 15

    y = height - 225
    pdf.setFillColor(colors.HexColor("#E7EFE5"))
    pdf.rect(left - 5, y - 6, right - left + 10, 20, stroke=0, fill=1)
    pdf.setFillColor(colors.black)
    pdf.setFont("Helvetica-Bold", 9)
    pdf.drawString(left, y, "Item Code")
    pdf.drawString(left + 85, y, "Description")
    pdf.drawRightString(right - 190, y, "Qty")
    pdf.drawRightString(right - 95, y, "Unit Price")
    pdf.drawRightString(right, y, "Amount")

    pdf.setFont("Helvetica", 9)
    for line in inv["lines"]:
        y -= 20
        pdf.drawString(left, y, line["item_code"])
        pdf.drawString(left + 85, y, line["description"])
        pdf.drawRightString(right - 190, y, str(line["qty"]))
        pdf.drawRightString(right - 95, y, money(line["unit_price"]))
        pdf.drawRightString(right, y, money(line["total"]))

    y -= 15
    pdf.line(left, y, right, y)
    rate = int(TAX[currency] * 100)
    for label, value, bold in (("Subtotal", inv["subtotal"], False), (f"Tax ({rate}%)", inv["tax"], False),
                               ("Total", inv["total"], True)):
        y -= 18
        pdf.setFont("Helvetica-Bold" if bold else "Helvetica", 11 if bold else 9)
        pdf.drawRightString(right - 95, y, f"{label} {currency}" if bold else label)
        pdf.drawRightString(right, y, money(value))

    pdf.setFont("Helvetica", 8)
    pdf.setFillColor(colors.HexColor("#5A6E64"))
    pdf.drawString(left, 60, f"Payment terms: Net 30 days. Please quote {inv['invoice_no']} and {po['po_number']} with your payment.")
    pdf.save()


def main() -> None:
    rng = random.Random(2026)
    INCOMING.mkdir(parents=True, exist_ok=True)
    ERP.mkdir(parents=True, exist_ok=True)
    for old in INCOMING.iterdir():
        old.unlink()

    orders = []
    for n in range(1, 101):
        po = make_order(n, rng)
        orders.append(po)
        draw_pdf(INCOMING / f"INV-2026-{n:03d}.pdf", make_invoice(n, po, rng))

    vendors = [{"vendor_id": v, "name": name, "currency": cur, "active": True} for v, name, cur, _ in VENDORS]
    (ERP / "vendors.json").write_text(json.dumps(vendors, indent=2), encoding="utf-8")
    (ERP / "purchase_orders.json").write_text(json.dumps(orders, indent=2), encoding="utf-8")
    print(f"100 invoices in {INCOMING.relative_to(ROOT)}, {len(MISTAKES)} with a small mistake: "
          + ", ".join(f"INV-2026-{n:03d} ({kind})" for n, kind in MISTAKES.items()))


if __name__ == "__main__":
    main()
