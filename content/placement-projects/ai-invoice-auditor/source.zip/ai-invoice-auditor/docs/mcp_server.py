"""Calculator MCP server.  Run: python mcp_server.py  ->  http://localhost:8000/mcp"""
from fastmcp import FastMCP

mcp = FastMCP("Calculator")


@mcp.tool
def add(a: float, b: float) -> float:
    """Add two numbers."""
    return a + b


@mcp.tool
def subtract(a: float, b: float) -> float:
    """Subtract b from a."""
    return a - b


@mcp.tool
def multiply(a: float, b: float) -> float:
    """Multiply two numbers."""
    return a * b


if __name__ == "__main__":
    mcp.run(transport="http", port=8000)
