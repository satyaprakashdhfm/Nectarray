"""Talks to the ERP MCP server (backend/mcp_servers/mcp_server.py).

The app never opens the ERP files. Vendors and purchase orders come from that
server as MCP tool calls: each pipeline run opens one MCP session and makes one
call per record.
"""
import asyncio
import json

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

URL = "http://127.0.0.1:8001/mcp"
START_COMMAND = "python -m backend.mcp_servers.mcp_server"


async def _lookup(vendor_ids: set, po_numbers: set) -> tuple[dict, dict]:
    async with streamablehttp_client(URL) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()

            async def call(tool: str, **args) -> dict | None:
                result = await session.call_tool(tool, args)
                return json.loads(result.content[0].text) or None   # the server answers {} for "not found"

            vendors = {v: await call("get_vendor", vendor_id=v) for v in vendor_ids if v}
            orders = {p: await call("get_po", po_number=p) for p in po_numbers if p}
            return vendors, orders


def lookup(vendor_ids, po_numbers) -> tuple[dict, dict]:
    """Fetch these vendors and purchase orders. Returns ({vendor_id: record}, {po_number: record})."""
    return asyncio.run(_lookup(set(vendor_ids), set(po_numbers)))


def is_up() -> bool:
    """True when the ERP MCP server answers."""
    try:
        lookup([], [])
        return True
    except Exception:
        return False
