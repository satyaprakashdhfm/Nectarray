"""Gemini, used by the chat only.

Invoice fields are read by regex in pipeline.py, so auditing 100 PDFs costs
nothing. The key is needed for two things: answering chat questions here, and
embedding the audited invoices in vector_store.py.
"""
import json

from google import genai
from google.genai import types

MODEL = "gemini-3.6-flash"


def is_up(api_key: str | None) -> bool:
    """True when the key works and Gemini answers. Listing models spends no tokens."""
    if not api_key:
        return False
    client = genai.Client(api_key=api_key)   # keep a reference: a dropped client closes its connection
    try:
        next(iter(client.models.list()), None)
        return True
    except Exception as exc:
        print(f"[gemini] key check failed: {str(exc)[:120]}", flush=True)
        return False


PROMPT = """You are the assistant for an invoice audit. Answer only from the two blocks below.

SUMMARY counts every audited invoice by status. RECORDS holds the few invoices picked out
for this question, in full. So take counts from the summary and details from the records.
A status means:
  auto_approved       matched its purchase order, stored without a human
  needs_review        a rule flagged it, still waiting for a person
  approved, rejected  a person has since decided it

Answer in two or three sentences. Name the invoice numbers you used, and when the question
is about a problem, quote the finding that explains it. If the blocks do not answer the
question, say so plainly instead of guessing.

QUESTION
{question}

SUMMARY
{summary}

RECORDS
{records}"""


def answer_question(question: str, summary: str, records: list[dict], api_key: str) -> str:
    """Answer from the summary line and the retrieved invoice records only."""
    prompt = PROMPT.format(question=question, summary=summary,
                           records="\n".join(json.dumps(record) for record in records) or "none retrieved")
    client = genai.Client(api_key=api_key)
    try:
        reply = client.models.generate_content(
            model=MODEL, contents=prompt, config=types.GenerateContentConfig(temperature=0.1))
        return reply.text.strip()
    except Exception as exc:
        return f"Gemini could not answer: {str(exc)[:200]}"
