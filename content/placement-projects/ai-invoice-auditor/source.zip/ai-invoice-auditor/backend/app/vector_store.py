"""Vectors for the chat: every audited invoice becomes one embedded document.

A small LangGraph graph does the ingest in two steps, load -> store. There is
one store, LangChain's InMemoryVectorStore: it is created on the first run with
an API key and is gone when the API stops. Each document's id is its PDF file
name, so indexing an invoice again (after Approve / Reject) replaces it.
"""
from typing import TypedDict

from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langgraph.graph import START, StateGraph

EMBEDDING_MODEL = "gemini-embedding-001"
TOP_K = 8
_store: InMemoryVectorStore | None = None


def to_text(review: dict) -> str:
    """One invoice as plain sentences, which is what gets embedded."""
    inv = review["invoice"]
    items = "; ".join(f"{l['item_code']} {l['description']} qty {l['qty']} at {l['unit_price']}" for l in inv["line_items"])
    problems = "; ".join(f["message"] for f in review["findings"]) or "none"
    return (f"Invoice {inv['invoice_no']} from {inv['vendor_name']} ({inv['vendor_id']}), PO {inv['po_number']}, "
            f"dated {inv['invoice_date']}, total {inv['total_amount']} {inv['currency']}. Status: {review['status']}. "
            f"Items: {items}. Problems: {problems}.")


class IngestState(TypedDict):
    reviews: list[dict]
    docs: list[Document]


def load(state: IngestState) -> dict:
    return {"docs": [Document(to_text(review), id=review["file"]) for review in state["reviews"]]}


def store(state: IngestState) -> dict:
    _store.add_documents(state["docs"])   # embeds each document, then saves it under its id
    return {}


ingest = StateGraph(IngestState).add_sequence([load, store]).add_edge(START, "load").compile()


def index(reviews: list[dict], api_key: str | None) -> None:
    """Embed these reviews into the store. Skipped without an API key."""
    global _store
    if not api_key or not reviews:
        return
    try:
        if _store is None:
            _store = InMemoryVectorStore(GoogleGenerativeAIEmbeddings(model=EMBEDDING_MODEL, api_key=api_key))
        ingest.invoke({"reviews": reviews})
        print(f"[vectors] embedded {len(reviews)} invoice(s), {len(_store.store)} in the store", flush=True)
    except Exception as exc:
        print(f"[vectors] embedding failed: {str(exc)[:150]}", flush=True)


def search(question: str) -> list[str]:
    """File names of the TOP_K invoices closest in meaning to the question. Empty if nothing was embedded."""
    if _store is None:
        return []
    try:
        return [doc.id for doc in _store.similarity_search(question, k=TOP_K)]
    except Exception as exc:
        print(f"[vectors] search failed: {str(exc)[:150]}", flush=True)
        return []
