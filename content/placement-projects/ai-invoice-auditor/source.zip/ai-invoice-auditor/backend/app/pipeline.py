"""The audit pipeline: invoice PDFs in, verdicts out.

For every new PDF in data/incoming:
  1. read the text out of the PDF
  2. read the invoice fields off that text with regex - no LLM call, so a run is free
  3. fetch its vendor and purchase order from the ERP MCP server
  4. validate: nothing wrong -> "auto_approved" (stored), anything wrong -> "needs_review" (a human decides)
"""
import re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from pypdf import PdfReader

from . import erp_client

INCOMING_DIR = Path(__file__).resolve().parent / "data" / "incoming"
REQUIRED = ("invoice_no", "invoice_date", "vendor_id", "po_number", "currency", "total_amount")
PRICE_TOLERANCE = 0.05   # a unit price may be up to 5% away from the PO price
PROCESSED: set[str] = set()


def read_pdf(path: Path) -> str:
    return "\n".join(page.extract_text() or "" for page in PdfReader(path).pages)


def number(value) -> float | None:
    """'1,200.00' -> 1200.0. Missing or unreadable -> None, so the rules flag it instead of guessing."""
    try:
        return float(str(value).replace(",", ""))
    except (TypeError, ValueError):
        return None


def extract(path: Path) -> dict:
    """PDF -> invoice fields, read off the labels printed on the page."""
    text = read_pdf(path)

    def after(label: str) -> str | None:
        hit = re.search(rf"^{label}\s*(.+)$", text, re.M)
        return (hit.group(1).strip() or None) if hit else None

    # pypdf gives one table cell per line: code, description, qty, unit price, amount
    rows = re.findall(r"^([A-Z][A-Z0-9-]+)\n(.+)\n(\d+)\n([\d,]+\.\d\d)\n([\d,]+\.\d\d)$", text, re.M)
    return {
        "invoice_no": after("Invoice No:"), "invoice_date": after("Invoice Date:"),
        "vendor_id": after("Vendor ID:"), "vendor_name": after("Vendor:"),
        "po_number": after("PO Number:"), "currency": after("Currency:"),
        "tax_amount": number(after(r"Tax \(\d+%\)\n")) or 0.0,
        "total_amount": number(after(r"Total [A-Z]{3}\n")),
        "line_items": [{"item_code": code, "description": description, "qty": number(qty),
                        "unit_price": number(unit_price), "total": number(total)}
                       for code, description, qty, unit_price, total in rows],
    }


def validate(invoice: dict, vendor: dict | None, po: dict | None) -> list[dict]:
    """Every rule, in one place. An empty list means the invoice is clean."""
    findings = []

    def flag(code: str, message: str) -> None:
        findings.append({"code": code, "message": message})

    for name in REQUIRED:
        if invoice[name] is None:
            flag("MISSING_FIELD", f"{name} is missing")

    lines = invoice["line_items"]
    expected = round(sum(line["total"] or 0 for line in lines) + invoice["tax_amount"], 2)
    if invoice["total_amount"] is not None and abs(expected - invoice["total_amount"]) > 0.01:
        flag("TOTAL", f"Lines plus tax come to {expected:,.2f} but the invoice total is {invoice['total_amount']:,.2f}")

    if not vendor or not vendor["active"]:
        flag("VENDOR", f"Vendor {invoice['vendor_id']} is unknown or inactive in the ERP")
    if not po:
        flag("PO", f"Purchase order {invoice['po_number']} is not in the ERP")
        return findings
    if po["vendor_id"] != invoice["vendor_id"]:
        flag("PO_VENDOR", f"{po['po_number']} belongs to {po['vendor_id']}, not {invoice['vendor_id']}")
    if po["currency"] != invoice["currency"]:
        flag("CURRENCY", f"Invoice is in {invoice['currency']}, the PO is in {po['currency']}")

    ordered = {item["item_code"]: item for item in po["items"]}
    for line in lines:
        code, item = line["item_code"], ordered.get(line["item_code"])
        if not item:
            flag("ITEM", f"{code} is billed but not on {po['po_number']}")
            continue
        if line["qty"] != item["qty"]:
            flag("QUANTITY", f"{code}: billed {line['qty'] or 0:g}, the PO ordered {item['qty']}")
        if line["unit_price"] is not None and abs(line["unit_price"] - item["unit_price"]) > PRICE_TOLERANCE * item["unit_price"]:
            flag("PRICE", f"{code}: billed {line['unit_price']:,.2f} each, the PO price is {item['unit_price']:,.2f}")
    return findings


def run() -> list[dict]:
    """Audit every PDF not processed yet. Returns the new reviews."""
    files = [path for path in sorted(INCOMING_DIR.glob("*.pdf")) if path.name not in PROCESSED]
    if not files:
        return []
    with ThreadPoolExecutor(max_workers=8) as pool:   # 8 PDFs read at a time
        invoices = list(pool.map(extract, files))
    vendors, orders = erp_client.lookup({i["vendor_id"] for i in invoices}, {i["po_number"] for i in invoices})

    reviews = []
    for path, invoice in zip(files, invoices):
        findings = validate(invoice, vendors.get(invoice["vendor_id"]), orders.get(invoice["po_number"]))
        status = "needs_review" if findings else "auto_approved"
        reviews.append({"file": path.name, "invoice": invoice, "findings": findings, "status": status})
        print(f"[pipeline] {path.name} {status} {' '.join(f['code'] for f in findings)}", flush=True)
    PROCESSED.update(path.name for path in files)
    return reviews
