"""The chat: vector search picks the relevant invoices, Gemini answers from them.

Gemini also gets a one-line summary of all audited invoices, so questions about
counts ("how many were rejected?") work even though only TOP_K records are sent.
"""
from . import llm, vector_store


def summary(reviews: list[dict]) -> str:
    """e.g. '100 invoices: 92 auto_approved, 6 needs_review (INV-...), 1 approved (INV-...), 1 rejected (INV-...).'"""
    by_status: dict[str, list[str]] = {}
    for review in reviews:
        by_status.setdefault(review["status"], []).append(review["invoice"]["invoice_no"] or review["file"])
    parts = [f"{len(numbers)} {status}" if status == "auto_approved" else f"{len(numbers)} {status} ({', '.join(numbers)})"
             for status, numbers in by_status.items()]
    return f"{len(reviews)} invoices: {', '.join(parts)}."


def answer(question: str, reviews: list[dict], api_key: str | None) -> dict:
    if not reviews:
        return {"answer": "No invoices audited yet. Run the pipeline first.", "sources": []}
    if not api_key:
        return {"answer": "The chat needs a Google AI key. Add one at the top of the page.", "sources": []}

    by_file = {review["file"]: review for review in reviews}
    records = [by_file[f] for f in vector_store.search(question) if f in by_file]
    text = llm.answer_question(question, summary(reviews), records, api_key)
    print(f"[chat] {question[:60]!r} -> {len(records)} record(s)", flush=True)
    return {"answer": text, "sources": [r["invoice"]["invoice_no"] or r["file"] for r in records]}
