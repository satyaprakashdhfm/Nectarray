"""The API the React app calls.

    uvicorn backend.app.main:app --reload --port 8000     # Swagger UI at /docs

Start the ERP MCP server first (python -m backend.mcp_servers.mcp_server).
Audited invoices live in REVIEWS, in memory: they are gone when the API stops.
"""
import os

from fastapi import Body, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from . import chat, erp_client, llm, pipeline, vector_store

app = FastAPI(title="AI Invoice Auditor",
              description="Invoice PDFs are read with regex, checked against the ERP over MCP, "
                          "and either stored automatically or held for a human. Gemini answers questions about them.")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_methods=["*"], allow_headers=["*"])

REVIEWS: dict[str, dict] = {}   # PDF file name -> review (file, invoice, findings, status)


def api_key(body: dict | None) -> str | None:
    """The Google AI key from the request, else from the GEMINI_API_KEY environment variable."""
    return (body or {}).get("api_key") or os.getenv("GEMINI_API_KEY")


@app.post("/health")
def health(body: dict | None = Body(default=None, examples=[{"api_key": ""}])):
    """Are the two outside services reachable: the ERP MCP server, and Gemini with this key.

    A POST, not a GET, so the key travels in the body: a query string would end up
    in the server log. The UI asks on load, when the key changes, and on Check again.
    """
    return {"erp_mcp": erp_client.is_up(), "gemini": llm.is_up(api_key(body))}


@app.post("/pipeline/run")
def run_pipeline(body: dict | None = Body(default=None, examples=[{"api_key": ""}])):
    """Audit every new PDF in backend/app/data/incoming, then embed them for the chat."""
    if not erp_client.is_up():
        raise HTTPException(503, f"The ERP MCP server is not running. Start it with: {erp_client.START_COMMAND}")
    new = pipeline.run()
    REVIEWS.update((review["file"], review) for review in new)
    vector_store.index(new, api_key(body))
    held = sum(r["status"] == "needs_review" for r in new)
    print(f"[api] pipeline run: {len(new)} new invoice(s), {len(new) - held} stored, {held} need review", flush=True)
    return {"reviews": list(REVIEWS.values())}


@app.post("/reviews/{file}/decision")
def decide(file: str, body: dict = Body(examples=[{"decision": "approved"}, {"decision": "rejected"}])):
    """A human approves or rejects an invoice the rules held back."""
    review = REVIEWS.get(file)
    if not review:
        raise HTTPException(404, f"No invoice {file}. Run the pipeline first.")
    if review["status"] != "needs_review":
        raise HTTPException(409, f"{file} is not waiting for review (status: {review['status']})")
    if body.get("decision") not in ("approved", "rejected"):
        raise HTTPException(422, "decision must be 'approved' or 'rejected'")

    review["status"] = body["decision"]
    vector_store.index([review], api_key(body))   # embed it again so the chat knows the decision
    print(f"[api] {file} {review['status']} by reviewer", flush=True)
    return {"review": review}


@app.post("/chat")
def ask(body: dict = Body(examples=[{"question": "Which invoices need review and why?"}])):
    """Answer a question about the audited invoices."""
    question = str(body.get("question") or "").strip()
    if not question:
        raise HTTPException(422, "question is required")
    return chat.answer(question, list(REVIEWS.values()), api_key(body))
