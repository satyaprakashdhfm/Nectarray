"""ERP MCP server: serves vendor and purchase-order records as two MCP tools.

Start it in its own terminal, before the API:

    python -m backend.mcp_servers.mcp_server      # http://127.0.0.1:8001/mcp

It is the only code that reads the ERP files in ./data/erp. The API reaches them
through backend/app/erp_client.py, one tool call at a time.
"""
import json
from pathlib import Path

from mcp.server.fastmcp import FastMCP

ERP_DIR = Path(__file__).resolve().parent / "data" / "erp"
VENDORS = {v["vendor_id"]: v for v in json.loads((ERP_DIR / "vendors.json").read_text(encoding="utf-8"))}
ORDERS = {po["po_number"]: po for po in json.loads((ERP_DIR / "purchase_orders.json").read_text(encoding="utf-8"))}

mcp = FastMCP("ERP", host="127.0.0.1", port=8001, log_level="WARNING")


@mcp.tool()
def get_vendor(vendor_id: str) -> dict:
    """Vendor master record: name, currency and whether the vendor is active. {} if unknown."""
    vendor = VENDORS.get(vendor_id, {})
    print(f"[erp] get_vendor {vendor_id} -> {'found' if vendor else 'NOT FOUND'}", flush=True)
    return vendor


@mcp.tool()
def get_po(po_number: str) -> dict:
    """Purchase order: vendor, currency and the ordered items with qty and unit price. {} if unknown."""
    po = ORDERS.get(po_number, {})
    found = f"{len(po['items'])} item(s)" if po else "NOT FOUND"
    print(f"[erp] get_po {po_number} -> {found}", flush=True)
    return po


if __name__ == "__main__":
    print(f"ERP MCP server on http://127.0.0.1:8001/mcp - {len(VENDORS)} vendors, {len(ORDERS)} purchase orders")
    mcp.run(transport="streamable-http")
