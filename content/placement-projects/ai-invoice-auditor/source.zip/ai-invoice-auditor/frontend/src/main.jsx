/**
 * Invoice Auditor UI.
 *
 * On load it asks the API whether the ERP MCP server and Gemini are reachable.
 * "Run pipeline" audits the invoice PDFs: clean ones are stored automatically,
 * the rest wait here for Approve / Reject. Once the run is done, the chat opens.
 */
import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const API = 'http://localhost:8000';
const START_ERP = 'python -m backend.mcp_servers.mcp_server';
const STATUS = { auto_approved: 'Stored', needs_review: 'Needs review', approved: 'Approved', rejected: 'Rejected' };

/** GET when there is no body, POST JSON otherwise. Throws the API's error message. */
async function call(path, body) {
  const options = body === undefined ? {} : {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
  const response = await fetch(API + path, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || `Request failed (${response.status})`);
  return data;
}

function money(amount, currency) {
  const number = Number(amount ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${number} ${currency ?? ''}`;
}

function count(reviews, status) {
  return reviews.filter((review) => review.status === status).length;
}

function Stats({ reviews }) {
  return (
    <section className="stats">
      <div><b>{reviews.length}</b><span>invoices</span></div>
      <div><b>{count(reviews, 'auto_approved')}</b><span>stored automatically</span></div>
      <div><b>{count(reviews, 'needs_review')}</b><span>need review</span></div>
      <div><b>{count(reviews, 'approved')}</b><span>approved by you</span></div>
      <div><b>{count(reviews, 'rejected')}</b><span>rejected</span></div>
    </section>
  );
}

/** An invoice the rules held back: what is wrong with it, and the two buttons. */
function ReviewCard({ review, onDecide }) {
  const { invoice, findings } = review;
  return (
    <article>
      <h3>{invoice.invoice_no}</h3>
      <p>{invoice.vendor_name} · {invoice.po_number}</p>
      <strong>{money(invoice.total_amount, invoice.currency)}</strong>
      <ul>
        {findings.map((finding, index) => <li key={index}><b>{finding.code}</b> {finding.message}</li>)}
      </ul>
      <footer>
        <button className="approve" onClick={() => onDecide(review.file, 'approved')}>Approve</button>
        <button className="reject" onClick={() => onDecide(review.file, 'rejected')}>Reject</button>
      </footer>
    </article>
  );
}

function InvoiceTable({ reviews }) {
  return (
    <details>
      <summary>All invoices ({reviews.length})</summary>
      <table>
        <thead>
          <tr><th>Invoice</th><th>Vendor</th><th>PO</th><th>Date</th><th className="num">Total</th><th>Status</th></tr>
        </thead>
        <tbody>
          {reviews.map(({ file, invoice, status }) => (
            <tr key={file}>
              <td>{invoice.invoice_no}</td>
              <td>{invoice.vendor_name}</td>
              <td>{invoice.po_number}</td>
              <td>{invoice.invoice_date}</td>
              <td className="num">{money(invoice.total_amount, invoice.currency)}</td>
              <td><span className={`tag ${status}`}>{STATUS[status]}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </details>
  );
}

/** Opens after a pipeline run, starting with a summary of what the run did. */
function Chat({ reviews, apiKey }) {
  const [messages, setMessages] = useState(() => [{
    role: 'assistant',
    text: `Audit done: ${reviews.length} invoices, ${count(reviews, 'auto_approved')} stored automatically, `
      + `${count(reviews, 'needs_review')} waiting for your review. Ask me anything about them.`,
  }]);
  const [question, setQuestion] = useState('');

  const ask = async (event) => {
    event.preventDefault();
    if (!question.trim()) return;
    const asked = question;
    setQuestion('');
    setMessages((thread) => [...thread, { role: 'user', text: asked }]);
    try {
      const result = await call('/chat', { question: asked, api_key: apiKey || null });
      setMessages((thread) => [...thread, { role: 'assistant', text: result.answer, sources: result.sources }]);
    } catch (error) {
      setMessages((thread) => [...thread, { role: 'assistant', text: error.message }]);
    }
  };

  return (
    <section className="chat">
      <h2>Ask about the invoices</h2>
      <div className="thread">
        {messages.map((message, index) => (
          <div className={message.role} key={index}>
            {message.text}
            {message.sources?.length > 0 && <small>Sources: {message.sources.join(', ')}</small>}
          </div>
        ))}
      </div>
      <form onSubmit={ask}>
        <input
          value={question}
          onChange={(event) => setQuestion(event.target.value)}
          placeholder={apiKey ? 'Which invoices need review, and why?' : 'Add a Google AI key above to chat'}
        />
        <button>Send</button>
      </form>
    </section>
  );
}

function App() {
  const [erpUp, setErpUp] = useState(null);   // null while checking
  const [llmUp, setLlmUp] = useState(null);
  const [apiKey, setApiKey] = useState(() => sessionStorage.getItem('geminiApiKey') || '');
  const [reviews, setReviews] = useState([]);
  const [ran, setRan] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  /** Is the ERP server up. Asked on load and on Check again. */
  const checkErp = () => call('/health', {})
    .then((health) => setErpUp(health.erp_mcp))
    .catch(() => setErpUp(false));
  useEffect(() => { checkErp(); }, []);

  /** Does this key work. Only ever asked when you press Check. */
  const checkKey = () => call('/health', { api_key: apiKey || null })
    .then((health) => setLlmUp(health.gemini))
    .catch(() => setLlmUp(false));

  const saveKey = (value) => {
    setApiKey(value);
    if (value) sessionStorage.setItem('geminiApiKey', value);
    else sessionStorage.removeItem('geminiApiKey');
  };

  const runPipeline = async () => {
    setBusy(true);
    setError('');
    try {
      const result = await call('/pipeline/run', { api_key: apiKey || null });
      setReviews(result.reviews);
      setRan(true);
    } catch (err) {
      setError(err.message);
      checkErp();
    } finally {
      setBusy(false);
    }
  };

  const decide = async (file, decision) => {
    try {
      const result = await call(`/reviews/${encodeURIComponent(file)}/decision`, { decision, api_key: apiKey || null });
      setReviews((current) => current.map((review) => (review.file === file ? result.review : review)));
    } catch (err) {
      setError(err.message);
    }
  };

  const waiting = reviews.filter((review) => review.status === 'needs_review');
  // Not checked yet, and no key yet, are both neutral; only a key Gemini rejected is red.
  const gemini = llmUp ? { tone: 'up', text: 'Gemini connected' }
    : llmUp === null ? { tone: '', text: 'Gemini key not checked' }
    : apiKey ? { tone: 'down', text: 'Gemini key not working' }
    : { tone: '', text: 'Gemini needs a key for the chat' };

  return (
    <main>
      <header>
        <div>
          <span className="eyebrow">GLOBAL LOGISTICS · CONTROL TOWER</span>
          <h1>Invoice Auditor</h1>
        </div>
        <div className="actions">
          <span className={`pill ${erpUp === null ? '' : erpUp ? 'up' : 'down'}`}>
            {erpUp === null ? 'Checking ERP…' : erpUp ? 'ERP MCP server connected' : 'ERP MCP server not running'}
          </span>
          <span className={`pill ${gemini.tone}`}>{gemini.text}</span>
          <button onClick={runPipeline} disabled={busy || !erpUp}>{busy ? 'Auditing…' : 'Run pipeline'}</button>
        </div>
      </header>

      {erpUp === false && (
        <p className="banner">
          Start the ERP MCP server in a terminal: <code>{START_ERP}</code>
          <button onClick={checkErp}>Check again</button>
        </p>
      )}

      <section className="keybar">
        <label>
          Google AI API key
          <input type="password" value={apiKey} onChange={(event) => saveKey(event.target.value)} placeholder="AIza…" />
        </label>
        <button onClick={checkKey}>Check</button>
        <small>The audit itself never calls Gemini — invoice fields are read by regex. The key is what the chat needs.
          Press Check to see whether it works.</small>
      </section>

      {error && <p className="banner">{error}</p>}

      {!ran ? (
        <p className="empty">Invoice PDFs are waiting in <code>backend/app/data/incoming</code>. Press <b>Run pipeline</b>.</p>
      ) : (
        <>
          <Stats reviews={reviews} />
          <h2>Waiting for review ({waiting.length})</h2>
          {waiting.length > 0 ? (
            <div className="grid">
              {waiting.map((review) => <ReviewCard key={review.file} review={review} onDecide={decide} />)}
            </div>
          ) : (
            <p className="empty">Nothing is waiting. Every invoice is decided.</p>
          )}
          <Chat reviews={reviews} apiKey={apiKey} />
          <InvoiceTable reviews={reviews} />
        </>
      )}
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
